package com.ivisuals;

import java.util.Arrays;

/** Colors and 2D rasterizing helpers (lines, polygons) on top of a Canvas. No Minecraft classes. */
public final class Fx {
    private Fx() {}

    public static final String[] COLORS = {
            "Rainbow", "Cyan", "Pink", "Gold", "Purple", "Red", "Green", "White", "Aqua-Pink"
    };

    public static int hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float r = 0, g = 0, b = 0;
        int i = (int) (h * 6f);
        float f = h * 6f - i, p = v * (1f - s), q = v * (1f - f * s), t = v * (1f - (1f - f) * s);
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** RGB for a color preset (index into COLORS). phase offsets the animation. */
    public static int color(int mode, float time, float phase) {
        return switch (mode) {
            case 0 -> hsv(time * 0.35f + phase, 0.85f, 1f);
            case 1 -> 0x00E5FF;
            case 2 -> 0xFF4FD8;
            case 3 -> 0xFFC83A;
            case 4 -> 0xA855FF;
            case 5 -> 0xFF3B3B;
            case 6 -> 0x3BFF7A;
            case 7 -> 0xFFFFFF;
            default -> mix(0x00E5FF, 0xFF4FD8, 0.5f + 0.5f * (float) Math.sin(time * 2f + phase * 6.283f));
        };
    }

    public static int withAlpha(int rgb, float a) {
        int al = (int) (255f * Math.max(0f, Math.min(1f, a)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    // ------------------------------------------------------------------ lines

    /** Thick line, clipped to the screen. Consecutive pixels are merged into runs (few fills, no double blending). */
    public static void line(Canvas c, int sw, int sh, double x0, double y0, double x1, double y1, int w, int argb) {
        if ((argb >>> 24) == 0) return;
        // Liang-Barsky against the screen rect (with a small margin)
        double xmin = -2, ymin = -2, xmax = sw + 2, ymax = sh + 2;
        double dx = x1 - x0, dy = y1 - y0, t0 = 0, t1 = 1;
        double[] p = {-dx, dx, -dy, dy};
        double[] q = {x0 - xmin, xmax - x0, y0 - ymin, ymax - y0};
        for (int i = 0; i < 4; i++) {
            if (p[i] == 0) {
                if (q[i] < 0) return;
            } else {
                double r = q[i] / p[i];
                if (p[i] < 0) { if (r > t1) return; if (r > t0) t0 = r; }
                else { if (r < t0) return; if (r < t1) t1 = r; }
            }
        }
        double ax = x0 + dx * t0, ay = y0 + dy * t0, bx = x0 + dx * t1, by = y0 + dy * t1;
        dx = bx - ax;
        dy = by - ay;
        int steps = (int) Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)));
        int half = w / 2;
        if (steps == 0) {
            int ix = (int) Math.floor(ax), iy = (int) Math.floor(ay);
            c.fill(ix - half, iy - half, ix - half + w, iy - half + w, argb);
            return;
        }
        boolean xMajor = Math.abs(dx) >= Math.abs(dy);
        int runStart = 0, runMinor = 0, last = 0;
        boolean open = false;
        for (int i = 0; i <= steps; i++) {
            double t = (double) i / steps;
            int ix = (int) Math.floor(ax + dx * t), iy = (int) Math.floor(ay + dy * t);
            int major = xMajor ? ix : iy, minor = xMajor ? iy : ix;
            if (!open) {
                runStart = major; runMinor = minor; last = major; open = true;
            } else if (minor == runMinor && major == last + 1 || major == last && minor == runMinor) {
                last = major;
            } else {
                flushRun(c, xMajor, runStart, last, runMinor, w, half, argb);
                runStart = major; runMinor = minor; last = major;
            }
        }
        if (open) flushRun(c, xMajor, runStart, last, runMinor, w, half, argb);
    }

    private static void flushRun(Canvas c, boolean xMajor, int a, int b, int minor, int w, int half, int argb) {
        int lo = Math.min(a, b), hi = Math.max(a, b) + 1;
        if (xMajor) c.fill(lo, minor - half, hi, minor - half + w, argb);
        else c.fill(minor - half, lo, minor - half + w, hi, argb);
    }

    // ---------------------------------------------------------------- polygons

    /** Fills a polygon (even-odd) with horizontal scanlines. xs/ys are screen coords, n vertices. */
    public static void fillPoly(Canvas c, int sw, int sh, double[] xs, double[] ys, int n, int argb) {
        if (n < 3 || (argb >>> 24) == 0) return;
        double minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < n; i++) { minY = Math.min(minY, ys[i]); maxY = Math.max(maxY, ys[i]); }
        int y0 = Math.max(0, (int) Math.ceil(minY)), y1 = Math.min(sh - 1, (int) Math.floor(maxY));
        double[] cross = new double[n];
        for (int y = y0; y <= y1; y++) {
            double sy = y + 0.5;
            int k = 0;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                double ya = ys[i], yb = ys[j];
                if ((ya <= sy && yb > sy) || (yb <= sy && ya > sy)) {
                    cross[k++] = xs[i] + (sy - ya) / (yb - ya) * (xs[j] - xs[i]);
                }
            }
            Arrays.sort(cross, 0, k);
            for (int i = 0; i + 1 < k; i += 2) {
                int xa = Math.max(0, (int) Math.round(cross[i])), xb = Math.min(sw, (int) Math.round(cross[i + 1]));
                if (xb > xa) c.fill(xa, y, xb, y + 1, argb);
            }
        }
    }
}
