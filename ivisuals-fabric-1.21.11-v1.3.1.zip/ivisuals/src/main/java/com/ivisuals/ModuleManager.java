package com.ivisuals;

import com.ivisuals.Module.Category;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Add a feature with ONE line in the static block:
 *
 *     add("My Feature", Category.VISUALS, "Short description")
 *         .onTick(mc -> { ... })
 *         .onToggle(on -> { ... });
 *
 * It gets a card in the menu, search, a saved ON/OFF state and an
 * Alt+Click keybind automatically.
 */
public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();

    public static Module FULLBRIGHT, HANDS, BLOCK_HIGHLIGHT, SWING, HIT_PARTICLES, HIT_HIGHLIGHT, OPTIMIZER;

    static {
        // ---- VISUALS ----
        FULLBRIGHT = add("Fullbright", Category.VISUALS, "Max brightness")
                .onTick(Fullbright::tick)
                .onToggle(on -> { if (!on) Fullbright.disable(MinecraftClient.getInstance()); });

        HANDS = add("Hand Tweaks", Category.VISUALS, "Size and position of hands");
        HandTweaks.setup(HANDS);

        BLOCK_HIGHLIGHT = add("Block Highlight", Category.VISUALS, "Glow on the block you look at");
        BlockHighlight.setup(BLOCK_HIGHLIGHT);

        // ---- COMBAT ----
        SWING = add("Swing Animation", Category.COMBAT, "Pick how your hit swings");
        SwingAnimation.setup(SWING);

        HIT_PARTICLES = add("Hit Particles", Category.COMBAT, "Dollars, ducks, crowns on hit")
                .onToggle(on -> { if (!on) HitParticles.clear(); });
        HitParticles.setup(HIT_PARTICLES);

        HIT_HIGHLIGHT = add("Hit Highlight", Category.COMBAT, "Target glows after your hit")
                .onTick(HitHighlight::tick)
                .onToggle(on -> { if (!on) HitHighlight.clear(MinecraftClient.getInstance()); });
        HitHighlight.setup(HIT_HIGHLIGHT);

        // ---- PLAYER ----
        add("Inventory Move", Category.PLAYER, "Walk with inventory open")
                .onTick(InventoryMove::tick);

        // ---- PERFORMANCE ----
        OPTIMIZER = add("Optimizer", Category.PERFORMANCE, "Hard FPS boost")
                .onTick(Optimizer::tick)
                .onToggle(on -> { if (!on) Optimizer.disable(MinecraftClient.getInstance()); });
        Optimizer.setup(OPTIMIZER);

        // ---- HUD ----
        add("Inventory HUD", Category.HUD, "Your inventory on screen").defaultOn();
        add("Armor HUD", Category.HUD, "Armor durability").defaultOn();
    }

    public static Module add(String name, Category cat, String description) {
        Module m = new Module(name, cat, description);
        MODULES.add(m);
        return m;
    }

    public static void tick(MinecraftClient mc) {
        boolean free = mc.currentScreen == null;
        for (Module m : MODULES) {
            if (m.bind != Module.NO_KEY && mc.getWindow() != null) {
                boolean down = InputUtil.isKeyPressed(mc.getWindow(), m.bind);
                if (down && !m.bindWasDown && free) m.toggle();
                m.bindWasDown = down;
            }
            m.tick(mc);
        }
    }

    public static boolean isOn(String name) {
        for (Module m : MODULES) if (m.name.equals(name)) return m.enabled;
        return false;
    }

    public static Module get(String name) {
        for (Module m : MODULES) if (m.name.equals(name)) return m;
        return null;
    }
}
