package com.ivisuals;

import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;

/**
 * "Hard optimization": one switch that drops the heavy video options to the minimum and puts
 * the old values back when it is switched off. The original values are also kept in the
 * config, so they come back even if the game was closed while the module was on.
 */
public final class Optimizer {
    private Optimizer() {}

    private static Setting level, lowerDistance;

    // saved originals
    private static boolean saved;
    private static int sView, sSim, sBlend;
    private static double sEntity;
    private static boolean sShadows, sBob;
    private static String sParticles = "ALL", sClouds = "FANCY", sGraphics = "FANCY";

    private static int appliedLevel = -1;
    private static boolean appliedDistance;

    // per level: view, simulation (min 5), blend, entity scale
    private static final int[] VIEW = {8, 6, 4};
    private static final int[] SIM = {8, 6, 5};
    private static final int[] BLEND = {1, 0, 0};
    private static final double[] ENTITY = {0.75, 0.5, 0.5};

    public static void setup(Module m) {
        level = m.mode("Level", 1, "Medium", "Hard", "Extreme");
        lowerDistance = m.toggle("Lower Render Distance", true);
    }

    private static void save(GameOptions o) {
        sView = o.getViewDistance().getValue();
        sSim = o.getSimulationDistance().getValue();
        sBlend = o.getBiomeBlendRadius().getValue();
        sEntity = o.getEntityDistanceScaling().getValue();
        sShadows = o.getEntityShadows().getValue();
        sBob = o.getBobView().getValue();
        sParticles = o.getParticles().getValue().name();
        sClouds = o.getCloudRenderMode().getValue().name();
        sGraphics = o.getPreset().getValue().name();
        saved = true;
        Config.save();
    }

    private static void apply(GameOptions o) {
        int lv = level.i();
        boolean dist = lowerDistance.b();
        o.getPreset().setValue(GraphicsMode.FAST);
        o.getParticles().setValue(lv == 0 ? ParticlesMode.DECREASED : ParticlesMode.MINIMAL);
        o.getEntityShadows().setValue(false);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getBiomeBlendRadius().setValue(BLEND[lv]);
        o.getEntityDistanceScaling().setValue(ENTITY[lv]);
        if (lv >= 1) o.getBobView().setValue(false);
        else o.getBobView().setValue(sBob);
        if (dist) {
            o.getViewDistance().setValue(Math.min(sView, VIEW[lv]));
            o.getSimulationDistance().setValue(Math.min(sSim, SIM[lv]));
        } else {
            o.getViewDistance().setValue(sView);
            o.getSimulationDistance().setValue(sSim);
        }
        appliedLevel = lv;
        appliedDistance = dist;
    }

    /** Called every tick while the module is on. */
    public static void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        GameOptions o = mc.options;
        if (!saved) save(o);
        if (appliedLevel != level.i() || appliedDistance != lowerDistance.b()) apply(o);
    }

    public static void disable(MinecraftClient mc) {
        appliedLevel = -1;
        if (!saved || mc == null || mc.options == null) return;
        GameOptions o = mc.options;
        try {
            o.getPreset().setValue(GraphicsMode.valueOf(sGraphics));
            o.getViewDistance().setValue(sView);
            o.getSimulationDistance().setValue(sSim);
            o.getBiomeBlendRadius().setValue(sBlend);
            o.getEntityDistanceScaling().setValue(sEntity);
            o.getEntityShadows().setValue(sShadows);
            o.getBobView().setValue(sBob);
            o.getParticles().setValue(ParticlesMode.valueOf(sParticles));
            o.getCloudRenderMode().setValue(CloudRenderMode.valueOf(sClouds));
            o.write();
        } catch (Throwable ignored) {}
        saved = false;
        Config.save();
    }

    // ---- persistence of the original values ----
    public static void saveTo(JsonObject root) {
        if (!saved) return;
        JsonObject o = new JsonObject();
        o.addProperty("view", sView);
        o.addProperty("sim", sSim);
        o.addProperty("blend", sBlend);
        o.addProperty("entity", sEntity);
        o.addProperty("shadows", sShadows);
        o.addProperty("bob", sBob);
        o.addProperty("particles", sParticles);
        o.addProperty("clouds", sClouds);
        o.addProperty("graphics", sGraphics);
        root.add("optimizerBackup", o);
    }

    public static void loadFrom(JsonObject root) {
        try {
            if (!root.has("optimizerBackup")) return;
            JsonObject o = root.getAsJsonObject("optimizerBackup");
            sView = o.get("view").getAsInt();
            sSim = o.get("sim").getAsInt();
            sBlend = o.get("blend").getAsInt();
            sEntity = o.get("entity").getAsDouble();
            sShadows = o.get("shadows").getAsBoolean();
            sBob = o.get("bob").getAsBoolean();
            sParticles = o.get("particles").getAsString();
            sClouds = o.get("clouds").getAsString();
            sGraphics = o.get("graphics").getAsString();
            saved = true;
        } catch (Exception ignored) {}
    }
}
