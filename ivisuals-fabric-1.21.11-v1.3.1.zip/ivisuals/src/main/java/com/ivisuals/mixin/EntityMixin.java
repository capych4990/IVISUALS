package com.ivisuals.mixin;

import com.ivisuals.HitHighlight;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    /** Hit Highlight: custom glow-outline color for entities you hit. */
    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true, require = 0)
    private void ivisuals$outlineColor(CallbackInfoReturnable<Integer> cir) {
        Integer c = HitHighlight.colorFor(((Entity) (Object) this).getId());
        if (c != null) cir.setReturnValue(c);
    }
}
