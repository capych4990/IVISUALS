package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.List;

public final class HudWidgets {
    private HudWidgets() {}

    public static final HudWidget INVENTORY = new InventoryWidget();
    public static final HudWidget ARMOR = new ArmorWidget();
    public static final List<HudWidget> ALL = List.of(INVENTORY, ARMOR);

    private static final int WHITE = 0xFFFFFF;

    private static void glass(DrawContext c, int w, int h) {
        Draw.roundRectV(c, 0, 0, w, h, 6, Draw.argb(170, 0x131316), Draw.argb(170, 0x070709));
        Draw.ring(c, 0, 0, w, h, 6, Draw.argb(120, WHITE), Draw.argb(30, WHITE));
    }

    // ------------------------------------------------------------------
    /** The 27 inner inventory slots (NOT the hotbar). */
    private static final class InventoryWidget extends HudWidget {
        private static ItemStack[] sample;

        InventoryWidget() { super("inventory", "Inventory", "Inventory HUD", 6, 6); }

        @Override public int w() { return 9 * 18 + 8; }
        @Override public int h() { return 3 * 18 + 8; }

        private static ItemStack[] sample() {
            if (sample == null) {
                sample = new ItemStack[27];
                java.util.Arrays.fill(sample, ItemStack.EMPTY);
                sample[0] = new ItemStack(Items.DIAMOND_PICKAXE);
                sample[1] = new ItemStack(Items.GOLDEN_APPLE, 5);
                sample[2] = new ItemStack(Items.COBBLESTONE, 64);
                sample[10] = new ItemStack(Items.ENDER_PEARL, 16);
                sample[13] = new ItemStack(Items.TORCH, 32);
                sample[20] = new ItemStack(Items.OAK_LOG, 48);
            }
            return sample;
        }

        @Override
        protected void content(DrawContext c, MinecraftClient mc) {
            glass(c, w(), h());
            for (int r = 0; r < 3; r++) {
                for (int col = 0; col < 9; col++) {
                    int sx = 4 + col * 18, sy = 4 + r * 18;
                    c.fill(sx + 1, sy + 1, sx + 17, sy + 17, Draw.argb(26, WHITE));
                    int idx = r * 9 + col;
                    ItemStack s = mc.player != null ? mc.player.getInventory().getStack(9 + idx) : sample()[idx];
                    if (s != null && !s.isEmpty()) {
                        c.drawItem(s, sx + 1, sy + 1);
                        c.drawStackOverlay(mc.textRenderer, s, sx + 1, sy + 1);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    /** Durability of the four armor pieces. */
    private static final class ArmorWidget extends HudWidget {
        private static final EquipmentSlot[] SLOTS =
                {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        private static ItemStack[] sample;

        ArmorWidget() { super("armor", "Armor", "Armor HUD", 6, 80); }

        @Override public int w() { return 118; }
        @Override public int h() { return 4 * 20 + 6; }

        private static ItemStack[] sample() {
            if (sample == null) {
                sample = new ItemStack[]{
                        new ItemStack(Items.DIAMOND_HELMET), new ItemStack(Items.DIAMOND_CHESTPLATE),
                        new ItemStack(Items.DIAMOND_LEGGINGS), new ItemStack(Items.DIAMOND_BOOTS)};
                sample[0].setDamage(40);
                sample[1].setDamage(300);
                sample[2].setDamage(150);
                sample[3].setDamage(20);
            }
            return sample;
        }

        private static int healthColor(float f) {
            int red = 0xFFE5484D, yellow = 0xFFF5C542, green = 0xFF46D369;
            return f > 0.5f ? Draw.lerp(yellow, green, (f - 0.5f) * 2f) : Draw.lerp(red, yellow, f * 2f);
        }

        @Override
        protected void content(DrawContext c, MinecraftClient mc) {
            glass(c, w(), h());
            int W = w();
            for (int i = 0; i < 4; i++) {
                int ry = 3 + i * 20;
                ItemStack s = mc.player != null ? mc.player.getEquippedStack(SLOTS[i]) : sample()[i];
                if (s == null || s.isEmpty()) {
                    c.drawText(mc.textRenderer, "-", 26, ry + 6, Draw.argb(90, WHITE), false);
                    continue;
                }
                c.drawItem(s, 4, ry + 2);
                if (s.isDamageable()) {
                    int max = s.getMaxDamage();
                    int left = Math.max(0, max - s.getDamage());
                    float f = max <= 0 ? 0f : (float) left / max;
                    int col = healthColor(f);
                    c.drawText(mc.textRenderer, left + "/" + max, 26, ry + 3, col, false);
                    String pct = Math.round(f * 100f) + "%";
                    c.drawText(mc.textRenderer, pct, W - 4 - mc.textRenderer.getWidth(pct), ry + 3,
                            Draw.argb(170, WHITE), false);
                    int bx = 26, bw = W - 4 - bx;
                    c.fill(bx, ry + 14, bx + bw, ry + 16, Draw.argb(50, WHITE));
                    c.fill(bx, ry + 14, bx + Math.max(1, Math.round(bw * f)), ry + 16, col);
                } else {
                    c.drawText(mc.textRenderer, "no durability", 26, ry + 6, Draw.argb(110, WHITE), false);
                }
            }
        }
    }
}
