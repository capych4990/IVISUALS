package com.ivisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class IVisualsClient implements ClientModInitializer {
    /** Menu key (Right Shift). */
    public static final int MENU_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private static boolean menuWasDown;

    @Override
    public void onInitializeClient() {
        Config.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() != null) {
                boolean down = InputUtil.isKeyPressed(client.getWindow(), MENU_KEY);
                if (down && !menuWasDown && client.currentScreen == null) client.setScreen(new MenuScreen());
                menuWasDown = down;
            }
            ModuleManager.tick(client);
        });

        // restore gamma etc. if the game is closed while Fullbright is on
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Fullbright.disable(client));

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of("ivisuals", "widgets"),
                (ctx, tickCounter) -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc.player == null || mc.options.hudHidden) return;
                    if (mc.currentScreen instanceof MenuScreen) return; // the editor draws them itself
                    int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
                    for (HudWidget w : HudWidgets.ALL) {
                        if (w.enabled()) w.draw(ctx, mc, sw, sh);
                    }
                });
    }
}
