package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import java.util.function.Consumer;

public class Module {
    public enum Category {
        VISUALS("Visuals"), PLAYER("Player"), HUD("HUD");
        public final String label;
        Category(String label) { this.label = label; }
    }

    public static final int NO_KEY = -1;

    public final String name;
    public final String description;
    public final Category category;
    public boolean enabled;

    /** GLFW key code, or NO_KEY. Set with Alt+Click on the card in the menu. */
    public int bind = NO_KEY;
    boolean bindWasDown;

    // animation state (0..1), used by the menu
    public float toggleAnim;
    public float hoverAnim;

    private Consumer<MinecraftClient> tickHandler;
    private Consumer<Boolean> toggleHandler;

    public Module(String name, Category category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }

    /** Called every client tick while the module is enabled. */
    public Module onTick(Consumer<MinecraftClient> handler) {
        this.tickHandler = handler;
        return this;
    }

    /** Called when the module is switched on or off. */
    public Module onToggle(Consumer<Boolean> handler) {
        this.toggleHandler = handler;
        return this;
    }

    /** Enabled by default (until a saved config says otherwise). */
    public Module defaultOn() {
        this.enabled = true;
        this.toggleAnim = 1f;
        return this;
    }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (toggleHandler != null) toggleHandler.accept(value);
    }

    /** Toggle from the menu / keybind and save to config. */
    public void toggle() {
        setEnabled(!enabled);
        Config.save();
    }

    void tick(MinecraftClient mc) {
        if (enabled && tickHandler != null) tickHandler.accept(mc);
    }
}
