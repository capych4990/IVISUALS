package com.ivisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;

public final class Draw {
    private Draw() {}

    public static int argb(int a, int rgb) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    public static int mulAlpha(int color, float m) {
        int a = (int) (((color >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, m)));
        return (a << 24) | (color & 0xFFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((c1 >>> 24) & 255) + ((((c2 >>> 24) & 255) - ((c1 >>> 24) & 255)) * t));
        int r = (int) (((c1 >> 16) & 255) + ((((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t));
        int g = (int) (((c1 >> 8) & 255) + ((((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t));
        int b = (int) ((c1 & 255) + (((c2 & 255) - (c1 & 255)) * t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Filled rounded rectangle (scanline corners). */
    public static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (((color >>> 24) & 255) == 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    /** Neon glow: stacked translucent rounded rects, draw BEFORE the solid shape. */
    public static void glow(DrawContext c, int x, int y, int w, int h, int r, int rgb, int layers, float strength) {
        for (int k = layers; k >= 1; k--) {
            int a = (int) (strength * 255f / layers);
            roundRect(c, x - k, y - k, w + k * 2, h + k * 2, r + k, argb(a, rgb));
        }
    }

    /** Solid rounded rect with 1px border. */
    public static void bordered(DrawContext c, int x, int y, int w, int h, int r, int fill, int border) {
        roundRect(c, x, y, w, h, r, border);
        roundRect(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    public static void text(DrawContext c, TextRenderer tr, String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 4) return;
        var m = c.getMatrices();
        m.push();
        m.translate(x, y, 0);
        m.scale(scale, scale, 1f);
        c.drawText(tr, s, 0, 0, color, false);
        m.pop();
    }

    public static int textWidth(TextRenderer tr, String s, float scale) {
        return (int) (tr.getWidth(s) * scale);
    }
}
