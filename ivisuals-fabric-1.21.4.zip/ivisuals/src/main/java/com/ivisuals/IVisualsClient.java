package com.ivisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class IVisualsClient implements ClientModInitializer {
    public static KeyBinding openMenu;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ivisuals.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "key.categories.ivisuals"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new MenuScreen());
            }
        });

        // Small neon HUD (works from the HUD tab toggles)
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;
            boolean fps = ModuleManager.isOn("FPS Counter");
            boolean pos = ModuleManager.isOn("Coordinates");
            if (!fps && !pos) return;

            String l1 = fps ? "FPS  " + mc.getCurrentFps() : null;
            String l2 = pos ? String.format("XYZ  %d  %d  %d",
                    mc.player.getBlockX(), mc.player.getBlockY(), mc.player.getBlockZ()) : null;
            int w = Math.max(l1 == null ? 0 : mc.textRenderer.getWidth(l1),
                             l2 == null ? 0 : mc.textRenderer.getWidth(l2)) + 14;
            int h = ((l1 != null ? 1 : 0) + (l2 != null ? 1 : 0)) * 11 + 8;
            int x = 6, y = 6;
            Draw.glow(ctx, x, y, w, h, 5, 0xFFFFFF, 4, 0.18f);
            Draw.bordered(ctx, x, y, w, h, 5, 0xE0050505, Draw.argb(200, 0xFFFFFF));
            int ty = y + 5;
            if (l1 != null) { ctx.drawText(mc.textRenderer, l1, x + 7, ty, 0xFFFFFFFF, false); ty += 11; }
            if (l2 != null) ctx.drawText(mc.textRenderer, l2, x + 7, ty, 0xFFFFFFFF, false);
        });
    }
}
