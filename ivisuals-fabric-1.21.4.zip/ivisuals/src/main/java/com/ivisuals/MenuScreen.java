package com.ivisuals;

import com.ivisuals.Module.Category;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class MenuScreen extends Screen {
    private static final int W = 380, H = 230, SIDE = 96, HEAD = 38;
    private static final int WHITE = 0xFFFFFF;
    private static final int PANEL = 0xFF050505;
    private static final int ROW = 0xFF0C0C0C;

    private final long openTime = System.currentTimeMillis();
    private long lastNano = System.nanoTime();
    private Category tab = Category.VISUALS;
    private float tabY = -1;

    public MenuScreen() {
        super(Text.literal("Ivisuals"));
    }

    @Override public boolean shouldPause() { return false; }

    private float openProgress() {
        float t = Math.min((System.currentTimeMillis() - openTime) / 380f, 1f);
        return 1f - (float) Math.pow(1f - t, 3);
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, Draw.argb((int) (150 * openProgress()), 0x000000));
    }

    private int panelX() { return (width - W) / 2; }
    private int panelY() { return (height - H) / 2; }
    private int tabTop(int i) { return panelY() + HEAD + 12 + i * 28; }
    private int rowY(int j) { return panelY() + HEAD + 12 + j * 30; }
    private int rowX() { return panelX() + SIDE + 12; }
    private int rowW() { return W - SIDE - 24; }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = Math.min((now - lastNano) / 1e9f, 0.05f);
        lastNano = now;
        float time = (System.currentTimeMillis() - openTime) / 1000f;
        float e = openProgress();

        super.render(c, mx, my, delta);

        int px = panelX(), py = panelY();
        var m = c.getMatrices();
        m.push();
        float s = 0.90f + 0.10f * e;
        m.translate(width / 2f, height / 2f, 0);
        m.scale(s, s, 1f);
        m.translate(-width / 2f, -height / 2f, 0);

        // pulsing neon glow
        float pulse = 0.22f + 0.10f * (float) Math.sin(time * 2.2f);
        Draw.glow(c, px, py, W, H, 10, WHITE, 9, pulse * e);

        // panel + border
        Draw.bordered(c, px, py, W, H, 10, Draw.mulAlpha(PANEL, e),
                Draw.argb((int) (190 * e), WHITE));

        // floating particles
        for (int i = 0; i < 36; i++) {
            float speed = 8f + (i * 7 % 13);
            float x = px + 6 + ((i * 53) % (W - 12));
            float y = py + H - 4 - ((time * speed + i * 37) % (H - 8));
            float tw = 0.5f + 0.5f * (float) Math.sin(time * 3f + i);
            c.fill((int) x, (int) y, (int) x + 1, (int) y + 1, Draw.argb((int) (90 * tw * e), WHITE));
        }

        // title with glow
        String title = "IVISUALS";
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
                if (dx != 0 || dy != 0)
                    Draw.text(c, textRenderer, title, px + 16 + dx, py + 12 + dy, 1.7f, Draw.argb((int) (28 * e), WHITE));
        Draw.text(c, textRenderer, title, px + 16, py + 12, 1.7f, Draw.argb((int) (255 * e), WHITE));
        Draw.text(c, textRenderer, "v1.0", px + W - 34, py + 16, 0.9f, Draw.argb((int) (120 * e), WHITE));

        // header separator + scanning light
        c.fill(px + 10, py + HEAD, px + W - 10, py + HEAD + 1, Draw.argb((int) (40 * e), WHITE));
        float scan = ((time * 0.55f) % 1f);
        int sx = px + 10 + (int) (scan * (W - 20));
        for (int i = -34; i <= 34; i++) {
            int xx = sx + i;
            if (xx < px + 10 || xx >= px + W - 10) continue;
            float f = 1f - Math.abs(i) / 34f;
            c.fill(xx, py + HEAD, xx + 1, py + HEAD + 1, Draw.argb((int) (230 * f * f * e), WHITE));
        }

        // sidebar divider
        c.fill(px + SIDE, py + HEAD + 8, px + SIDE + 1, py + H - 12, Draw.argb((int) (35 * e), WHITE));

        // tabs
        Category[] cats = Category.values();
        int selIdx = tab.ordinal();
        float target = tabTop(selIdx);
        if (tabY < 0) tabY = target;
        tabY += (target - tabY) * Math.min(1f, dt * 14f);

        Draw.roundRect(c, px + 8, (int) tabY - 2, SIDE - 16, 22, 5, Draw.argb((int) (22 * e), WHITE));
        Draw.glow(c, px + 8, (int) tabY, 3, 18, 1, WHITE, 4, 0.5f * e);
        Draw.roundRect(c, px + 8, (int) tabY, 3, 18, 1, Draw.argb((int) (255 * e), WHITE));

        for (int i = 0; i < cats.length; i++) {
            boolean sel = i == selIdx;
            int col = sel ? Draw.argb((int) (255 * e), WHITE) : Draw.argb((int) (130 * e), WHITE);
            Draw.text(c, textRenderer, cats[i].label, px + 20, tabTop(i) + 4, 1.0f, col);
        }

        // modules
        List<Module> list = ModuleManager.of(tab);
        for (int j = 0; j < list.size(); j++) {
            Module mod = list.get(j);
            int rx = rowX(), ry = rowY(j), rw = rowW(), rh = 24;

            boolean hov = mx >= rx && mx <= rx + rw && my >= ry && my <= ry + rh;
            mod.hoverAnim += ((hov ? 1f : 0f) - mod.hoverAnim) * Math.min(1f, dt * 12f);
            mod.toggleAnim += ((mod.enabled ? 1f : 0f) - mod.toggleAnim) * Math.min(1f, dt * 11f);

            // row appear animation (staggered)
            float ra = Math.max(0f, Math.min(1f, (e * 1.4f) - j * 0.12f));
            int slide = (int) ((1f - ra) * 10f);
            rx += slide;

            float ta = mod.toggleAnim;
            if (ta > 0.02f) Draw.glow(c, rx, ry, rw, rh, 6, WHITE, 5, 0.16f * ta * ra);

            int border = Draw.lerp(Draw.argb(60, WHITE), Draw.argb(235, WHITE), Math.max(ta, mod.hoverAnim * 0.6f));
            Draw.bordered(c, rx, ry, rw, rh, 6, Draw.mulAlpha(ROW, ra), Draw.mulAlpha(border, ra));
            Draw.roundRect(c, rx + 1, ry + 1, rw - 2, rh - 2, 5, Draw.argb((int) (22 * mod.hoverAnim * ra), WHITE));

            int tcol = Draw.lerp(Draw.argb(170, WHITE), Draw.argb(255, WHITE), Math.max(ta, mod.hoverAnim));
            Draw.text(c, textRenderer, mod.name, rx + 10, ry + 8, 1.0f, Draw.mulAlpha(tcol, ra));

            // toggle switch
            int sw = 30, sh = 12;
            int sxw = rx + rw - sw - 10, syw = ry + (rh - sh) / 2;
            if (ta > 0.02f) Draw.glow(c, sxw, syw, sw, sh, 6, WHITE, 5, 0.35f * ta * ra);
            int track = Draw.lerp(Draw.argb(255, 0x1A1A1A), Draw.argb(255, WHITE), ta);
            Draw.roundRect(c, sxw, syw, sw, sh, 6, Draw.mulAlpha(track, ra));
            int knobX = (int) (sxw + 2 + (sw - 12) * ta);
            int knob = Draw.lerp(Draw.argb(255, 0x8A8A8A), Draw.argb(255, 0x000000), ta);
            Draw.roundRect(c, knobX, syw + 2, 8, 8, 4, Draw.mulAlpha(knob, ra));
        }

        // footer
        Draw.text(c, textRenderer, "RSHIFT  close", px + 14, py + H - 14, 0.75f, Draw.argb((int) (90 * e), WHITE));

        m.pop();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                int ty = tabTop(i);
                if (mx >= panelX() + 8 && mx <= panelX() + SIDE - 8 && my >= ty - 2 && my <= ty + 20) {
                    tab = cats[i];
                    return true;
                }
            }
            List<Module> list = ModuleManager.of(tab);
            for (int j = 0; j < list.size(); j++) {
                int rx = rowX(), ry = rowY(j);
                if (mx >= rx && mx <= rx + rowW() && my >= ry && my <= ry + 24) {
                    list.get(j).enabled = !list.get(j).enabled;
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
