package com.ivisuals;

public class Module {
    public enum Category {
        VISUALS("VISUALS"), WORLD("WORLD"), HUD("HUD");
        public final String label;
        Category(String label) { this.label = label; }
    }

    public final String name;
    public final Category category;
    public boolean enabled;

    // animation state (0..1)
    public float toggleAnim;
    public float hoverAnim;

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }
}
