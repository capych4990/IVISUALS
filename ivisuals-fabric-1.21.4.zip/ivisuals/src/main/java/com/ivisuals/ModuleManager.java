package com.ivisuals;

import com.ivisuals.Module.Category;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();

    static {
        // VISUALS
        add("Fullbright", Category.VISUALS);
        add("Zoom", Category.VISUALS);
        add("Hit Color", Category.VISUALS);
        add("Particles Boost", Category.VISUALS);
        // WORLD
        add("Clear Weather", Category.WORLD);
        add("Time Changer", Category.WORLD);
        add("Custom Sky", Category.WORLD);
        // HUD
        add("FPS Counter", Category.HUD);
        add("Coordinates", Category.HUD);
        add("Keystrokes", Category.HUD);
    }

    private static void add(String name, Category cat) {
        MODULES.add(new Module(name, cat));
    }

    public static List<Module> of(Category cat) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) if (m.category == cat) out.add(m);
        return out;
    }

    /** Use this from your mixins/hooks: ModuleManager.isOn("Fullbright") */
    public static boolean isOn(String name) {
        for (Module m : MODULES) if (m.name.equals(name)) return m.enabled;
        return false;
    }
}
