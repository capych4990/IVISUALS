package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;

/**
 * Held Glow: a custom neon glow around the item in your hand (first person). It is drawn as an overlay at the spot
 * where the item sits on the screen (it follows Hand Tweaks), so use Size / Offset to fit it to your item.
 */
public final class HeldGlow {
    private HeldGlow() {}

    private static Setting style, color, size, opacity, offX, offY, mainHand, offHand, pulse;

    public static void setup(Module m) {
        style = m.mode("Style", 0, "Aura", "Ring", "Sparks");
        color = m.mode("Color", 9, Fx.COLORS);
        size = m.slider("Size", 1f, 0.3f, 3f, 0.05f);
        opacity = m.slider("Opacity", 0.8f, 0.1f, 1f, 0.05f);
        pulse = m.toggle("Pulse", true);
        mainHand = m.toggle("Main Hand", true);
        offHand = m.toggle("Off Hand", false);
        offX = m.slider("Offset X", 0f, -80f, 80f, 1f);
        offY = m.slider("Offset Y", 0f, -80f, 80f, 1f);
    }

    public static void render(DrawContext ctx, MinecraftClient mc, float tp) {
        if (!ModuleManager.HELD_GLOW.enabled || mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) return;
        Proj cam = HudFx.camera(mc, tp);
        if (cam == null) return;
        Arm mainArm = mc.player.getMainArm();
        if (mainHand.b()) one(ctx, cam, mc.player.getMainHandStack(), true, mainArm == Arm.RIGHT ? 1 : -1);
        if (offHand.b()) one(ctx, cam, mc.player.getOffHandStack(), false, mainArm == Arm.RIGHT ? -1 : 1);
    }

    private static void one(DrawContext ctx, Proj cam, ItemStack stack, boolean main, int side) {
        if (stack == null || stack.isEmpty()) return;
        float[] o = HandTweaks.offset(main);
        // vanilla spot of the held item in camera space (right, up, forward), moved like Hand Tweaks moves it
        double fwd = Math.max(0.25, 0.80 - o[2]);
        double[] sc = cam.screen(new double[]{0.50 * side + o[0], -0.36 + o[1], fwd});
        double cx = sc[0] + offX.f(), cy = sc[1] - offY.f();
        double r = 0.26 * size.f() * o[3] / fwd * cam.focal;
        if (r < 4) return;

        float t = HudFx.time();
        float a = opacity.f() * (pulse.b() ? 0.75f + 0.25f * (float) Math.sin(t * 3.2f) : 1f);
        int mode = color.i();
        Canvas cv = HudFx.canvas(ctx);
        switch (style.i()) {
            case 0 -> aura(ctx, cx, cy, r, mode, t, a);
            case 1 -> ring(cv, cam, cx, cy, r, mode, t, a);
            default -> sparks(cv, cx, cy, r, mode, t, a);
        }
    }

    /** Soft halo: concentric thin rings fading outwards + a bright inner ring. */
    private static void aura(DrawContext ctx, double cx, double cy, double r, int mode, float t, float a) {
        int layers = 7;
        for (int k = layers; k >= 0; k--) {
            double rr = r * (1.0 + k * 0.07);
            float f = 1f - (float) k / (layers + 1);
            int rgb = Fx.color(mode, t, k * 0.05f);
            int d = (int) Math.round(rr * 2);
            Draw.ring(ctx, (int) Math.round(cx - rr), (int) Math.round(cy - rr), d, d, (int) Math.round(rr),
                    Draw.argb((int) (150 * a * f * f), rgb), Draw.argb((int) (150 * a * f * f), rgb));
        }
        int rgb = Fx.color(mode, t, 0f);
        int d = (int) Math.round(r * 2);
        Draw.ring(ctx, (int) Math.round(cx - r), (int) Math.round(cy - r), d, d, (int) Math.round(r),
                Draw.argb((int) (255 * a), rgb), Draw.argb((int) (255 * a), rgb));
    }

    /** Rotating dashed ring. */
    private static void ring(Canvas cv, Proj cam, double cx, double cy, double r, int mode, float t, float a) {
        int n = 28;
        double spin = t * 1.1;
        for (int i = 0; i < n; i++) {
            double a0 = spin + i * (Math.PI * 2 / n), a1 = a0 + Math.PI * 2 / n * 0.62;
            int rgb = Fx.color(mode, t, i / (float) n);
            Fx.line(cv, cam.sw, cam.sh, cx + Math.cos(a0) * r, cy + Math.sin(a0) * r,
                    cx + Math.cos(a1) * r, cy + Math.sin(a1) * r, 2, Fx.withAlpha(rgb, a));
            Fx.line(cv, cam.sw, cam.sh, cx + Math.cos(a0 + Math.PI) * r * 1.12, cy + Math.sin(a0 + Math.PI) * r * 1.12,
                    cx + Math.cos(a1 + Math.PI) * r * 1.12, cy + Math.sin(a1 + Math.PI) * r * 1.12, 1,
                    Fx.withAlpha(rgb, a * 0.5f));
        }
    }

    /** Little sparkles orbiting / rising around the item. */
    private static void sparks(Canvas cv, double cx, double cy, double r, int mode, float t, float a) {
        int n = 16;
        for (int i = 0; i < n; i++) {
            double ph = i * 0.6180339 * 6.2831853;
            double life = (t * 0.45 + i / (double) n) % 1.0;
            double ang = ph + t * (0.6 + (i % 3) * 0.2);
            double rad = r * (0.55 + 0.55 * Math.abs(Math.sin(ph))) ;
            double x = cx + Math.cos(ang) * rad, y = cy + Math.sin(ang) * rad * 0.9 - life * r * 0.35;
            float tw = (float) Math.sin(life * Math.PI);
            int s = 1 + (i % 3 == 0 ? 1 : 0);
            int rgb = Fx.color(mode, t, i / (float) n);
            int px = (int) Math.round(x), py = (int) Math.round(y);
            cv.fill(px - s, py, px + s + 1, py + 1, Fx.withAlpha(rgb, a * tw));
            cv.fill(px, py - s, px + 1, py + s + 1, Fx.withAlpha(rgb, a * tw));
        }
    }
}
