package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** The entity you hit glows (in a color you pick) for a set time. Players / mobs / both. */
public final class HitHighlight {
    private HitHighlight() {}

    private static final class Rec {
        long end;
        boolean wasGlowing;
    }

    private static final Map<Integer, Rec> ACTIVE = new HashMap<>();
    private static Setting targets, duration, color, blink;

    public static void setup(Module m) {
        targets = m.mode("Targets", 2, "Players", "Mobs", "Players + Mobs");
        duration = m.slider("Duration (s)", 3f, 0.5f, 15f, 0.5f);
        color = m.mode("Color", 0, Fx.COLORS);
        blink = m.toggle("Blink at end", true);
    }

    private static boolean accepts(Entity e) {
        int t = targets.i();
        if (e instanceof PlayerEntity) return t == 0 || t == 2;
        if (e instanceof LivingEntity) return t == 1 || t == 2;
        return false;
    }

    public static void onAttack(Entity e) {
        if (!ModuleManager.HIT_HIGHLIGHT.enabled || e == null || !accepts(e)) return;
        Rec r = ACTIVE.get(e.getId());
        if (r == null) {
            r = new Rec();
            r.wasGlowing = e.isGlowing();
            ACTIVE.put(e.getId(), r);
        }
        r.end = System.currentTimeMillis() + (long) (duration.f() * 1000f);
        e.setGlowing(true);
    }

    /** Outline color for the render hook (RGB) or null when the entity is not highlighted. */
    public static Integer colorFor(int entityId) {
        if (ACTIVE.isEmpty() || !ACTIVE.containsKey(entityId)) return null;
        return Fx.color(color.i(), HudFx.time(), (entityId % 7) / 7f);
    }

    public static void tick(MinecraftClient mc) {
        if (ACTIVE.isEmpty() || mc.world == null) return;
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<Integer, Rec>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Rec> en = it.next();
            Entity e = mc.world.getEntityById(en.getKey());
            Rec r = en.getValue();
            long left = r.end - now;
            if (e == null || !e.isAlive() || left <= 0) {
                if (e != null) e.setGlowing(r.wasGlowing);
                it.remove();
                continue;
            }
            boolean on = true;
            if (blink.b() && left < 700) on = ((now / 90) % 2) == 0;
            e.setGlowing(on || r.wasGlowing);
        }
    }

    /** Remove every highlight (module switched off / world left). */
    public static void clear(MinecraftClient mc) {
        if (mc != null && mc.world != null) {
            for (Map.Entry<Integer, Rec> en : ACTIVE.entrySet()) {
                Entity e = mc.world.getEntityById(en.getKey());
                if (e != null) e.setGlowing(en.getValue().wasGlowing);
            }
        }
        ACTIVE.clear();
    }
}
