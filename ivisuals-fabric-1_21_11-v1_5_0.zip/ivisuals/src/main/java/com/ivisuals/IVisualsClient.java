package com.ivisuals;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class IVisualsClient implements ClientModInitializer {
    /** Menu key (Right Shift). */
    public static final int MENU_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private static boolean menuWasDown;

    @Override
    public void onInitializeClient() {
        Config.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.getWindow() != null) {
                boolean down = InputUtil.isKeyPressed(client.getWindow(), MENU_KEY);
                if (down && !menuWasDown && client.currentScreen == null) client.setScreen(new MenuScreen());
                menuWasDown = down;
            }
            ModuleManager.tick(client);
        });

        // startup screen: fade our loading picture out over whatever screen comes first
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) ->
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> LoadingFx.afterScreen(ctx)));

        // restore gamma / video options if the game is closed while Fullbright / Optimizer is on
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            Fullbright.disable(client);
            if (ModuleManager.OPTIMIZER.enabled) Optimizer.disable(client);
        });

        // hit effects: only for attacks made by the local player (ignore the integrated server's copy)
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player == mc.player) {
                HitParticles.onAttack(mc, entity);
                HitHighlight.onAttack(entity);
            }
            return ActionResult.PASS;
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of("ivisuals", "widgets"),
                (ctx, tickCounter) -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc.player == null || mc.options.hudHidden) return;
                    float tp = tickCounter.getTickProgress(false);
                    BlockHighlight.render(ctx, mc, tp);
                    Trajectories.render(ctx, mc, tp);
                    LowFire.render(ctx, mc, tp);
                    HitParticles.render(ctx, mc, tp);
                    ItemEsp.render(ctx, mc, tp);
                    HeldGlow.render(ctx, mc, tp);
                    if (mc.currentScreen instanceof MenuScreen) return; // the editor draws them itself
                    int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
                    for (HudWidget w : HudWidgets.ALL) {
                        if (w.enabled()) w.draw(ctx, mc, sw, sh);
                    }
                });
    }
}
