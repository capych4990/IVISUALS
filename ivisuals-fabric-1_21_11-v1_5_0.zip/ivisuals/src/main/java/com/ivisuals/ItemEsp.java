package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Item ESP: items lying on the ground get a glowing outline of their own texture (the vanilla glow outline, in a
 * color you pick) and their name + count floating above them.
 */
public final class ItemEsp {
    private ItemEsp() {}

    private static Setting glow, names, count, range, color, scale, background;
    private static final Set<Integer> GLOWING = new HashSet<>();
    private static World lastWorld;

    public static void setup(Module m) {
        glow = m.toggle("Glow Outline", true);
        color = m.mode("Glow Color", 9, Fx.COLORS);
        names = m.toggle("Names", true);
        count = m.toggle("Show Count", true);
        background = m.toggle("Name Background", true);
        scale = m.slider("Name Size", 0.85f, 0.5f, 1.8f, 0.05f);
        range = m.slider("Range", 32f, 8f, 96f, 4f);
    }

    /** Outline color (RGB) for the render hook, or null when this entity is not one of ours. */
    public static Integer colorFor(int entityId) {
        if (GLOWING.isEmpty() || !GLOWING.contains(entityId)) return null;
        return Fx.color(color.i(), HudFx.time(), (entityId % 7) / 7f);
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { GLOWING.clear(); lastWorld = null; return; }
        if (mc.world != lastWorld) { GLOWING.clear(); lastWorld = mc.world; }

        double r = range.f();
        double r2 = r * r;
        Set<Integer> seen = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity) || e.isRemoved()) continue;
            int id = e.getId();
            boolean near = mc.player.squaredDistanceTo(e.getX(), e.getY(), e.getZ()) <= r2;
            if (near && glow.b()) {
                e.setGlowing(true);
                GLOWING.add(id);
                seen.add(id);
            }
        }
        // anything we made glow that is no longer wanted (too far, picked up, glow switched off)
        Iterator<Integer> it = GLOWING.iterator();
        while (it.hasNext()) {
            int id = it.next();
            if (seen.contains(id)) continue;
            Entity e = mc.world.getEntityById(id);
            if (e != null) e.setGlowing(false);
            it.remove();
        }
    }

    /** Remove all outlines (module switched off). */
    public static void clear(MinecraftClient mc) {
        if (mc != null && mc.world != null) {
            for (int id : GLOWING) {
                Entity e = mc.world.getEntityById(id);
                if (e instanceof ItemEntity) e.setGlowing(false);
            }
        }
        GLOWING.clear();
    }

    // ------------------------------------------------------------------ names

    public static void render(DrawContext ctx, MinecraftClient mc, float tp) {
        if (!ModuleManager.ITEM_ESP.enabled || !names.b() || mc.world == null || mc.player == null) return;
        Proj cam = HudFx.camera(mc, tp);
        if (cam == null) return;

        double r = range.f();
        double r2 = r * r;
        float t = HudFx.time();
        int shown = 0;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity ie) || e.isRemoved()) continue;
            double d2 = mc.player.squaredDistanceTo(e.getX(), e.getY(), e.getZ());
            if (d2 > r2) continue;
            ItemStack st = ie.getStack();
            if (st == null || st.isEmpty()) continue;

            Vec3d v = e.getVelocity();
            double x = e.getX() - v.x * (1 - tp), y = e.getY() - v.y * (1 - tp), z = e.getZ() - v.z * (1 - tp);
            double[] sc = cam.project(x, y + 0.62, z);
            if (sc == null || sc[0] < -80 || sc[0] > cam.sw + 80 || sc[1] < -20 || sc[1] > cam.sh + 20) continue;

            double dist = Math.sqrt(d2);
            float fade = (float) Math.max(0.25, 1.0 - Math.max(0.0, dist - r * 0.6) / (r * 0.4));
            float sz = scale.f() * (float) Math.max(0.6, 1.25 - dist / Math.max(1.0, r) * 0.9);

            String s = st.getName().getString();
            if (count.b() && st.getCount() > 1) s += " x" + st.getCount();
            drawName(ctx, mc, s, (float) sc[0], (float) sc[1], sz, fade, Fx.color(color.i(), t, (e.getId() % 7) / 7f));
            if (++shown >= 80) break;
        }
    }

    private static void drawName(DrawContext ctx, MinecraftClient mc, String s, float cx, float by, float sz,
                                 float alpha, int rgb) {
        int tw = Draw.textWidth(mc.textRenderer, s, sz);
        int th = Math.max(6, Math.round(8f * sz));
        int padX = 4, padY = 2;
        int w = tw + padX * 2, h = th + padY * 2;
        int x = Math.round(cx - w / 2f), y = Math.round(by - h - 3);

        if (background.b()) {
            Draw.roundRect(ctx, x, y, w, h, 4, Draw.argb((int) (165 * alpha), 0x0A0A0C));
            Draw.ring(ctx, x, y, w, h, 4, Draw.argb((int) (230 * alpha), rgb), Draw.argb((int) (110 * alpha), rgb));
        }
        Draw.text(ctx, mc.textRenderer, s, x + padX, y + padY, sz, Draw.argb((int) (255 * alpha), 0xFFFFFF));
        // little marker where the name points to
        int mx = Math.round(cx);
        ctx.fill(mx - 1, y + h + 1, mx + 1, y + h + 3, Draw.argb((int) (230 * alpha), rgb));
    }
}
