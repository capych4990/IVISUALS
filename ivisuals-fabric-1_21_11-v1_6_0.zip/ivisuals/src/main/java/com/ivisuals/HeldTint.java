package com.ivisuals;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.List;

/**
 * Held Tint: the item in your hand (first person) gets a see-through color coat that follows the real model of the
 * item (not a circle). It is the same model drawn a second time, a hair bigger, with a flat translucent texture
 * (assets/ivisuals/textures/held/c{color}_a{opacity}.png, made by tools/gen_held_tints.py).
 *
 * The ItemRenderState internals are reached by field TYPE (not by name), so it works with any mappings. If the game
 * layout is different from what is expected the feature switches itself off instead of crashing.
 */
public final class HeldTint {
    private HeldTint() {}

    private static final int NC = 25;                   // 24 hues + white
    private static final float[] ALPHA_LEVELS = {0.25f, 0.40f, 0.60f, 0.80f};
    private static final int FULL_LIGHT = 0xF000F0;

    private static Setting color, opacity, expand, pulse, mainHand, offHand;

    // render context, set by HeldItemRendererMixin around renderFirstPersonItem
    private static MatrixStack curMatrices;
    private static OrderedRenderCommandQueue curQueue;
    private static boolean curMain;
    private static boolean busy, failed;

    // reflection cache
    private static Field stateF, layersF, countF, layerRenderLayerF, layerQuadsF;
    private static Method renderM;
    private static final RenderLayer[][] LAYERS = new RenderLayer[NC][ALPHA_LEVELS.length];

    public static void setup(Module m) {
        color = m.mode("Color", 0, Fx.COLORS);
        opacity = m.slider("Opacity", 0.4f, 0.25f, 0.8f, 0.05f);
        pulse = m.toggle("Pulse", true);
        expand = m.slider("Expand", 1.03f, 1.0f, 1.2f, 0.01f);
        mainHand = m.toggle("Main Hand", true);
        offHand = m.toggle("Off Hand", false);
    }

    // ------------------------------------------------------------------ mixin hooks

    public static void begin(MatrixStack m, OrderedRenderCommandQueue q, boolean main) {
        curMatrices = m;
        curQueue = q;
        curMain = main;
    }

    public static void end() {
        curMatrices = null;
        curQueue = null;
    }

    /** Called right after the vanilla code queued the held item; the matrix stack still holds the item transform. */
    public static void afterItem(Object heldItemRenderer) {
        if (busy || failed || curMatrices == null || !ModuleManager.HELD_TINT.enabled) return;
        if (curMain ? !mainHand.b() : !offHand.b()) return;
        busy = true;
        RenderLayer[] saved = null;
        Object[] layers = null;
        Object state = null;
        try {
            if (stateF == null && !init(heldItemRenderer)) { failed = true; return; }
            state = stateF.get(heldItemRenderer);
            layers = (Object[]) layersF.get(state);
            int n = countF.getInt(state);
            if (n <= 0 || n > layers.length) return;
            // special models (shield, trident, banner...) have no plain quads: leave them alone
            if (layerQuadsF != null) {
                for (int i = 0; i < n; i++) {
                    Object q = layerQuadsF.get(layers[i]);
                    if (q instanceof List<?> l && l.isEmpty()) return;
                }
            }
            RenderLayer coat = coat();
            if (coat == null) return;
            saved = new RenderLayer[n];
            for (int i = 0; i < n; i++) {
                saved[i] = (RenderLayer) layerRenderLayerF.get(layers[i]);
                layerRenderLayerF.set(layers[i], coat);
            }
            float s = expand.f();
            curMatrices.push();
            curMatrices.scale(s, s, s);
            renderM.invoke(state, curMatrices, curQueue, FULL_LIGHT, OverlayTexture.DEFAULT_UV, 0);
            curMatrices.pop();
        } catch (Throwable t) {
            failed = true;
            System.err.println("[ivisuals] Held Tint disabled: " + t);
        } finally {
            if (saved != null && layers != null) {
                try {
                    for (int i = 0; i < saved.length; i++) layerRenderLayerF.set(layers[i], saved[i]);
                } catch (Throwable ignored) {}
            }
            busy = false;
        }
    }

    // ------------------------------------------------------------------ colors

    private static RenderLayer coat() {
        float t = HudFx.time();
        int rgb = Fx.color(color.i(), t, 0f);
        int ci = colorIndex(rgb);
        float op = opacity.f();
        if (pulse.b()) op += 0.12f * (float) Math.sin(t * 3.0f);
        int ai = 0;
        float best = 9f;
        for (int i = 0; i < ALPHA_LEVELS.length; i++) {
            float d = Math.abs(ALPHA_LEVELS[i] - op);
            if (d < best) { best = d; ai = i; }
        }
        RenderLayer l = LAYERS[ci][ai];
        if (l == null) {
            l = RenderLayer.getEntityTranslucent(Identifier.of("ivisuals", "textures/held/c" + ci + "_a" + ai + ".png"));
            LAYERS[ci][ai] = l;
        }
        return l;
    }

    /** Nearest of the 24 hue textures (or white for pale colors). */
    static int colorIndex(int rgb) {
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        if (max <= 0f || d / max < 0.22f) return 24;
        float h;
        if (d == 0) h = 0;
        else if (max == r) h = ((g - b) / d) % 6f;
        else if (max == g) h = (b - r) / d + 2f;
        else h = (r - g) / d + 4f;
        h /= 6f;
        if (h < 0) h += 1f;
        return Math.round(h * 24f) % 24;
    }

    // ------------------------------------------------------------------ reflection (by type, not by name)

    private static boolean init(Object renderer) throws Exception {
        for (Field f : renderer.getClass().getDeclaredFields()) {
            if (f.getType() == ItemRenderState.class && !Modifier.isStatic(f.getModifiers())) { stateF = f; break; }
        }
        if (stateF == null) return fail("no ItemRenderState field");
        stateF.setAccessible(true);

        for (Field f : ItemRenderState.class.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            if (f.getType().isArray() && !f.getType().getComponentType().isPrimitive()) layersF = f;
            else if (f.getType() == int.class) {
                if (countF != null) return fail("more than one int field");
                countF = f;
            }
        }
        if (layersF == null || countF == null) return fail("layers / count not found");
        layersF.setAccessible(true);
        countF.setAccessible(true);

        Class<?> layerCls = layersF.getType().getComponentType();
        for (Field f : layerCls.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers())) continue;
            if (f.getType() == RenderLayer.class) layerRenderLayerF = f;
            else if (f.getType() == List.class && layerQuadsF == null) layerQuadsF = f;
        }
        if (layerRenderLayerF == null) return fail("layer RenderLayer field not found");
        layerRenderLayerF.setAccessible(true);
        if (layerQuadsF != null) layerQuadsF.setAccessible(true);

        for (Method m : ItemRenderState.class.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (p.length == 5 && p[0] == MatrixStack.class && p[1] == OrderedRenderCommandQueue.class
                    && p[2] == int.class && p[3] == int.class && p[4] == int.class) {
                renderM = m;
                break;
            }
        }
        if (renderM == null) return fail("render method not found");
        renderM.setAccessible(true);
        return true;
    }

    private static boolean fail(String why) {
        System.err.println("[ivisuals] Held Tint can not start: " + why);
        return false;
    }
}
