package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Quick Swap: press the key you bound to the module (Alt on its card, then the key) and the chosen item jumps into
 * your hand. Done with the same inventory "swap" click the game itself uses, so no mouse / screen is needed:
 *  - item is in the hotbar: that hotbar slot is selected
 *  - item is in the inventory: it is swapped with the slot in your hand (hand empty = it just moves there,
 *    hand busy = the two items change places)
 */
public final class QuickSwap {
    private QuickSwap() {}

    public static final String[] ITEMS = {
            "Ender Pearl", "Golden Apple", "Ench. Golden Apple", "Totem of Undying", "Shield", "Firework Rocket",
            "Water Bucket", "Cobweb", "Obsidian", "End Crystal", "Splash Potion", "Wind Charge", "XP Bottle",
            "Chorus Fruit", "Mace", "Elytra"};

    private static Item item(int i) {
        return switch (i) {
            case 0 -> Items.ENDER_PEARL;
            case 1 -> Items.GOLDEN_APPLE;
            case 2 -> Items.ENCHANTED_GOLDEN_APPLE;
            case 3 -> Items.TOTEM_OF_UNDYING;
            case 4 -> Items.SHIELD;
            case 5 -> Items.FIREWORK_ROCKET;
            case 6 -> Items.WATER_BUCKET;
            case 7 -> Items.COBWEB;
            case 8 -> Items.OBSIDIAN;
            case 9 -> Items.END_CRYSTAL;
            case 10 -> Items.SPLASH_POTION;
            case 11 -> Items.WIND_CHARGE;
            case 12 -> Items.EXPERIENCE_BOTTLE;
            case 13 -> Items.CHORUS_FRUIT;
            case 14 -> Items.MACE;
            default -> Items.ELYTRA;
        };
    }

    private static final class Slot {
        Setting item, hand;
    }

    private static final Slot[] SLOTS = {new Slot(), new Slot(), new Slot()};

    public static void setup(Module m, int index) {
        Slot s = SLOTS[index];
        int[] def = {0, 1, 3};
        s.item = m.mode("Item", def[index], ITEMS);
        s.hand = m.mode("Into", index == 2 ? 1 : 0, "Main Hand", "Off Hand");
    }

    public static void press(MinecraftClient mc, int index) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        Slot s = SLOTS[index];
        Item want = item(s.item.i());
        boolean off = s.hand.i() == 1;
        if (off ? p.getOffHandStack().isOf(want) : p.getMainHandStack().isOf(want)) return;

        PlayerInventory inv = p.getInventory();
        int found = -1;                                    // hotbar first (0-8), then the inventory (9-35)
        for (int i = 0; i < 36 && found < 0; i++) if (inv.getStack(i).isOf(want)) found = i;
        if (found < 0) return;

        int syncId = p.playerScreenHandler.syncId;
        if (!off) {
            if (found < 9) {
                inv.setSelectedSlot(found);
            } else {
                // inventory slot <-> the hotbar slot that is in your hand
                mc.interactionManager.clickSlot(syncId, found, inv.getSelectedSlot(), SlotActionType.SWAP, p);
            }
        } else {
            int slotId = found < 9 ? 36 + found : found;   // hotbar slots are 36-44 in the inventory screen handler
            mc.interactionManager.clickSlot(syncId, slotId, 40, SlotActionType.SWAP, p);   // 40 = off hand
        }
    }
}
