package com.ivisuals.mixin;

import com.ivisuals.HitHighlight;
import com.ivisuals.ItemEsp;
import com.ivisuals.LowFire;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    /** Hit Highlight: custom glow-outline color for entities you hit. */
    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true, require = 0)
    private void ivisuals$outlineColor(CallbackInfoReturnable<Integer> cir) {
        int id = ((Entity) (Object) this).getId();
        Integer c = HitHighlight.colorFor(id);
        if (c == null) c = ItemEsp.colorFor(id);          // Item ESP: outline color of dropped items
        if (c != null) cir.setReturnValue(c);
    }

    /**
     * Hit Highlight / Item ESP: the vanilla glow flag can not be set from the client (the server owns it), so the
     * client simply answers "yes, glowing" for the entities we picked. The outline renderer asks exactly this.
     */
    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true, require = 0)
    private void ivisuals$glowing(CallbackInfoReturnable<Boolean> cir) {
        int id = ((Entity) (Object) this).getId();
        if (HitHighlight.glows(id) || ItemEsp.glows(id)) cir.setReturnValue(true);
    }

    /** Small Fire: hides the vanilla first-person fire overlay (only for the local player). */
    @Inject(method = "isOnFire", at = @At("HEAD"), cancellable = true, require = 0)
    private void ivisuals$hideFire(CallbackInfoReturnable<Boolean> cir) {
        if (LowFire.shouldHideVanilla((Entity) (Object) this)) cir.setReturnValue(false);
    }
}
