package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Style;

import java.lang.reflect.Method;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Finds the nick of the player under the mouse in the open chat.
 *
 * The chat does not keep "who wrote this", but the part of the line you click carries a text style (hover / click
 * event / insertion). Vanilla and most server chats put the player's UUID or a "/msg Nick" there. We read that style
 * and look for a UUID or the nick of somebody who is online. Plain, style-less chat lines can not be read.
 */
public final class ChatPick {
    private ChatPick() {}

    private static final Pattern UUID_RE = Pattern.compile(
            "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");
    private static final Pattern CMD_RE = Pattern.compile(
            "/(?:msg|tell|w|m|pm|whisper|r|t|reply)\\s+([A-Za-z0-9_]{2,16})");

    private static Method styleAt;
    private static boolean styleSearched;

    /** ChatHud.getTextStyleAt(double, double). Looked up by its shape, so it works with any name mapping. */
    private static Style styleAt(MinecraftClient mc, double x, double y) {
        try {
            ChatHud hud = mc.inGameHud.getChatHud();
            if (!styleSearched) {
                styleSearched = true;
                for (Method m : ChatHud.class.getDeclaredMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length == 2 && p[0] == double.class && p[1] == double.class && m.getReturnType() == Style.class) {
                        m.setAccessible(true);
                        styleAt = m;
                        break;
                    }
                }
            }
            if (styleAt == null) return null;
            return (Style) styleAt.invoke(hud, x, y);
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean isWord(char c) { return Character.isLetterOrDigit(c) || c == '_'; }

    /** The nick under the mouse (as the server spells it) or null. */
    public static String nameAt(MinecraftClient mc, double x, double y) {
        if (mc.world == null) return null;
        Style st = styleAt(mc, x, y);
        if (st == null) return null;

        StringBuilder sb = new StringBuilder(String.valueOf(st));
        try {
            String ins = st.getInsertion();
            if (ins != null) sb.append(' ').append(ins);
        } catch (Throwable ignored) {}
        String s = sb.toString();
        List<String> names = Social.onlineNames(mc);

        // 1) a "/msg Nick" style command
        Matcher cm = CMD_RE.matcher(s);
        while (cm.find()) {
            String n = cm.group(1);
            for (String o : names) if (o.equalsIgnoreCase(n)) return o;
        }

        // 2) the UUID of the player (vanilla hover event / insertion)
        Matcher um = UUID_RE.matcher(s);
        while (um.find()) {
            try {
                UUID id = UUID.fromString(um.group());
                PlayerEntity p = mc.world.getPlayerByUuid(id);
                if (p != null) return p.getName().getString();
                if (mc.getNetworkHandler() != null) {
                    PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(id);
                    String n = Social.nameOfProfileEntry(e);
                    if (n != null) return n;
                }
            } catch (Throwable ignored) {}
        }

        // 3) any online nick written in the style: the first one wins (longest first on a tie)
        String best = null;
        int bestAt = Integer.MAX_VALUE;
        for (String n : names) {
            if (n.length() < 3) continue;
            int from = 0, at;
            while ((at = s.indexOf(n, from)) >= 0) {
                boolean left = at == 0 || !isWord(s.charAt(at - 1));
                boolean right = at + n.length() >= s.length() || !isWord(s.charAt(at + n.length()));
                if (left && right) {
                    if (at < bestAt || (at == bestAt && best != null && n.length() > best.length())) {
                        best = n;
                        bestAt = at;
                    }
                    break;
                }
                from = at + 1;
            }
        }
        return best;
    }
}
