package com.ivisuals;

import java.util.ArrayList;
import java.util.List;

/**
 * Hats and wings as small 3D meshes, drawn as a 2D overlay through Proj / Canvas (same way as the ghost model and the
 * block highlight). No Minecraft classes, so it can be tested on its own.
 *
 * Model space: x = to the right of the player, y = up, z = forward. Yaw in degrees, Minecraft convention.
 */
public final class CosmeticGfx {
    private CosmeticGfx() {}

    public static final String[] HATS = {
            "Top Hat", "Wizard Hat", "Crown", "Halo", "Cap", "Cat Ears", "Party Hat", "Devil Horns"};
    public static final String[] WINGS = {"Angel", "Demon", "Dragon", "Butterfly", "Blades"};

    /** Color of the user's choice; phase (0..1) lets rainbow-like colors differ from part to part. */
    public interface ColorFn { int rgb(float phase); }

    // tones: 0 = chosen color, 1 = dark, 2 = white, 3 = gold, 4 = light version of the chosen color
    private static int tone(int tone, ColorFn col, float phase) {
        return switch (tone) {
            case 1 -> 0x18181C;
            case 2 -> 0xF4F4F8;
            case 3 -> 0xFFC83A;
            case 4 -> Fx.mix(col.rgb(phase), 0xFFFFFF, 0.45f);
            default -> col.rgb(phase);
        };
    }

    // ================================================================= transform

    public static final class Xf {
        final double ox, oy, oz, rx, rz, fx, fz, s;

        public Xf(double x, double y, double z, float yawDeg, double scale) {
            double yaw = Math.toRadians(yawDeg);
            ox = x; oy = y; oz = z; s = scale;
            rx = -Math.cos(yaw); rz = -Math.sin(yaw);
            fx = -Math.sin(yaw); fz = Math.cos(yaw);
        }

        public double[] at(double lx, double ly, double lz) {
            return new double[]{ox + s * (rx * lx + fx * lz), oy + s * ly, oz + s * (rz * lx + fz * lz)};
        }

        /** True when the camera stands in front of the model (looks at its face). */
        public boolean cameraInFront(Proj cam) {
            return (cam.cx - ox) * fx + (cam.cz - oz) * fz > 0;
        }
    }

    // ================================================================= hat meshes

    private static final class Face {
        final double[][] v;
        final double[] ref;   // a point inside the solid, used to find the outside of the face
        final int tone;
        Face(double[][] v, double[] ref, int tone) { this.v = v; this.ref = ref; this.tone = tone; }
    }

    private static void frustum(List<Face> out, Xf xf, double y0, double y1, double r0, double r1,
                                double x0, double z0, double x1, double z1, int n, int toneA, int toneB,
                                boolean capTop, boolean capBot) {
        double[] ref = xf.at((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
        for (int i = 0; i < n; i++) {
            double a0 = Math.PI * 2 * i / n, a1 = Math.PI * 2 * (i + 1) / n;
            double[][] q = {
                    xf.at(x0 + r0 * Math.cos(a0), y0, z0 + r0 * Math.sin(a0)),
                    xf.at(x0 + r0 * Math.cos(a1), y0, z0 + r0 * Math.sin(a1)),
                    xf.at(x1 + r1 * Math.cos(a1), y1, z1 + r1 * Math.sin(a1)),
                    xf.at(x1 + r1 * Math.cos(a0), y1, z1 + r1 * Math.sin(a0))};
            out.add(new Face(q, ref, (i & 1) == 0 ? toneA : toneB));
        }
        if (capTop && r1 > 0.001) {
            double[][] p = new double[n][];
            for (int i = 0; i < n; i++) {
                double a = Math.PI * 2 * i / n;
                p[i] = xf.at(x1 + r1 * Math.cos(a), y1, z1 + r1 * Math.sin(a));
            }
            out.add(new Face(p, ref, toneA));
        }
        if (capBot && r0 > 0.001) {
            double[][] p = new double[n][];
            for (int i = 0; i < n; i++) {
                double a = Math.PI * 2 * i / n;
                p[i] = xf.at(x0 + r0 * Math.cos(a), y0, z0 + r0 * Math.sin(a));
            }
            out.add(new Face(p, ref, toneA));
        }
    }

    private static void box(List<Face> out, Xf xf, double x0, double x1, double y0, double y1, double z0, double z1,
                            int tone) {
        double[] ref = xf.at((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
        double[][] c = new double[8][];
        for (int i = 0; i < 8; i++) {
            c[i] = xf.at((i & 1) == 0 ? x0 : x1, (i & 2) == 0 ? y0 : y1, (i & 4) == 0 ? z0 : z1);
        }
        int[][] f = {{0, 1, 3, 2}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 3, 7, 5}};
        for (int[] q : f) out.add(new Face(new double[][]{c[q[0]], c[q[1]], c[q[2]], c[q[3]]}, ref, tone));
    }

    private static void torus(List<Face> out, Xf xf, double cy, double major, double minor, int seg, int tube, int tone) {
        for (int i = 0; i < seg; i++) {
            double a0 = Math.PI * 2 * i / seg, a1 = Math.PI * 2 * (i + 1) / seg, am = (a0 + a1) / 2;
            double[] ref = xf.at(major * Math.cos(am), cy, major * Math.sin(am));
            for (int j = 0; j < tube; j++) {
                double b0 = Math.PI * 2 * j / tube, b1 = Math.PI * 2 * (j + 1) / tube;
                out.add(new Face(new double[][]{
                        torusPt(xf, cy, major, minor, a0, b0), torusPt(xf, cy, major, minor, a1, b0),
                        torusPt(xf, cy, major, minor, a1, b1), torusPt(xf, cy, major, minor, a0, b1)}, ref, tone));
            }
        }
    }

    private static double[] torusPt(Xf xf, double cy, double major, double minor, double a, double b) {
        double rr = major + minor * Math.cos(b);
        return xf.at(rr * Math.cos(a), cy + minor * Math.sin(b), rr * Math.sin(a));
    }

    /** Hat meshes; xf origin = centre of the top of the head. */
    private static List<Face> hat(int style, Xf xf, float t) {
        List<Face> f = new ArrayList<>();
        switch (style) {
            case 0 -> { // Top Hat
                frustum(f, xf, 0, 0.035, 0.42, 0.42, 0, 0, 0, 0, 18, 0, 0, true, true);
                frustum(f, xf, 0.035, 0.52, 0.255, 0.245, 0, 0, 0, 0, 18, 0, 0, true, false);
                frustum(f, xf, 0.035, 0.13, 0.262, 0.262, 0, 0, 0, 0, 18, 1, 1, false, false);
            }
            case 1 -> { // Wizard Hat (bent cone)
                frustum(f, xf, 0, 0.03, 0.46, 0.46, 0, 0, 0, 0, 18, 0, 0, true, true);
                frustum(f, xf, 0.03, 0.085, 0.285, 0.275, 0, 0, 0, 0, 16, 3, 3, false, false);
                for (int s = 0; s < 4; s++) {
                    double y0 = 0.085 + s * 0.16, y1 = y0 + 0.16;
                    double r0 = 0.27 * (1 - s * 0.24), r1 = 0.27 * (1 - (s + 1) * 0.24) + 0.004;
                    double z0 = -0.025 * s * s, z1 = -0.025 * (s + 1) * (s + 1);
                    frustum(f, xf, y0, y1, r0, r1, 0, z0, 0, z1, 14, 0, 0, false, false);
                }
            }
            case 2 -> { // Crown
                frustum(f, xf, 0, 0.13, 0.255, 0.25, 0, 0, 0, 0, 12, 3, 3, false, true);
                for (int k = 0; k < 5; k++) {
                    double a = Math.PI * 2 * k / 5 + Math.PI / 2;
                    double cx = 0.25 * Math.cos(a), cz = 0.25 * Math.sin(a);
                    frustum(f, xf, 0.13, 0.29, 0.065, 0.0, cx, cz, cx, cz, 4, 3, 3, false, false);
                    box(f, xf, cx - 0.02, cx + 0.02, 0.13, 0.17, cz - 0.02, cz + 0.02, 0);
                }
                box(f, xf, -0.035, 0.035, 0.04, 0.10, 0.245, 0.275, 0);
            }
            case 3 -> { // Halo
                double bob = 0.025 * Math.sin(t * 2.2);
                torus(f, xf, 0.24 + bob, 0.27, 0.022, 20, 6, 3);
            }
            case 4 -> { // Cap
                for (int i = 0; i < 4; i++) {
                    double p0 = Math.PI / 2 * i / 4, p1 = Math.PI / 2 * (i + 1) / 4;
                    frustum(f, xf, 0.21 * Math.sin(p0), 0.21 * Math.sin(p1), 0.285 * Math.cos(p0),
                            Math.max(0.01, 0.285 * Math.cos(p1)), 0, 0, 0, 0, 14, 0, 0, i == 3, false);
                }
                box(f, xf, -0.2, 0.2, 0.0, 0.03, 0.2, 0.48, 1);
                box(f, xf, -0.025, 0.025, 0.205, 0.235, -0.025, 0.025, 2);
            }
            case 5 -> { // Cat Ears
                for (int side = -1; side <= 1; side += 2) {
                    double cx = 0.15 * side;
                    frustum(f, xf, 0, 0.23, 0.095, 0.0, cx, 0.0, cx + 0.03 * side, 0.0, 3, 1, 1, false, false);
                    frustum(f, xf, 0.0, 0.17, 0.05, 0.0, cx, 0.045, cx + 0.02 * side, 0.045, 3, 4, 4, false, false);
                }
            }
            case 6 -> { // Party Hat
                frustum(f, xf, 0, 0.5, 0.2, 0.0, 0, 0, 0, 0, 10, 0, 2, false, true);
                box(f, xf, -0.045, 0.045, 0.47, 0.56, -0.045, 0.045, 3);
            }
            default -> { // Devil Horns
                for (int side = -1; side <= 1; side += 2) {
                    for (int h = 0; h < 3; h++) {
                        double x0 = side * (0.16 + 0.03 * h * h), x1 = side * (0.16 + 0.03 * (h + 1) * (h + 1));
                        frustum(f, xf, h * 0.1, (h + 1) * 0.1, 0.06 * (1 - h * 0.28), 0.06 * (1 - (h + 1) * 0.28) + 0.004,
                                x0, 0.0, x1, 0.0, 8, 0, 0, false, h == 0);
                    }
                }
            }
        }
        return f;
    }

    private static final double LX = 0.35, LY = 0.85, LZ = 0.40;

    /** Draws a hat. xf origin = centre of the top of the head. */
    public static void drawHat(Canvas c, Proj cam, int style, Xf xf, float time, ColorFn col, float alpha, int lineW) {
        List<Face> faces = hat(style, xf, time);
        List<double[]> keep = new ArrayList<>();          // {index, dist2, shade}
        for (int i = 0; i < faces.size(); i++) {
            Face fc = faces.get(i);
            double[] a = fc.v[0], b = fc.v[1], d = fc.v[2];
            double ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
            double tx = d[0] - a[0], ty = d[1] - a[1], tz = d[2] - a[2];
            double nx = uy * tz - uz * ty, ny = uz * tx - ux * tz, nz = ux * ty - uy * tx;
            double mx = 0, my = 0, mz = 0;
            for (double[] p : fc.v) { mx += p[0]; my += p[1]; mz += p[2]; }
            mx /= fc.v.length; my /= fc.v.length; mz /= fc.v.length;
            if (nx * (mx - fc.ref[0]) + ny * (my - fc.ref[1]) + nz * (mz - fc.ref[2]) < 0) { nx = -nx; ny = -ny; nz = -nz; }
            double len = Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (len < 1e-9) continue;
            nx /= len; ny /= len; nz /= len;
            if (nx * (cam.cx - mx) + ny * (cam.cy - my) + nz * (cam.cz - mz) <= 0) continue;   // turned away
            double d2 = (cam.cx - mx) * (cam.cx - mx) + (cam.cy - my) * (cam.cy - my) + (cam.cz - mz) * (cam.cz - mz);
            keep.add(new double[]{i, d2, 0.50 + 0.50 * Math.max(0, nx * LX + ny * LY + nz * LZ)});
        }
        keep.sort((p, q) -> Double.compare(q[1], p[1]));   // far faces first

        for (double[] k : keep) {
            Face fc = faces.get((int) k[0]);
            int base = tone(fc.tone, col, (int) k[0] * 0.013f);
            int shaded = shade(base, (float) k[2]);
            fillWorldPoly(c, cam, fc.v, Fx.withAlpha(shaded, alpha));
            int edge = shade(base, 0.45f);
            for (int i = 0; i < fc.v.length; i++) {
                worldLine(c, cam, fc.v[i], fc.v[(i + 1) % fc.v.length], lineW, Fx.withAlpha(edge, alpha * 0.8f));
            }
        }
    }

    // ================================================================= wings

    private static final class Part {
        final double[][] uv;
        final int tone;
        final boolean line;     // thin bone / feather outline only
        Part(double[][] uv, int tone) { this(uv, tone, false); }
        Part(double[][] uv, int tone, boolean line) { this.uv = uv; this.tone = tone; this.line = line; }
        double cu() { double s = 0; for (double[] p : uv) s += p[0]; return s / uv.length; }
    }

    private static final List<Part>[] CACHE = newCache();

    @SuppressWarnings("unchecked")
    private static List<Part>[] newCache() { return new List[WINGS.length]; }

    private static List<Part> parts(int style) {
        List<Part> p = CACHE[style];
        if (p == null) CACHE[style] = p = buildWing(style);
        return p;
    }

    private static double[] pt(double u, double v) { return new double[]{u, v}; }

    private static Part feather(double ru, double rv, double ang, double len, double w0, double w1, int tone) {
        double dx = Math.cos(ang), dy = Math.sin(ang), px = -dy, py = dx;
        double tu = ru + dx * len, tv = rv + dy * len;
        return new Part(new double[][]{
                pt(ru + px * w0, rv + py * w0), pt(tu + px * w1, tv + py * w1),
                pt(tu + dx * 0.05, tv + dy * 0.05),
                pt(tu - px * w1, tv - py * w1), pt(ru - px * w0, rv - py * w0)}, tone);
    }

    private static Part bone(double u0, double v0, double u1, double v1, double w, int tone) {
        double dx = u1 - u0, dy = v1 - v0, l = Math.max(1e-6, Math.sqrt(dx * dx + dy * dy));
        double px = -dy / l * w, py = dx / l * w;
        return new Part(new double[][]{pt(u0 + px, v0 + py), pt(u1 + px * 0.5, v1 + py * 0.5),
                pt(u1 - px * 0.5, v1 - py * 0.5), pt(u0 - px, v0 - py)}, tone, true);
    }

    private static double[] pull(double[] a, double[] b, double[] root, double amount) {
        double mu = (a[0] + b[0]) / 2, mv = (a[1] + b[1]) / 2;
        return pt(mu + (root[0] - mu) * amount, mv + (root[1] - mv) * amount);
    }

    private static Part membrane(double[] root, double[] first, double[][] tips, double[] last, double scallop, int tone) {
        List<double[]> pts = new ArrayList<>();
        pts.add(root);
        pts.add(first);
        for (int i = 0; i < tips.length; i++) {
            pts.add(tips[i]);
            if (i + 1 < tips.length) pts.add(pull(tips[i], tips[i + 1], root, scallop));
        }
        pts.add(last);
        return new Part(pts.toArray(new double[0][]), tone);
    }

    private static Part ellipse(double cu, double cv, double ru, double rv, double rot, int tone) {
        int n = 22;
        double[][] p = new double[n][];
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            double x = Math.cos(a) * ru, y = Math.sin(a) * rv;
            p[i] = pt(cu + x * Math.cos(rot) - y * Math.sin(rot), cv + x * Math.sin(rot) + y * Math.cos(rot));
        }
        return new Part(p, tone);
    }

    private static List<Part> buildWing(int style) {
        List<Part> o = new ArrayList<>();
        switch (style) {
            case 0 -> { // Angel: two layers of feathers
                for (int k = 0; k < 7; k++) {
                    double ang = Math.toRadians(80 - k * 13);
                    double len = 0.55 + 0.5 * Math.sin(Math.PI * (k + 0.5) / 7.0);
                    o.add(feather(0.06, 0.20 - k * 0.06, ang, len, 0.05, 0.095, 4));
                }
                for (int k = 0; k < 6; k++) {
                    double ang = Math.toRadians(74 - k * 14);
                    double len = (0.55 + 0.5 * Math.sin(Math.PI * (k + 0.5) / 6.0)) * 0.55;
                    o.add(feather(0.05, 0.14 - k * 0.055, ang, len, 0.045, 0.08, 0));
                }
            }
            case 1 -> { // Demon: bat wing
                double[] root = pt(0.05, 0.10);
                double[][] tips = {pt(1.0, 0.95), pt(1.3, 0.45), pt(1.15, -0.15), pt(0.8, -0.55)};
                o.add(membrane(root, pt(0.45, 0.62), tips, pt(0.05, -0.30), 0.24, 0));
                for (double[] t : tips) o.add(bone(0.05, 0.10, t[0], t[1], 0.035, 1));
            }
            case 2 -> { // Dragon: bigger, with an elbow
                double[] root = pt(0.05, 0.10), elbow = pt(0.55, 0.85);
                double[][] tips = {pt(1.5, 1.15), pt(1.88, 0.6), pt(1.8, 0.0), pt(1.45, -0.45), pt(0.95, -0.8)};
                o.add(membrane(root, elbow, tips, pt(0.05, -0.45), 0.27, 0));
                o.add(bone(0.05, 0.10, elbow[0], elbow[1], 0.05, 1));
                for (double[] t : tips) o.add(bone(elbow[0], elbow[1], t[0], t[1], 0.04, 1));
                o.add(new Part(new double[][]{pt(0.45, 0.85), pt(0.52, 1.18), pt(0.66, 0.88)}, 2));   // claw
            }
            case 3 -> { // Butterfly
                o.add(ellipse(0.55, 0.50, 0.58, 0.44, 0.35, 0));
                o.add(ellipse(0.42, -0.30, 0.40, 0.30, -0.35, 0));
                o.add(ellipse(0.58, 0.52, 0.32, 0.23, 0.35, 4));
                o.add(ellipse(0.44, -0.30, 0.20, 0.15, -0.35, 4));
            }
            default -> { // Blades
                for (int k = 0; k < 5; k++) {
                    double ang = Math.toRadians(70 - k * 20);
                    double len = 0.85 + 0.5 * Math.sin(Math.PI * (k + 0.6) / 5.5);
                    double rv = 0.16 - k * 0.05, dx = Math.cos(ang), dy = Math.sin(ang);
                    o.add(new Part(new double[][]{pt(0.05 - dy * 0.075, rv + dx * 0.075),
                            pt(0.05 + dx * len, rv + dy * len), pt(0.05 + dy * 0.075, rv - dx * 0.075)}, 0));
                    o.add(new Part(new double[][]{pt(0.05 - dy * 0.03, rv + dx * 0.03),
                            pt(0.05 + dx * len * 0.9, rv + dy * len * 0.9), pt(0.05 + dy * 0.03, rv - dx * 0.03)}, 2));
                }
            }
        }
        return o;
    }

    /**
     * Draws a pair of wings on the back. xf origin = centre of the back (between the shoulder blades), yaw = body yaw.
     * open = how far they spread backwards (degrees), already including the flapping.
     */
    public static void drawWings(Canvas c, Proj cam, int style, Xf xf, double openDeg, ColorFn col, float alpha, int lineW) {
        List<Part> ps = parts(style);
        boolean front = xf.cameraInFront(cam);
        double th = Math.toRadians(openDeg), cs = Math.cos(th), sn = Math.sin(th);

        List<Object[]> draw = new ArrayList<>();          // {double[][] world, Integer tone, Boolean line, Double depth, Float phase}
        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < ps.size(); i++) {
                Part p = ps.get(i);
                if (front && p.cu() < 0.3) continue;      // hidden behind the body when seen from the front
                double[][] w = new double[p.uv.length][];
                double depth = 0;
                for (int k = 0; k < w.length; k++) {
                    double u = p.uv[k][0], v = p.uv[k][1];
                    w[k] = xf.at(side * u * cs, v, -0.0 - u * sn);
                    depth += cam.view(w[k][0], w[k][1], w[k][2])[2];
                }
                draw.add(new Object[]{w, p.tone, p.line, depth / w.length, i * 0.045f});
            }
        }
        draw.sort((a, b) -> Double.compare((double) b[3], (double) a[3]));

        for (Object[] d : draw) {
            double[][] w = (double[][]) d[0];
            int base = wingTone((int) d[1], col, (float) d[4]);
            boolean line = (boolean) d[2];
            fillWorldPoly(c, cam, w, Fx.withAlpha(base, alpha * (line ? 0.95f : 0.62f)));
            int edge = Fx.mix(base, 0xFFFFFF, 0.35f);
            for (int i = 0; i < w.length; i++) {
                worldLine(c, cam, w[i], w[(i + 1) % w.length], lineW, Fx.withAlpha(edge, alpha * 0.9f));
            }
        }
    }

    /** Wing tones: 0 = chosen colour, 4 = lighter, 2 = white, 1 = dark. */
    private static int wingTone(int tone, ColorFn col, float phase) {
        return switch (tone) {
            case 1 -> Fx.mix(col.rgb(phase), 0x000000, 0.65f);
            case 2 -> Fx.mix(col.rgb(phase), 0xFFFFFF, 0.8f);
            case 4 -> Fx.mix(col.rgb(phase), 0xFFFFFF, 0.5f);
            default -> col.rgb(phase);
        };
    }

    // ================================================================= drawing helpers

    private static int shade(int rgb, float f) {
        f = Math.max(0f, Math.min(1.2f, f));
        int r = Math.min(255, (int) (((rgb >> 16) & 255) * f));
        int g = Math.min(255, (int) (((rgb >> 8) & 255) * f));
        int b = Math.min(255, (int) ((rgb & 255) * f));
        return (r << 16) | (g << 8) | b;
    }

    private static void fillWorldPoly(Canvas c, Proj cam, double[][] world, int argb) {
        List<double[]> poly = new ArrayList<>();
        for (double[] p : world) poly.add(cam.view(p[0], p[1], p[2]));
        poly = Proj.clipPoly(poly);
        if (poly.size() < 3) return;
        double[] xs = new double[poly.size()], ys = new double[poly.size()];
        for (int i = 0; i < poly.size(); i++) {
            double[] s = cam.screen(poly.get(i));
            xs[i] = s[0];
            ys[i] = s[1];
        }
        Fx.fillPoly(c, cam.sw, cam.sh, xs, ys, poly.size(), argb);
    }

    private static void worldLine(Canvas c, Proj cam, double[] a, double[] b, int w, int argb) {
        double[][] seg = Proj.clipSegment(cam.view(a[0], a[1], a[2]), cam.view(b[0], b[1], b[2]));
        if (seg == null) return;
        double[] s0 = cam.screen(seg[0]), s1 = cam.screen(seg[1]);
        Fx.line(c, cam.sw, cam.sh, s0[0], s0[1], s1[0], s1[1], w, argb);
    }
}
