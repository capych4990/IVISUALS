package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Hats and Wings: drawn on you (third person) and / or on other players, as a 2D overlay (like the ghost model of
 * Trajectories). See CosmeticGfx for the shapes.
 */
public final class Cosmetics {
    private Cosmetics() {}

    private static Setting hatStyle, hatColor, hatOpacity, hatSize, hatWho;
    private static Setting wingStyle, wingColor, wingOpacity, wingSize, wingWho, wingOpen, wingFlap, wingSpeed;

    private static final String[] WHO = {"Me", "Others", "Everyone"};

    public static void setupHats(Module m) {
        hatStyle = m.mode("Style", 0, CosmeticGfx.HATS);
        hatColor = m.mode("Color", 3, Fx.COLORS);          // Gold
        hatOpacity = m.slider("Opacity", 0.95f, 0.3f, 1f, 0.05f);
        hatSize = m.slider("Size", 1f, 0.5f, 2f, 0.05f);
        hatWho = m.mode("Who", 0, WHO);
    }

    public static void setupWings(Module m) {
        wingStyle = m.mode("Style", 0, CosmeticGfx.WINGS);
        wingColor = m.mode("Color", 7, Fx.COLORS);        // White
        wingOpacity = m.slider("Opacity", 0.75f, 0.2f, 1f, 0.05f);
        wingSize = m.slider("Size", 1f, 0.5f, 2f, 0.05f);
        wingOpen = m.slider("Spread", 30f, 0f, 75f, 1f);
        wingFlap = m.slider("Flap", 12f, 0f, 35f, 1f);
        wingSpeed = m.slider("Flap Speed", 1f, 0f, 3f, 0.1f);
        wingWho = m.mode("Who", 0, WHO);
    }

    // ------------------------------------------------------------------ camera (first AND third person)

    private static Method posM;

    static Proj camera(MinecraftClient mc, float tp) {
        if (mc.options.getPerspective().isFirstPerson()) return HudFx.camera(mc, tp);
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null) return null;
        try {
            if (posM == null) {
                for (Method m : Camera.class.getMethods()) {
                    if (m.getParameterCount() == 0 && m.getReturnType() == Vec3d.class) { posM = m; break; }
                }
            }
            if (posM == null) return null;
            Vec3d p = (Vec3d) posM.invoke(cam);
            int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
            return new Proj(p.x, p.y, p.z, cam.getYaw(), cam.getPitch(), mc.options.getFov().getValue(), sw, sh);
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------------ render

    public static void render(DrawContext ctx, MinecraftClient mc, float tp) {
        boolean hats = ModuleManager.HATS.enabled, wings = ModuleManager.WINGS.enabled;
        if (!hats && !wings) return;
        if (mc.world == null || mc.player == null || mc.currentScreen != null) return;
        Proj cam = camera(mc, tp);
        if (cam == null) return;
        boolean first = mc.options.getPerspective().isFirstPerson();
        Canvas cv = HudFx.canvas(ctx);
        float t = HudFx.time();

        List<PlayerEntity> list = new ArrayList<>();
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            if (p.isInvisible() || p.isSpectator() || p.isSleeping() || p.getHeight() < 1.0f) continue;
            if (p == mc.player && first) continue;                       // you can not see your own head / back
            double d2 = cam.cx - p.getX(), d3 = cam.cz - p.getZ(), d4 = cam.cy - p.getY();
            if (d2 * d2 + d3 * d3 + d4 * d4 > 48 * 48) continue;
            list.add(p);
        }
        list.sort(Comparator.comparingDouble(p -> -p.squaredDistanceTo(cam.cx, cam.cy, cam.cz)));   // far first
        int shown = 0;
        for (PlayerEntity p : list) {
            if (++shown > 10) break;
            boolean self = p == mc.player;
            Vec3d pos = p.getLerpedPos(tp);
            float body = MathHelper.lerpAngleDegrees(tp, p.lastBodyYaw, p.bodyYaw);
            float head = MathHelper.lerpAngleDegrees(tp, p.lastHeadYaw, p.headYaw);
            float h = p.getHeight();

            if (wings && allows(wingWho.i(), self)) {
                double sc = 0.85 * wingSize.f();
                double open = wingOpen.f() + wingFlap.f() * Math.sin(t * 5.0 * wingSpeed.f());
                int mode = wingColor.i();
                CosmeticGfx.drawWings(cv, cam, wingStyle.i(), backXf(pos, body, h * 0.80, sc), open,
                        ph -> Fx.color(mode, t, ph), wingOpacity.f(), 1);
            }
            if (hats && allows(hatWho.i(), self)) {
                CosmeticGfx.Xf xf = new CosmeticGfx.Xf(pos.x, pos.y + h, pos.z, head, hatSize.f());
                int mode = hatColor.i();
                CosmeticGfx.drawHat(cv, cam, hatStyle.i(), xf, t, ph -> Fx.color(mode, t, ph), hatOpacity.f(), 1);
            }
        }
    }

    /** Wings sit on the back, a bit behind the body centre. */
    private static CosmeticGfx.Xf backXf(Vec3d pos, float yaw, double up, double sc) {
        double y = Math.toRadians(yaw);
        double back = 0.17 * sc;
        return new CosmeticGfx.Xf(pos.x + Math.sin(y) * back, pos.y + up, pos.z - Math.cos(y) * back, yaw, sc);
    }

    private static boolean allows(int who, boolean self) {
        return who == 2 || (who == 0 && self) || (who == 1 && !self);
    }
}
