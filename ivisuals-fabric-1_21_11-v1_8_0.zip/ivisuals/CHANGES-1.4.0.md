# Ivisuals 1.4.0

New modules (Right Shift menu)
- Trajectories (Combat, on by default): path + landing marker for ender pearls, arrows, tridents, snowballs, eggs,
  potions, XP bottles; "My Aim" previews your own throw / bow shot. When ANOTHER player throws a pearl you see the path
  and a see-through model of him where he will arrive; it stays a few seconds after the teleport (+ a dim model at the start).
- Small Fire (Visuals): vanilla fire overlay is hidden, a thin strip of pixel flames is drawn at the bottom instead.
- Neon Buttons (Visuals, on by default): iridescent neon edge on every button / slider.

Visuals
- Startup loading screen: black, white neon shapes drifting, glowing "IVISUALS" title.
- Black & white lobby panorama + black menu backgrounds + black/white button textures (resource overrides).
- Menu accents are iridescent now.

Fixes
- Optimizer rewritten: every option is applied separately, values are re-applied twice a second, FPS cap and VSync are
  lifted ("Unlock FPS" setting).

Regenerate the lobby wallpaper:  python3 tools/gen_assets.py 1024
