# Ivisuals 1.5.0

Keybinds (easier)
- Hover a module card (or open its settings) and press Alt, then press ANY key -> bound.
- To remove a bind: Alt, then Delete (while it waits for the key). Esc cancels.
- Alt+Click on a card still works too. RShift can not be bound (menu key), Alt itself can not be bound.

New
- Info (HUD): client name, FPS and ping. Move / resize it in the HUD tab, toggle name / FPS / ping in its settings.
- Client Color (Visuals): Red, Orange, Yellow, Green, Cyan, Blue, Purple, Pink, White, Rainbow or Custom hue.
  The menu, HUD, neon edges and every "Client" colored highlight follow it. Switch it off / "Default" = old white look.
- Item ESP (Visuals): dropped items get a glow outline of their own texture + name and count above them.
  Options: glow color, names, count, background, name size, range.
- Held Glow (Visuals): custom glow (Aura / Ring / Sparks) around the item in your hand, any color, size, opacity,
  offset, main / off hand.

Other
- New color "Client" in every color list (follows Client Color).
