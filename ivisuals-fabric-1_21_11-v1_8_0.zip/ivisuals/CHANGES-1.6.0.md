# Ivisuals 1.6.0

Fixes
- Hit Highlight works again. Reason: the client can not set the vanilla glow flag (the server owns it), so nothing lit up.
  Now the client answers "isGlowing" itself for the entities you hit (EntityMixin). Item ESP glow had the same
  problem and is fixed the same way.
- Held Glow (circle) is gone. New module "Held Tint" instead: the item model in your hand is drawn a second time with a
  see-through color coat, so it follows the real shape of the item. Color (Rainbow / Cyan / Pink / Gold / Purple /
  Red / Green / White / Aqua-Pink / Client), Opacity, Pulse, Expand, Main Hand / Off Hand.

New
- Hats (Visuals): Top Hat, Wizard Hat, Crown, Halo, Cap, Cat Ears, Party Hat, Devil Horns. Color, Opacity, Size,
  Who (Me / Others / Everyone).
- Wings (Visuals): Angel, Demon, Dragon, Butterfly, Blades. Color, Opacity, Size, Spread, Flap, Flap Speed, Who.
  (Hats / Wings are drawn as an overlay like the Trajectories ghost, so they are not hidden by blocks.)
- Quick Swap 1 / 2 / 3 (Player): pick an item (Ender Pearl, Golden Apple, Totem, Shield, ...) and where it goes
  (Main Hand / Off Hand). Hover the card, press Alt, then press the key. Pressing the key later moves the item
  into your hand with the game's own inventory swap click: hotbar item = slot gets selected, inventory item =
  swapped with the slot in your hand (hand busy = the two items change places). Works without opening the inventory.
  The card's ON/OFF switch turns the key on / off.

Tools
- tools/gen_held_tints.py regenerates the 100 tint textures (assets/ivisuals/textures/held).
