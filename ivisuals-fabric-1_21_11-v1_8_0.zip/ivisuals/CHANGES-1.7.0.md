# Ivisuals 1.7.0

HUD (move / resize in the HUD tab like the other widgets)
- Effects HUD: every active potion effect with its level, the time that is left (m:ss, "inf" for endless ones) and a
  bar. Good effects green, bad effects red, the time turns yellow / red when the effect is about to end.
  Nothing is drawn while you have no effects.
- Keybinds HUD: list of every key you bound in the menu (Alt, then the key). Quick Swap shows its item
  ("Quick Swap 1  Ender Pearl > Main Hand"). A bound module that is switched off is dimmed.

Quick Swap
- Press the key AGAIN while the item is in your hand: the last swap is undone, the item you had before comes back
  (and the swapped item goes back to its old slot). Works for hotbar / inventory / off hand.
  Option "Press Again = Swap Back" (on by default) in every Quick Swap card.

Nametags (Visuals, on by default)
- Pretty custom nicks over players (Glass / Neon / Minimal), with health and distance. The vanilla name is hidden.
- Admins are RED with an ADMIN badge (or their rank text). Everybody else uses the color chosen in the menu
  ("Normal Players Color"). Friends get a star and the friend color.
- Admin detection: a rank next to the nick (team prefix / tab list name) that starts with Admin, Owner, Founder,
  Админ, Овнер ... or a nick you marked yourself (Shift + click on it in the chat, or /ivisuals admin <nick>).
  The client can not read real op levels of other players, so that part can not be automatic.

Friends (Player, on by default)
- Open the chat and click a player's nick -> he is your friend (click again = not any more). Friends glow through
  walls (vanilla glow outline, color in the card) and are starred in Nametags. Saved in config/ivisuals.json.
- Shift + click on a nick marks / unmarks an ADMIN (red nametag).
- Commands (client only, never sent to the server): /ivisuals friend <nick>, /ivisuals friend list,
  /ivisuals admin <nick>, /ivisuals admin list.
- The click needs the line to carry the player's UUID or a "/msg Nick" in its text style (vanilla and most server
  chats do). A completely plain line can not be read: use the command there.

See Invisible (Combat, off by default)
- Players (or players + mobs) under invisibility are drawn as the see-through ghost the game shows to spectators.
  Optional glow outline (color) so you also find them through walls.

Other
- New files: Social, ChatPick, Friends, SeeInvisible, Nametags, Commands, ChatScreenMixin, PlayerRendererMixin.
- Version 1.7.0.
