# Ivisuals 1.8.0

Friends (chat click) - fixed
- Clicking a nick in the open chat now also works on plain server chats (custom formats like "[Rank] Nick » text"):
  when the line carries no clickable style, the text of the line under the mouse is read and the nick you point at is used.
- The style lookup now also walks the click / hover events field by field (their toString differs between versions).
- A second hook (Screen.mouseClicked) is installed next to the ChatScreen one, in case this version's ChatScreen
  does not declare its own mouseClicked.

New effects (Visuals)
- Sky: Rainbow, Neon Pulse, Sunset, Aurora, Galaxy, Black & White, Solid Color. Speed, brightness, cloud tint.
  (Needs the game to still ask ClientWorld for the sky / cloud color - see the note below.)
- Sky Lanterns: Chinese lanterns drift up over the map. Amount, size, color, rise speed, hide behind walls.
- Fireflies: soft glowing dots floating around you.
- Jump Circles: neon rings on the ground when you jump (and land from a height). Ring / Double Ring / Burst.
- Player Trail: glowing line / ribbon behind players. Who: Me / Others / Everyone.
- Target Circle: circle + orbiting arcs around who you look at.
- TNT Timer: countdown over lit TNT with a bar and a blast ring (4 blocks).
- Damage Numbers: floating -N / +N over anything that gets hurt / healed.

Hats and Wings
- New "Skin" option: Solid (as before), Neon (dark glass + shimmering neon edges, the Ivisuals look), Glass (see-through).
- Hide Behind Walls (on by default): hats / wings are no longer drawn through blocks.
- New hats: Santa Hat, Bunny Ears. New wings: Cyber.

New files: WorldFx, Effects, Ambient, SkyFx, ScreenClickMixin, Sky*/Cloud* mixins.
