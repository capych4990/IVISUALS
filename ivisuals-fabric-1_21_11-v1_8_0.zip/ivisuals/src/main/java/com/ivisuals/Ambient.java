package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Ambient floating things around the map, drawn on the HUD layer: Sky Lanterns (Chinese lanterns drifting upwards)
 * and Fireflies (small glowing dots). One instance per module.
 */
public final class Ambient {
    public static final Ambient LANTERNS = new Ambient(true);
    public static final Ambient FIREFLIES = new Ambient(false);

    private static final String[] LANTERN_COLORS = {"Warm", "Red", "Neon", "Rainbow", "White", "Cyan", "Pink"};
    private static final Random RND = new Random();

    private final boolean lantern;
    private Setting amount, size, color, walls, speed;

    private static final class F {
        double x, y, z, vx, vy, vz;
        float age, life, phase, scale;
        boolean vis = true;
        float fade;
    }

    private final List<F> list = new ArrayList<>();
    private long last;

    private Ambient(boolean lantern) { this.lantern = lantern; }

    public void setup(Module m) {
        if (lantern) {
            amount = m.slider("Amount", 14f, 2f, 60f, 1f);
            size = m.slider("Size", 1.4f, 0.5f, 4f, 0.1f);
            color = m.mode("Color", 0, LANTERN_COLORS);
            speed = m.slider("Rise Speed", 1f, 0.2f, 3f, 0.1f);
        } else {
            amount = m.slider("Amount", 30f, 4f, 120f, 2f);
            size = m.slider("Size", 1f, 0.4f, 3f, 0.1f);
            color = m.mode("Color", 2, LANTERN_COLORS);
            speed = m.slider("Speed", 1f, 0.2f, 3f, 0.1f);
        }
        walls = m.toggle("Hide Behind Walls", true);
    }

    public void clear() { list.clear(); }

    private int rgb(float t, float ph) {
        return switch (color.i()) {
            case 1 -> 0xFF4B3A;
            case 2 -> Neon.strong(t, ph);
            case 3 -> Fx.hsv(t * 0.1f + ph, 0.8f, 1f);
            case 4 -> 0xFFFFFF;
            case 5 -> 0x40E8FF;
            case 6 -> 0xFF5FD2;
            default -> 0xFFB347;
        };
    }

    // ------------------------------------------------------------------ simulation (every tick)
    public void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { list.clear(); return; }
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        int want = Math.round(amount.f());
        float sp = speed.f();
        for (int i = list.size() - 1; i >= 0; i--) {
            F f = list.get(i);
            f.age += 0.05f;
            f.phase += 0.05f;
            if (lantern) {
                f.x += f.vx * 0.05 * sp + Math.sin(f.phase * 0.9) * 0.006;
                f.z += f.vz * 0.05 * sp + Math.cos(f.phase * 0.7) * 0.006;
                f.y += f.vy * 0.05 * sp;
            } else {
                f.vx += (RND.nextDouble() - 0.5) * 0.02;
                f.vy += (RND.nextDouble() - 0.5) * 0.015;
                f.vz += (RND.nextDouble() - 0.5) * 0.02;
                f.vx *= 0.96; f.vy *= 0.96; f.vz *= 0.96;
                f.x += f.vx * sp; f.y += f.vy * sp; f.z += f.vz * sp;
            }
            double dx = f.x - px, dz = f.z - pz;
            boolean far = dx * dx + dz * dz > (lantern ? 70 * 70 : 22 * 22) || f.y - py > 80 || py - f.y > 30;
            if (f.age >= f.life || far) { list.remove(i); continue; }
            float in = Math.min(1f, f.age / 2f), out = Math.min(1f, (f.life - f.age) / 3f);
            f.fade = Math.min(in, out);
        }
        while (list.size() < want) list.add(spawn(px, py, pz));
        while (list.size() > want) list.remove(list.size() - 1);
    }

    private F spawn(double px, double py, double pz) {
        F f = new F();
        double ang = RND.nextDouble() * Math.PI * 2;
        if (lantern) {
            double d = 8 + RND.nextDouble() * 40;
            f.x = px + Math.cos(ang) * d;
            f.z = pz + Math.sin(ang) * d;
            f.y = py + 1 + RND.nextDouble() * 14;
            f.vy = 0.35 + RND.nextDouble() * 0.35;
            f.vx = (RND.nextDouble() - 0.5) * 0.25;
            f.vz = (RND.nextDouble() - 0.5) * 0.25;
            f.life = 40 + RND.nextFloat() * 40;
            f.scale = 0.8f + RND.nextFloat() * 0.5f;
        } else {
            double d = 1.5 + RND.nextDouble() * 12;
            f.x = px + Math.cos(ang) * d;
            f.z = pz + Math.sin(ang) * d;
            f.y = py - 0.5 + RND.nextDouble() * 4;
            f.life = 6 + RND.nextFloat() * 8;
            f.scale = 0.7f + RND.nextFloat() * 0.6f;
        }
        f.phase = RND.nextFloat() * 6.28f;
        f.age = RND.nextFloat() * (f.life * 0.5f);      // do not all appear at once
        return f;
    }

    // ------------------------------------------------------------------ drawing (every frame)
    private int visTick;

    public void render(DrawContext c, MinecraftClient mc, Proj cam, float tp) {
        if (list.isEmpty()) return;
        boolean checkWalls = walls.b() && (++visTick % 10 == 0);
        float t = HudFx.time();
        float sz = size.f();
        for (F f : list) {
            if (checkWalls) f.vis = WorldFx.visible(mc, cam, f.x, f.y, f.z);
            if (!f.vis || f.fade <= 0.02f) continue;
            double[] s = cam.project(f.x, f.y + (lantern ? f.vy * 0.05 * tp : 0), f.z);
            if (s == null || s[2] > 90) continue;
            int rgb = rgb(t, f.phase * 0.05f);
            if (lantern) drawLantern(c, s, cam, sz * f.scale, rgb, f, t);
            else drawFirefly(c, s, cam, sz * f.scale, rgb, f, t);
        }
    }

    private void drawFirefly(DrawContext c, double[] s, Proj cam, float sz, int rgb, F f, float t) {
        float flick = 0.55f + 0.45f * (float) Math.sin(f.phase * 3.1 + f.scale * 7);
        float a = f.fade * flick;
        int r = Math.max(1, (int) (sz * 0.09 * cam.focal / s[2]));
        int x = (int) s[0], y = (int) s[1];
        if (x < -20 || y < -20 || x > cam.sw + 20 || y > cam.sh + 20) return;
        for (int k = 4; k >= 1; k--) {
            int rr = r + k * Math.max(1, r);
            c.fill(x - rr, y - rr, x + rr, y + rr, Draw.argb((int) (14 * a * (5 - k)), rgb));
        }
        c.fill(x - r, y - r, x + r + 1, y + r + 1, Draw.argb((int) (255 * a), Fx.mix(rgb, 0xFFFFFF, 0.6f)));
    }

    private void drawLantern(DrawContext c, double[] s, Proj cam, float sz, int rgb, F f, float t) {
        float a = f.fade;
        int h = (int) (sz * 0.9 * cam.focal / s[2]);
        if (h < 2) h = 2;
        int w = Math.max(2, (int) (h * 0.72f));
        int x0 = (int) s[0] - w / 2, y0 = (int) s[1] - h / 2;
        if (x0 > cam.sw + 30 || y0 > cam.sh + 30 || x0 + w < -30 || y0 + h < -30) return;
        float flick = 0.85f + 0.15f * (float) Math.sin(t * 9 + f.phase * 4);

        // soft glow around it
        if (h >= 4) Draw.glow(c, x0, y0, w, h, Math.max(1, w / 4), rgb, 7, 0.40f * a * flick);
        else c.fill(x0 - 2, y0 - 2, x0 + w + 2, y0 + h + 2, Draw.argb((int) (70 * a), rgb));

        if (h < 6) {                                              // far away: a bright dot
            c.fill(x0, y0, x0 + w, y0 + h, Draw.argb((int) (255 * a), Fx.mix(rgb, 0xFFFFFF, 0.5f)));
            return;
        }
        int cap = Math.max(1, h / 9);
        int bodyTop = y0 + cap, bodyBot = y0 + h - cap;
        int light = Fx.mix(rgb, 0xFFFFFF, 0.55f), dark = Fx.mix(rgb, 0x000000, 0.35f);
        // body (slightly bulging: narrower at the ends)
        int rows = Math.max(1, bodyBot - bodyTop);
        for (int i = 0; i < rows; i++) {
            float p = (float) i / rows;
            float bulge = (float) Math.sin(Math.PI * (0.15 + 0.7 * p));
            int inset = (int) ((1f - bulge) * w * 0.22f);
            int col = Draw.argb((int) (235 * a), Fx.mix(light, rgb, 0.4f + 0.6f * p));
            c.fill(x0 + inset, bodyTop + i, x0 + w - inset, bodyTop + i + 1, col);
        }
        // ribs
        int rib = Draw.argb((int) (150 * a), dark);
        c.fill(x0 + w / 2, bodyTop, x0 + w / 2 + 1, bodyBot, rib);
        c.fill(x0 + w / 4, bodyTop, x0 + w / 4 + 1, bodyBot, Draw.argb((int) (80 * a), dark));
        c.fill(x0 + w * 3 / 4, bodyTop, x0 + w * 3 / 4 + 1, bodyBot, Draw.argb((int) (80 * a), dark));
        // caps
        int capC = Draw.argb((int) (255 * a), 0x2A1E1A);
        c.fill(x0 + w / 8, y0, x0 + w - w / 8, y0 + cap, capC);
        c.fill(x0 + w / 8, y0 + h - cap, x0 + w - w / 8, y0 + h, capC);
        // flame
        int fw = Math.max(1, w / 5), fh = Math.max(2, (int) (h * 0.28f * flick));
        int fx = (int) s[0] - fw / 2, fy = bodyBot - fh - Math.max(0, h / 10);
        c.fill(fx, fy, fx + fw, fy + fh, Draw.argb((int) (255 * a), 0xFFF6C8));
        // tassel
        if (h >= 12) {
            int tx = (int) s[0];
            c.fill(tx, y0 + h, tx + 1, y0 + h + Math.max(2, h / 4), Draw.argb((int) (200 * a), rgb));
        }
    }
}
