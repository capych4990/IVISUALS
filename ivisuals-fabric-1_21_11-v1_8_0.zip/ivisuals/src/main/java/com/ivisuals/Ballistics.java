package com.ivisuals;

import java.util.ArrayList;
import java.util.List;

/** Flight path of a thrown / shot projectile, tick by tick (vanilla order: move, drag, gravity). No Minecraft classes. */
public final class Ballistics {
    private Ballistics() {}

    /** Collision test for the segment (x0,y0,z0)->(x1,y1,z1). Returns {x, y, z, side} of the hit or null. */
    public interface Hit {
        double[] test(double x0, double y0, double z0, double x1, double y1, double z1);
    }

    public static final class Result {
        public final List<double[]> pts = new ArrayList<>();
        public boolean hit;
        public int ticks;
        public int side = -1;
        public double[] last() { return pts.get(pts.size() - 1); }
    }

    public static Result simulate(double x, double y, double z, double vx, double vy, double vz,
                                  double gravity, double drag, int maxTicks, double minY, Hit hit) {
        Result r = new Result();
        r.pts.add(new double[]{x, y, z});
        for (int i = 1; i <= maxTicks; i++) {
            double nx = x + vx, ny = y + vy, nz = z + vz;
            double[] h = hit == null ? null : hit.test(x, y, z, nx, ny, nz);
            if (h != null) {
                r.pts.add(new double[]{h[0], h[1], h[2]});
                r.hit = true;
                r.ticks = i;
                r.side = (int) h[3];
                return r;
            }
            x = nx; y = ny; z = nz;
            r.pts.add(new double[]{x, y, z});
            vx *= drag; vy *= drag; vz *= drag;
            vy -= gravity;
            r.ticks = i;
            if (y < minY) break;
        }
        return r;
    }
}
