package com.ivisuals;

import java.util.ArrayList;
import java.util.List;

/** Draws a glowing box (block outline / faces) as a 2D overlay. No Minecraft classes. */
public final class BlockGfx {
    private BlockGfx() {}

    public static final String[] STYLES = {"Outline", "Fill", "Outline + Fill", "Corners", "Glow"};

    // corner i: x = bit0, y = bit1, z = bit2 (0 = min, 1 = max)
    // face order = Direction ordinal: DOWN, UP, NORTH, SOUTH, WEST, EAST
    private static final int[][] FACE = {
            {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 1, 3, 2}, {4, 5, 7, 6}, {0, 2, 6, 4}, {1, 3, 7, 5}};

    /**
     * @param b       {minX, minY, minZ, maxX, maxY, maxZ} in world space
     * @param hitFace Direction ordinal of the targeted face, or -1
     */
    public static void draw(Canvas c, Proj p, double[] b, int hitFace, int style, int rgb,
                            float alpha, int lineW, boolean faceOnly) {
        double[][] corner = new double[8][];
        for (int i = 0; i < 8; i++) {
            corner[i] = new double[]{
                    (i & 1) == 0 ? b[0] : b[3], (i & 2) == 0 ? b[1] : b[4], (i & 4) == 0 ? b[2] : b[5]};
        }
        double[][] v = new double[8][];
        for (int i = 0; i < 8; i++) v[i] = p.view(corner[i][0], corner[i][1], corner[i][2]);

        boolean[] vis = {p.cy < b[1], p.cy > b[4], p.cz < b[2], p.cz > b[5], p.cx < b[0], p.cx > b[3]};
        if (faceOnly && hitFace >= 0) {
            for (int f = 0; f < 6; f++) if (f != hitFace) vis[f] = false;
        }

        boolean fill = style == 1 || style == 2 || style == 4;
        boolean lines = style != 1;
        boolean corners = style == 3;
        boolean glow = style == 4;

        if (fill) {
            int col = Fx.withAlpha(rgb, alpha * (style == 1 ? 0.45f : 0.26f));
            for (int f = 0; f < 6; f++) {
                if (!vis[f]) continue;
                List<double[]> poly = new ArrayList<>();
                for (int k = 0; k < 4; k++) poly.add(v[FACE[f][k]]);
                poly = Proj.clipPoly(poly);
                if (poly.size() < 3) continue;
                double[] xs = new double[poly.size()], ys = new double[poly.size()];
                for (int i = 0; i < poly.size(); i++) {
                    double[] s = p.screen(poly.get(i));
                    xs[i] = s[0];
                    ys[i] = s[1];
                }
                Fx.fillPoly(c, p.sw, p.sh, xs, ys, poly.size(), col);
            }
        }

        if (!lines) return;
        boolean[] done = new boolean[64];
        for (int f = 0; f < 6; f++) {
            if (!vis[f]) continue;
            for (int k = 0; k < 4; k++) {
                int a = FACE[f][k], d = FACE[f][(k + 1) & 3];
                int key = Math.min(a, d) * 8 + Math.max(a, d);
                if (done[key]) continue;
                done[key] = true;
                double[][] seg = Proj.clipSegment(v[a], v[d]);
                if (seg == null) continue;
                double[] s0 = p.screen(seg[0]), s1 = p.screen(seg[1]);
                if (glow) {
                    Fx.line(c, p.sw, p.sh, s0[0], s0[1], s1[0], s1[1], lineW + 6, Fx.withAlpha(rgb, alpha * 0.10f));
                    Fx.line(c, p.sw, p.sh, s0[0], s0[1], s1[0], s1[1], lineW + 3, Fx.withAlpha(rgb, alpha * 0.22f));
                }
                if (corners) {
                    double mx0 = s0[0] + (s1[0] - s0[0]) * 0.28, my0 = s0[1] + (s1[1] - s0[1]) * 0.28;
                    double mx1 = s0[0] + (s1[0] - s0[0]) * 0.72, my1 = s0[1] + (s1[1] - s0[1]) * 0.72;
                    Fx.line(c, p.sw, p.sh, s0[0], s0[1], mx0, my0, lineW, Fx.withAlpha(rgb, alpha));
                    Fx.line(c, p.sw, p.sh, mx1, my1, s1[0], s1[1], lineW, Fx.withAlpha(rgb, alpha));
                } else {
                    Fx.line(c, p.sw, p.sh, s0[0], s0[1], s1[0], s1[1], lineW, Fx.withAlpha(rgb, alpha));
                }
            }
        }
    }
}
