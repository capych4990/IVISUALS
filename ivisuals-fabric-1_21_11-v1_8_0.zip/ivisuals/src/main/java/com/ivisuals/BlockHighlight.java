package com.ivisuals;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.shape.VoxelShape;

/** Pretty overlay on the block you are looking at (drawn on the HUD layer, first person only). */
public final class BlockHighlight {
    private BlockHighlight() {}

    private static Setting style, color, opacity, width, pulse, faceOnly;

    public static void setup(Module m) {
        style = m.mode("Style", 4, BlockGfx.STYLES);
        color = m.mode("Color", 0, Fx.COLORS);
        opacity = m.slider("Opacity", 0.85f, 0.05f, 1f, 0.05f);
        width = m.slider("Line Width", 2f, 1f, 4f, 1f);
        pulse = m.toggle("Pulse", true);
        faceOnly = m.toggle("Face Only", false);
    }

    public static void render(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        if (!ModuleManager.BLOCK_HIGHLIGHT.enabled || mc.world == null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        Proj cam = HudFx.camera(mc, tickProgress);
        if (cam == null) return;

        BlockPos pos = hit.getBlockPos();
        BlockState st = mc.world.getBlockState(pos);
        VoxelShape shape = st.getOutlineShape(mc.world, pos);
        if (shape.isEmpty()) return;
        Box b = shape.getBoundingBox().offset(pos);

        float t = HudFx.time();
        float a = opacity.f();
        if (pulse.b()) a *= 0.65f + 0.35f * (float) Math.sin(t * 4f);
        int rgb = Fx.color(color.i(), t, 0f);
        BlockGfx.draw(HudFx.canvas(ctx), cam,
                new double[]{b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ},
                hit.getSide().ordinal(), style.i(), rgb, a, Math.round(width.f()), faceOnly.b());
    }
}
