package com.ivisuals;

/** Minimal 2D sink (a DrawContext in the game, an image in tests). Colors are ARGB. */
public interface Canvas {
    void fill(int x1, int y1, int x2, int y2, int argb);
}
