package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Finds the nick of the player under the mouse in the open chat.
 *
 * The chat does not keep "who wrote this", but the part of the line you click carries a text style (hover / click
 * event / insertion). Vanilla and most server chats put the player's UUID or a "/msg Nick" there. We read that style
 * and look for a UUID or the nick of somebody who is online. Plain, style-less chat lines can not be read.
 */
public final class ChatPick {
    private ChatPick() {}

    private static final Pattern UUID_RE = Pattern.compile(
            "[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");
    private static final Pattern CMD_RE = Pattern.compile(
            "/(?:msg|tell|w|m|pm|whisper|r|t|reply)\\s+([A-Za-z0-9_]{2,16})");

    private static Method styleAt;
    private static boolean styleSearched;

    /** ChatHud.getTextStyleAt(double, double). Looked up by its shape, so it works with any name mapping. */
    private static Style styleAt(MinecraftClient mc, double x, double y) {
        try {
            ChatHud hud = mc.inGameHud.getChatHud();
            if (!styleSearched) {
                styleSearched = true;
                for (Method m : ChatHud.class.getDeclaredMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length == 2 && p[0] == double.class && p[1] == double.class && m.getReturnType() == Style.class) {
                        m.setAccessible(true);
                        styleAt = m;
                        break;
                    }
                }
            }
            if (styleAt == null) return null;
            return (Style) styleAt.invoke(hud, x, y);
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean isWord(char c) { return Character.isLetterOrDigit(c) || c == '_'; }

    /** The nick under the mouse (as the server spells it) or null. */
    public static String nameAt(MinecraftClient mc, double x, double y) {
        if (mc.world == null) return null;
        Style st = styleAt(mc, x, y);
        String viaStyle = st == null ? null : fromStyle(mc, st);
        if (viaStyle != null) return viaStyle;
        return nameFromLine(mc, x, y);                 // plain server chat: read the text of the line itself
    }

    private static String fromStyle(MinecraftClient mc, Style st) {

        StringBuilder sb = new StringBuilder(String.valueOf(st));
        // toString() of the style / events differs between versions: also walk the fields (names do not matter)
        try { sb.append(' ').append(dump(st, 5, new IdentityHashMap<>())); } catch (Throwable ignored) {}
        try {
            String ins = st.getInsertion();
            if (ins != null) sb.append(' ').append(ins);
        } catch (Throwable ignored) {}
        String s = sb.toString();
        List<String> names = Social.onlineNames(mc);

        // 1) a "/msg Nick" style command
        Matcher cm = CMD_RE.matcher(s);
        while (cm.find()) {
            String n = cm.group(1);
            for (String o : names) if (o.equalsIgnoreCase(n)) return o;
        }

        // 2) the UUID of the player (vanilla hover event / insertion)
        Matcher um = UUID_RE.matcher(s);
        while (um.find()) {
            try {
                UUID id = UUID.fromString(um.group());
                PlayerEntity p = mc.world.getPlayerByUuid(id);
                if (p != null) return p.getName().getString();
                if (mc.getNetworkHandler() != null) {
                    PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(id);
                    String n = Social.nameOfProfileEntry(e);
                    if (n != null) return n;
                }
            } catch (Throwable ignored) {}
        }

        // 3) any online nick written in the style: the first one wins (longest first on a tie)
        String best = null;
        int bestAt = Integer.MAX_VALUE;
        for (String n : names) {
            if (n.length() < 3) continue;
            int from = 0, at;
            while ((at = s.indexOf(n, from)) >= 0) {
                boolean left = at == 0 || !isWord(s.charAt(at - 1));
                boolean right = at + n.length() >= s.length() || !isWord(s.charAt(at + n.length()));
                if (left && right) {
                    if (at < bestAt || (at == bestAt && best != null && n.length() > best.length())) {
                        best = n;
                        bestAt = at;
                    }
                    break;
                }
                from = at + 1;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ reflective text of a style

    private static String dump(Object o, int depth, Map<Object, Boolean> seen) {
        if (o == null || depth < 0) return "";
        if (o instanceof CharSequence || o instanceof UUID || o instanceof Number || o instanceof Boolean) return o + " ";
        if (o instanceof Optional<?> op) return op.isPresent() ? dump(op.get(), depth, seen) : "";
        if (o instanceof net.minecraft.text.Text t) return t.getString() + " ";
        if (o instanceof Iterable<?> it) {
            StringBuilder b = new StringBuilder();
            int n = 0;
            for (Object e : it) { if (n++ > 16) break; b.append(dump(e, depth - 1, seen)); }
            return b.toString();
        }
        String cn = o.getClass().getName();
        if (!(cn.startsWith("net.minecraft.") || cn.startsWith("net.minecraft"))) return "";
        if (seen.put(o, Boolean.TRUE) != null) return "";
        StringBuilder b = new StringBuilder();
        for (Class<?> c = o.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) || f.getType().isPrimitive()) continue;
                try {
                    f.setAccessible(true);
                    b.append(dump(f.get(o), depth - 1, seen));
                } catch (Throwable ignored) {}
            }
        }
        return b.toString();
    }

    // ------------------------------------------------------------------ plain chat: the nick written in the line

    private static boolean lineSearched;
    private static Method idxM, toX, toY, contentM;
    private static Field visibleF;

    private static void findLineMembers(MinecraftClient mc, ChatHud hud) {
        try {
            for (Field f : ChatHud.class.getDeclaredFields()) {
                if (List.class.isAssignableFrom(f.getType()) && f.getGenericType().getTypeName().contains("Visible")) {
                    f.setAccessible(true);
                    visibleF = f;
                }
            }
            double probe = mc.getWindow().getScaledHeight() - 40.0;
            double bestAbs = Double.MAX_VALUE;
            Method xCand = null, yCand = null;
            for (Method m : ChatHud.class.getDeclaredMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (p.length == 2 && p[0] == double.class && p[1] == double.class && m.getReturnType() == int.class) {
                    m.setAccessible(true);
                    idxM = m;
                } else if (p.length == 1 && p[0] == double.class && m.getReturnType() == double.class
                        && !Modifier.isStatic(m.getModifiers())) {
                    m.setAccessible(true);
                    double v = Math.abs((double) m.invoke(hud, probe));
                    if (v < bestAbs) {
                        bestAbs = v;
                        xCand = yCand;
                        yCand = m;
                    } else {
                        xCand = m;
                    }
                }
            }
            toY = yCand;
            toX = xCand;
        } catch (Throwable ignored) {}
    }

    private static String lineText(Object line) {
        try {
            if (contentM == null) {
                for (Method m : line.getClass().getDeclaredMethods()) {
                    if (m.getParameterCount() == 0 && m.getReturnType() == OrderedText.class) {
                        m.setAccessible(true);
                        contentM = m;
                        break;
                    }
                }
            }
            if (contentM == null) return null;
            OrderedText ot = (OrderedText) contentM.invoke(line);
            StringBuilder sb = new StringBuilder();
            ot.accept((i, st, cp) -> { sb.appendCodePoint(cp); return true; });
            return sb.toString();
        } catch (Throwable t) {
            return null;
        }
    }

    /** Reads the text of the chat line under the mouse and returns the online nick the mouse is over, or null. */
    public static String nameFromLine(MinecraftClient mc, double x, double y) {
        try {
            ChatHud hud = mc.inGameHud.getChatHud();
            if (!lineSearched) { lineSearched = true; findLineMembers(mc, hud); }
            if (idxM == null || toX == null || toY == null || visibleF == null) return null;
            double cx = (double) toX.invoke(hud, x), cy = (double) toY.invoke(hud, y);
            int idx = (int) idxM.invoke(hud, cx, cy);
            List<?> list = (List<?>) visibleF.get(hud);
            if (list == null || idx < 0 || idx >= list.size()) return null;
            String text = lineText(list.get(idx));
            if (text == null || text.isEmpty()) return null;

            String best = null;
            for (String n : Social.onlineNames(mc)) {
                if (n.length() < 3) continue;
                int from = 0, at;
                while ((at = text.indexOf(n, from)) >= 0) {
                    boolean left = at == 0 || !isWord(text.charAt(at - 1));
                    boolean right = at + n.length() >= text.length() || !isWord(text.charAt(at + n.length()));
                    if (left && right) {
                        int w0 = mc.textRenderer.getWidth(text.substring(0, at));
                        int w1 = w0 + mc.textRenderer.getWidth(n);
                        if (cx >= w0 - 1 && cx <= w1 + 1 && (best == null || n.length() > best.length())) best = n;
                    }
                    from = at + 1;
                }
            }
            return best;
        } catch (Throwable t) {
            return null;
        }
    }
}
