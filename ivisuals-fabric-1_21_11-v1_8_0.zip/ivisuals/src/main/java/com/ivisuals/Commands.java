package com.ivisuals;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Client commands (they never go to the server):
 *   /ivisuals friend <nick>     add / remove a friend        /ivisuals friend list
 *   /ivisuals admin <nick>      mark / unmark an admin (red) /ivisuals admin list
 * Same as clicking the nick in the chat (Shift + click = admin).
 */
public final class Commands {
    private Commands() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(ClientCommandManager.literal("ivisuals")
                .then(group("friend", false))
                .then(group("admin", true)));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> group(String word, boolean admin) {
        return ClientCommandManager.literal(word)
                .then(ClientCommandManager.literal("list").executes(c -> {
                    List<String> l = admin ? Social.admins() : Social.friends();
                    c.getSource().sendFeedback(Text.literal(
                            (admin ? "Admins: " : "Friends: ") + (l.isEmpty() ? "(none)" : String.join(", ", l)))
                            .formatted(Formatting.GRAY));
                    return 1;
                }))
                .then(ClientCommandManager.argument("nick", StringArgumentType.word())
                        .suggests((ctx, b) -> CommandSource.suggestMatching(
                                Social.onlineNames(MinecraftClient.getInstance()), b))
                        .executes(c -> {
                            String nick = StringArgumentType.getString(c, "nick");
                            boolean now = admin ? Social.toggleAdmin(nick) : Social.toggleFriend(nick);
                            String msg = admin
                                    ? nick + (now ? " is now marked as ADMIN" : " is no longer marked as admin")
                                    : nick + (now ? " is now your friend" : " is no longer your friend");
                            c.getSource().sendFeedback(Text.literal(msg)
                                    .formatted(now ? (admin ? Formatting.RED : Formatting.GREEN) : Formatting.GRAY));
                            return 1;
                        }));
    }
}
