package com.ivisuals;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Saves menu size, module states / binds / settings and HUD widget layout to config/ivisuals.json */
public class Config {
    public static int winW = 470;
    public static int winH = 280;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("ivisuals.json");
    }

    private static JsonObject read() {
        try {
            Path f = file();
            if (Files.exists(f)) return JsonParser.parseString(Files.readString(f)).getAsJsonObject();
        } catch (Exception ignored) {}
        return new JsonObject();
    }

    public static void load() {
        try {
            JsonObject o = read();
            if (o.has("w")) winW = o.get("w").getAsInt();
            if (o.has("h")) winH = o.get("h").getAsInt();

            Optimizer.loadFrom(o);   // must happen before the Optimizer module is switched on below
            Social.loadFrom(o);

            JsonObject mods = o.has("modules") ? o.getAsJsonObject("modules") : new JsonObject();
            for (Module m : ModuleManager.MODULES) {
                if (!mods.has(m.name)) continue;
                JsonElement e = mods.get(m.name);
                if (e.isJsonPrimitive()) {                       // old format: plain boolean
                    m.setEnabled(e.getAsBoolean());
                } else if (e.isJsonObject()) {
                    JsonObject mo = e.getAsJsonObject();
                    if (mo.has("on")) m.setEnabled(mo.get("on").getAsBoolean());
                    if (mo.has("bind")) m.bind = mo.get("bind").getAsInt();
                    if (mo.has("settings") && mo.get("settings").isJsonObject()) {
                        JsonObject so = mo.getAsJsonObject("settings");
                        for (Setting st : m.settings) {
                            if (so.has(st.name)) {
                                try { st.set(so.get(st.name).getAsFloat()); } catch (Exception ignored) {}
                            }
                        }
                    }
                }
                m.toggleAnim = m.enabled ? 1f : 0f;
            }

            JsonObject hud = o.has("hud") ? o.getAsJsonObject("hud") : new JsonObject();
            for (HudWidget w : HudWidgets.ALL) {
                if (!hud.has(w.id)) continue;
                JsonObject wo = hud.getAsJsonObject(w.id);
                if (wo.has("x")) w.x = wo.get("x").getAsInt();
                if (wo.has("y")) w.y = wo.get("y").getAsInt();
                if (wo.has("scale")) w.scale = Math.max(0.5f, Math.min(4f, wo.get("scale").getAsFloat()));
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            o.addProperty("w", winW);
            o.addProperty("h", winH);

            JsonObject mods = new JsonObject();
            for (Module m : ModuleManager.MODULES) {
                JsonObject mo = new JsonObject();
                mo.addProperty("on", m.enabled);
                mo.addProperty("bind", m.bind);
                if (!m.settings.isEmpty()) {
                    JsonObject so = new JsonObject();
                    for (Setting st : m.settings) so.addProperty(st.name, st.f());
                    mo.add("settings", so);
                }
                mods.add(m.name, mo);
            }
            o.add("modules", mods);

            JsonObject hud = new JsonObject();
            for (HudWidget w : HudWidgets.ALL) {
                JsonObject wo = new JsonObject();
                wo.addProperty("x", w.x);
                wo.addProperty("y", w.y);
                wo.addProperty("scale", w.scale);
                hud.add(w.id, wo);
            }
            o.add("hud", hud);
            Optimizer.saveTo(o);
            Social.saveTo(o);

            Path f = file();
            Files.createDirectories(f.getParent());
            Files.writeString(f, o.toString());
        } catch (Exception ignored) {}
    }
}
