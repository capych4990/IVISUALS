package com.ivisuals;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Draw {
    private Draw() {}

    public static int argb(int a, int rgb) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    public static int mulAlpha(int color, float m) {
        int a = (int) (((color >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, m)));
        return (a << 24) | (color & 0xFFFFFF);
    }

    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) (((c1 >>> 24) & 255) + ((((c2 >>> 24) & 255) - ((c1 >>> 24) & 255)) * t));
        int r = (int) (((c1 >> 16) & 255) + ((((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t));
        int g = (int) (((c1 >> 8) & 255) + ((((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t));
        int b = (int) ((c1 & 255) + (((c2 & 255) - (c1 & 255)) * t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    /** Horizontal inset of row i of a rounded rect of height h and radius r. */
    private static int inset(int i, int h, int r) {
        int d = i < r ? i : (i >= h - r ? h - 1 - i : -1);
        if (d < 0) return 0;
        double dy = r - d - 0.5;
        return (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
    }

    public static void roundRect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (((color >>> 24) & 255) == 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int ins = inset(i, h, r);
            c.fill(x + ins, y + i, x + w - ins, y + i + 1, color);
            c.fill(x + ins, y + h - i - 1, x + w - ins, y + h - i, color);
        }
    }

    /** Rounded rect with a vertical gradient (top -> bottom). */
    public static void roundRectV(DrawContext c, int x, int y, int w, int h, int r, int top, int bot) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int col = lerp(top, bot, h <= 1 ? 0f : (float) i / (h - 1));
            if (((col >>> 24) & 255) == 0) continue;
            int ins = inset(i, h, r);
            c.fill(x + ins, y + i, x + w - ins, y + i + 1, col);
        }
    }

    /** 1px rounded outline with a vertical gradient (the glass edge). */
    public static void ring(DrawContext c, int x, int y, int w, int h, int r, int top, int bot) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int col = lerp(top, bot, h <= 1 ? 0f : (float) i / (h - 1));
            if (((col >>> 24) & 255) == 0) continue;
            int ins = inset(i, h, r);
            if (i == 0 || i == h - 1) {
                c.fill(x + ins, y + i, x + w - ins, y + i + 1, col);
            } else {
                int nb = (i < h / 2) ? inset(i - 1, h, r) : inset(i + 1, h, r);
                int run = Math.min(Math.max(1, nb - ins), Math.max(1, w / 2));
                c.fill(x + ins, y + i, x + ins + run, y + i + 1, col);
                c.fill(x + w - ins - run, y + i, x + w - ins, y + i + 1, col);
            }
        }
    }

    /** Soft glow: stacked translucent rounded rects, draw BEFORE the solid shape. */
    public static void glow(DrawContext c, int x, int y, int w, int h, int r, int rgb, int layers, float strength) {
        for (int k = layers; k >= 1; k--) {
            int a = (int) (strength * 255f / layers);
            roundRect(c, x - k, y - k, w + k * 2, h + k * 2, r + k, argb(a, rgb));
        }
    }

    public static void text(DrawContext c, TextRenderer tr, String s, float x, float y, float scale, int color) {
        if (((color >>> 24) & 255) < 4) return;
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(scale, scale);
        c.drawText(tr, s, 0, 0, color, false);
        m.popMatrix();
    }

    public static int textWidth(TextRenderer tr, String s, float scale) {
        return (int) (tr.getWidth(s) * scale);
    }
}
