package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * World effects drawn on the HUD layer (same way as Trajectories): Jump Circles, Target Circle, Player Trail,
 * TNT Timer and Damage Numbers. Every effect is its own module, see ModuleManager.
 */
public final class Effects {
    private Effects() {}

    private static final Random RND = new Random();

    private static float dt(long[] last) {
        long now = System.nanoTime();
        float d = last[0] == 0 ? 0.016f : Math.min((now - last[0]) / 1e9f, 0.1f);
        last[0] = now;
        return d;
    }

    // ================================================================== Jump Circles
    private static Setting jStyle, jColor, jSize, jLife, jWho, jLand;

    private static final class Ring { double x, y, z; long t0; float size; }
    private static final class Air { boolean ground = true; double prevY, peak; }

    private static final List<Ring> RINGS = new ArrayList<>();
    private static final Map<Integer, Air> AIR = new HashMap<>();

    public static void setupJump(Module m) {
        jStyle = m.mode("Style", 1, "Ring", "Double Ring", "Burst");
        jColor = m.mode("Color", 0, Neon.COLORS);
        jSize = m.slider("Size", 1f, 0.5f, 2.5f, 0.1f);
        jLife = m.slider("Lifetime (s)", 0.9f, 0.3f, 2.5f, 0.1f);
        jWho = m.mode("Who", 2, WorldFx.WHO);
        jLand = m.toggle("On Landing", true);
    }

    public static void clearJump() { RINGS.clear(); AIR.clear(); }

    public static void tickJump(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { clearJump(); return; }
        long now = System.currentTimeMillis();
        long life = (long) (jLife.f() * 1000f);
        RINGS.removeIf(r -> now - r.t0 > life);
        Set<Integer> seen = new HashSet<>();
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            boolean self = p == mc.player;
            if (p.isSpectator() || p.isRemoved() || !WorldFx.allows(jWho.i(), self)) continue;
            seen.add(p.getId());
            Air a = AIR.computeIfAbsent(p.getId(), k -> new Air());
            boolean g = p.isOnGround();
            double y = p.getY();
            if (a.ground && !g && y - a.prevY > 0.1) {
                spawnRing(p.getX(), a.prevY, p.getZ(), 1f, now);
                a.peak = y;
            } else if (!g) {
                a.peak = Math.max(a.peak, y);
            } else if (!a.ground && jLand.b() && a.peak - y > 0.6) {
                spawnRing(p.getX(), y, p.getZ(), (float) Math.min(1.6, 0.6 + (a.peak - y) * 0.12), now);
            }
            a.ground = g;
            a.prevY = y;
        }
        AIR.keySet().retainAll(seen);
    }

    private static void spawnRing(double x, double y, double z, float scale, long now) {
        Ring r = new Ring();
        r.x = x; r.y = y + 0.03; r.z = z; r.t0 = now; r.size = scale;
        RINGS.add(r);
        if (RINGS.size() > 40) RINGS.remove(0);
    }

    private static void renderJump(Canvas cv, Proj cam, float t) {
        long now = System.currentTimeMillis();
        float life = jLife.f() * 1000f;
        for (Ring r : RINGS) {
            float p = (now - r.t0) / life;
            if (p >= 1f) continue;
            float e = 1f - (1f - p) * (1f - p);                     // ease out
            float a = (1f - p) * (1f - p) * 1.1f;
            double rad = (0.25 + 1.9 * e) * jSize.f() * r.size;
            int rgb = Neon.pick(jColor.i(), t, 0f);
            WorldFx.ring(cv, cam, r.x, r.y, r.z, rad, 2, rgb, Math.min(1f, a));
            if (jStyle.i() >= 1) {
                float p2 = Math.max(0f, p - 0.15f) / 0.85f;
                double rad2 = (0.15 + 1.4 * (1f - (1f - p2) * (1f - p2))) * jSize.f() * r.size;
                WorldFx.ring(cv, cam, r.x, r.y, r.z, rad2, 1, Neon.pick(jColor.i(), t, 0.4f), Math.min(1f, a * 0.8f));
            }
            if (jStyle.i() == 2) {
                for (int k = 0; k < 12; k++) {
                    double ang = Math.PI * 2 * k / 12 + 0.3;
                    double r0 = rad * 0.55, r1 = rad * (0.9 + 0.35 * e);
                    WorldFx.glowLine(cv, cam, r.x + Math.cos(ang) * r0, r.y, r.z + Math.sin(ang) * r0,
                            r.x + Math.cos(ang) * r1, r.y + 0.25 * e, r.z + Math.sin(ang) * r1, 1, rgb, Math.min(1f, a));
                }
            }
        }
    }

    // ================================================================== Target Circle
    private static Setting tStyle, tColor, tSize, tSpeed;
    private static int tId = -1;
    private static float tFade;
    private static final long[] tLast = {0};

    public static void setupTarget(Module m) {
        tStyle = m.mode("Style", 2, "Ring", "Orbit", "Ring + Orbit");
        tColor = m.mode("Color", 0, Neon.COLORS);
        tSize = m.slider("Size", 1f, 0.6f, 2f, 0.05f);
        tSpeed = m.slider("Speed", 1f, 0.3f, 3f, 0.1f);
    }

    private static void renderTarget(MinecraftClient mc, Canvas cv, Proj cam, float tp, float t) {
        float d = dt(tLast);
        Entity te = mc.targetedEntity;
        if (te instanceof LivingEntity && !te.isRemoved()) tId = te.getId();
        Entity e = tId >= 0 ? mc.world.getEntityById(tId) : null;
        boolean on = te != null && e != null && te.getId() == tId;
        tFade += ((on ? 1f : 0f) - tFade) * Math.min(1f, d * 9f);
        if (e == null || tFade < 0.03f) return;
        Vec3d pos = e.getLerpedPos(tp);
        double r = Math.max(0.45, e.getWidth() * 0.85) * tSize.f();
        double h = e.getHeight();
        int rgb = Neon.pick(tColor.i(), t, 0f);
        int style = tStyle.i();
        float sp = tSpeed.f();
        if (style != 1) {
            WorldFx.ring(cv, cam, pos.x, pos.y + 0.04, pos.z, r, 2, rgb, tFade);
        }
        if (style != 0) {
            for (int k = 0; k < 3; k++) {
                double a0 = t * 2.6 * sp + k * Math.PI * 2 / 3;
                WorldFx.arc(cv, cam, pos.x, pos.y + 0.04, pos.z, r * 1.18, a0, 0.9, 8, 2,
                        Neon.pick(tColor.i(), t, k * 0.2f), tFade);
            }
            double y = pos.y + h * (0.5 + 0.5 * Math.sin(t * 1.9 * sp));
            WorldFx.ring(cv, cam, pos.x, y, pos.z, r * 0.95, 1, Neon.pick(tColor.i(), t, 0.5f), tFade * 0.8f);
        }
    }

    // ================================================================== Player Trail
    private static Setting trStyle, trColor, trLength, trWho, trWidth;
    private static final Map<Integer, List<double[]>> TRAILS = new HashMap<>();   // {x, y, z, timeMs}

    public static void setupTrail(Module m) {
        trStyle = m.mode("Style", 1, "Line", "Ribbon", "Double");
        trColor = m.mode("Color", 0, Neon.COLORS);
        trLength = m.slider("Length (s)", 1.6f, 0.4f, 5f, 0.1f);
        trWidth = m.slider("Line Width", 2f, 1f, 4f, 1f);
        trWho = m.mode("Who", 0, WorldFx.WHO);
    }

    public static void clearTrail() { TRAILS.clear(); }

    public static void tickTrail(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { TRAILS.clear(); return; }
        long now = System.currentTimeMillis();
        long keep = (long) (trLength.f() * 1000f);
        Set<Integer> seen = new HashSet<>();
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            boolean self = p == mc.player;
            if (p.isSpectator() || p.isRemoved() || p.isInvisible() || !WorldFx.allows(trWho.i(), self)) continue;
            seen.add(p.getId());
            List<double[]> l = TRAILS.computeIfAbsent(p.getId(), k -> new ArrayList<>());
            double[] last = l.isEmpty() ? null : l.get(l.size() - 1);
            double x = p.getX(), y = p.getY() + 0.08, z = p.getZ();
            if (last == null || Math.abs(last[0] - x) + Math.abs(last[1] - y) + Math.abs(last[2] - z) > 0.12) {
                if (last != null && Math.abs(last[0] - x) + Math.abs(last[2] - z) > 12) l.clear();   // teleport
                l.add(new double[]{x, y, z, now});
            }
            l.removeIf(q -> now - q[3] > keep);
        }
        TRAILS.keySet().retainAll(seen);
    }

    private static void renderTrail(Canvas cv, Proj cam, float t) {
        long now = System.currentTimeMillis();
        float keep = trLength.f() * 1000f;
        int w = Math.round(trWidth.f());
        for (List<double[]> l : TRAILS.values()) {
            for (int i = 0; i + 1 < l.size(); i++) {
                double[] a = l.get(i), b = l.get(i + 1);
                float age = (float) ((now - b[3]) / keep);
                float al = Math.max(0f, 1f - age);
                if (al <= 0.02f) continue;
                int rgb = Neon.pick(trColor.i(), t, i * 0.02f);
                int st = trStyle.i();
                if (st != 1) WorldFx.glowLine(cv, cam, a[0], a[1], a[2], b[0], b[1], b[2], w, rgb, al);
                if (st >= 1) {
                    double hgt = st == 1 ? 0.7 : 0.35;
                    double[] pa = cam.project(a[0], a[1], a[2]), pb = cam.project(b[0], b[1], b[2]);
                    double[] ta = cam.project(a[0], a[1] + hgt, a[2]), tb = cam.project(b[0], b[1] + hgt, b[2]);
                    if (pa != null && pb != null && ta != null && tb != null) {
                        Fx.fillPoly(cv, cam.sw, cam.sh,
                                new double[]{pa[0], pb[0], tb[0], ta[0]}, new double[]{pa[1], pb[1], tb[1], ta[1]}, 4,
                                Fx.withAlpha(rgb, al * 0.30f));
                    }
                    if (st == 1) {
                        WorldFx.line(cv, cam, a[0], a[1] + hgt, a[2], b[0], b[1] + hgt, b[2], 1, Fx.withAlpha(rgb, al * 0.8f));
                    }
                }
            }
        }
    }

    // ================================================================== TNT Timer
    private static Setting tnColor, tnSize, tnRange, tnBlast, tnWalls;
    private static final class Tnt { int id; float fuse; }
    private static final List<Tnt> TNTS = new ArrayList<>();
    private static final Map<Class<?>, Method> FUSE = new HashMap<>();

    public static void setupTnt(Module m) {
        tnColor = m.mode("Color", 0, new String[]{"Danger (white > red)", "Neon", "Rainbow"});
        tnSize = m.slider("Size", 1.2f, 0.6f, 3f, 0.1f);
        tnRange = m.slider("Range", 48f, 8f, 128f, 4f);
        tnBlast = m.toggle("Blast Ring", true);
        tnWalls = m.toggle("Hide Behind Walls", false);
    }

    public static void clearTnt() { TNTS.clear(); }

    private static float fuseOf(Entity e) {
        try {
            Class<?> c = e.getClass();
            Method m = FUSE.get(c);
            if (m == null && !FUSE.containsKey(c)) {
                for (Method x : c.getDeclaredMethods()) {
                    if (x.getParameterCount() == 0 && x.getReturnType() == int.class
                            && java.lang.reflect.Modifier.isPublic(x.getModifiers())
                            && !java.lang.reflect.Modifier.isStatic(x.getModifiers())) {
                        int v = (int) x.invoke(e);
                        if (v >= 0 && v <= 200) { m = x; break; }
                    }
                }
                FUSE.put(c, m);
            }
            if (m != null) return (int) m.invoke(e);
        } catch (Throwable ignored) {}
        return Math.max(0, 80 - e.age);
    }

    public static void tickTnt(MinecraftClient mc) {
        TNTS.clear();
        if (mc.world == null || mc.player == null) return;
        double rg = tnRange.f() * tnRange.f();
        for (Entity e : mc.world.getEntities()) {
            if (e.squaredDistanceTo(mc.player) > rg) continue;
            if (!Registries.ENTITY_TYPE.getId(e.getType()).getPath().equals("tnt")) continue;
            Tnt t = new Tnt();
            t.id = e.getId();
            t.fuse = fuseOf(e);
            TNTS.add(t);
            if (TNTS.size() >= 24) break;
        }
    }

    private static void renderTnt(DrawContext ctx, MinecraftClient mc, Canvas cv, Proj cam, float tp, float t) {
        for (Tnt tn : TNTS) {
            Entity e = mc.world.getEntityById(tn.id);
            if (e == null) continue;
            Vec3d p = e.getLerpedPos(tp);
            double hy = p.y + e.getHeight() + 0.55;
            if (tnWalls.b() && !WorldFx.visible(mc, cam, p.x, p.y + 0.5, p.z)) continue;
            float ticks = Math.max(0f, tn.fuse - tp);
            float danger = 1f - Math.min(1f, ticks / 80f);
            int rgb = switch (tnColor.i()) {
                case 1 -> Neon.strong(t, 0f);
                case 2 -> Fx.hsv(t * 0.35f, 0.85f, 1f);
                default -> Fx.mix(0xFFFFFF, 0xFF3B3B, danger);
            };
            if (tnBlast.b()) {
                WorldFx.ring(cv, cam, p.x, p.y + 0.05, p.z, 4.0, 1, rgb, 0.35f + 0.45f * danger);
            }
            String s = String.format(java.util.Locale.ROOT, "%.1fs", ticks / 20f);
            float sc = tnSize.f();
            WorldFx.text(ctx, mc, cam, p.x, hy, p.z, s, sc, rgb, 1f);
            // little bar under the number
            double[] sp = cam.project(p.x, hy, p.z);
            if (sp != null) {
                int bw = (int) (26 * sc), bx = (int) sp[0] - bw / 2, by = (int) (sp[1] + 6 * sc);
                float f = Math.min(1f, ticks / 80f);
                ctx.fill(bx, by, bx + bw, by + 2, Draw.argb(90, 0x000000));
                ctx.fill(bx, by, bx + Math.max(1, (int) (bw * f)), by + 2, Draw.argb(240, rgb));
            }
        }
    }

    // ================================================================== Damage Numbers
    private static Setting dmSize, dmHeal, dmSelf, dmStyle;
    private static final class Pop { double x, y, z; long t0; String s; int rgb; float big; }
    private static final List<Pop> POPS = new ArrayList<>();
    private static final Map<Integer, Float> HP = new HashMap<>();

    public static void setupDamage(Module m) {
        dmStyle = m.mode("Style", 0, "Colored", "White", "Neon");
        dmSize = m.slider("Size", 1.2f, 0.6f, 3f, 0.1f);
        dmHeal = m.toggle("Show Healing", true);
        dmSelf = m.toggle("Show My Damage", true);
    }

    public static void clearDamage() { POPS.clear(); HP.clear(); }

    public static void tickDamage(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { clearDamage(); return; }
        long now = System.currentTimeMillis();
        POPS.removeIf(p -> now - p.t0 > 1100);
        Set<Integer> seen = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e.squaredDistanceTo(mc.player) > 40 * 40) continue;
            if (e == mc.player && !dmSelf.b()) continue;
            String id = Registries.ENTITY_TYPE.getId(e.getType()).getPath();
            if (id.equals("armor_stand")) continue;
            seen.add(e.getId());
            float hp = le.getHealth();
            Float prev = HP.put(e.getId(), hp);
            if (prev == null) continue;
            float d = prev - hp;
            if (Math.abs(d) < 0.15f) continue;
            if (d < 0 && !dmHeal.b()) continue;
            Pop p = new Pop();
            p.x = e.getX() + (RND.nextDouble() - 0.5) * 0.5;
            p.y = e.getY() + e.getHeight() * 0.95;
            p.z = e.getZ() + (RND.nextDouble() - 0.5) * 0.5;
            p.t0 = now;
            p.big = Math.min(1.8f, 0.9f + Math.abs(d) / 10f);
            p.s = (d > 0 ? "-" : "+") + (Math.abs(d) >= 10 ? String.valueOf(Math.round(Math.abs(d)))
                    : String.format(java.util.Locale.ROOT, "%.1f", Math.abs(d)));
            p.rgb = d > 0 ? 0xFF4B4B : 0x46FF8A;
            POPS.add(p);
        }
        HP.keySet().retainAll(seen);
    }

    private static void renderDamage(DrawContext ctx, MinecraftClient mc, Proj cam, float t) {
        long now = System.currentTimeMillis();
        for (Pop p : POPS) {
            float age = (now - p.t0) / 1100f;
            if (age >= 1f) continue;
            float rise = 1.3f * (1f - (1f - age) * (1f - age));
            float a = age < 0.7f ? 1f : (1f - age) / 0.3f;
            double[] sp = cam.project(p.x, p.y + rise, p.z);
            if (sp == null) continue;
            float scale = dmSize.f() * p.big * (float) Math.max(0.7, Math.min(1.6, 7.0 / sp[2]))
                    * (age < 0.12f ? 0.6f + age / 0.12f * 0.4f : 1f);
            int rgb = switch (dmStyle.i()) {
                case 1 -> 0xFFFFFF;
                case 2 -> Neon.strong(t, (float) (p.x * 0.1));
                default -> p.rgb;
            };
            WorldFx.text(ctx, mc, cam, p.x, p.y + rise, p.z, p.s, scale, rgb, a);
        }
    }

    // ================================================================== render entry
    public static void render(DrawContext ctx, MinecraftClient mc, float tp) {
        boolean j = ModuleManager.JUMP_FX.enabled, tg = ModuleManager.TARGET_FX.enabled,
                tr = ModuleManager.TRAIL_FX.enabled, tn = ModuleManager.TNT_TIMER.enabled,
                dm = ModuleManager.DAMAGE_FX.enabled;
        if (!(j || tg || tr || tn || dm) || mc.world == null || mc.player == null) return;
        Proj cam = Cosmetics.camera(mc, tp);
        if (cam == null) return;
        Canvas cv = HudFx.canvas(ctx);
        float t = HudFx.time();
        if (j) renderJump(cv, cam, t);
        if (tr) renderTrail(cv, cam, t);
        if (tg) renderTarget(mc, cv, cam, tp, t);
        if (tn) renderTnt(ctx, mc, cv, cam, tp, t);
        if (dm) renderDamage(ctx, mc, cam, t);
    }
}
