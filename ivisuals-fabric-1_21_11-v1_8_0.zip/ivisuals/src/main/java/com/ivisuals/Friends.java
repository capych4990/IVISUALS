package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.util.InputUtil;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Friends: open the chat and click a player's nick -> he is your friend (click again = not any more).
 * Friends glow through walls (the vanilla glow outline, in a color you pick) and get a mark on their name tag.
 * Shift + click on a nick marks / unmarks an ADMIN (red name tag).
 */
public final class Friends {
    private Friends() {}

    private static Setting glow, color, chatClick, message;
    private static final Set<Integer> GLOWING = ConcurrentHashMap.newKeySet();
    private static World lastWorld;

    public static void setup(Module m) {
        glow = m.toggle("Glow Through Walls", true);
        color = m.mode("Glow Color", 6, Fx.COLORS);          // Green
        chatClick = m.toggle("Click Nick In Chat", true);
        message = m.toggle("Show Message", true);
    }

    public static boolean active() {
        return ModuleManager.FRIENDS != null && ModuleManager.FRIENDS.enabled;
    }

    /** True when the nick is in your friend list and the module is on. */
    public static boolean isFriend(String name) {
        return active() && Social.isFriend(name);
    }

    /** Friend color (RGB). */
    public static int colorRgb(float time, float phase) {
        return Fx.color(color == null ? 6 : color.i(), time, phase);
    }

    // ------------------------------------------------------------------ glow through walls

    /** Used by EntityMixin.isGlowing (client thread only). */
    public static boolean glows(int entityId) {
        if (GLOWING.isEmpty()) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc != null && mc.isOnThread() && GLOWING.contains(entityId);
    }

    public static Integer colorFor(int entityId) {
        if (GLOWING.isEmpty() || !GLOWING.contains(entityId)) return null;
        return Fx.color(color.i(), HudFx.time(), (entityId % 7) / 7f);
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { GLOWING.clear(); lastWorld = null; return; }
        if (mc.world != lastWorld) { GLOWING.clear(); lastWorld = mc.world; }
        Set<Integer> seen = new HashSet<>();
        if (glow.b()) {
            for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
                if (p == mc.player || p.isRemoved()) continue;
                if (Social.isFriend(p.getName().getString())) {
                    GLOWING.add(p.getId());
                    seen.add(p.getId());
                }
            }
        }
        Iterator<Integer> it = GLOWING.iterator();
        while (it.hasNext()) if (!seen.contains(it.next())) it.remove();
    }

    public static void clear() { GLOWING.clear(); }

    // ------------------------------------------------------------------ chat click

    private static boolean shiftDown() {
        var w = MinecraftClient.getInstance().getWindow();
        return InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_LEFT_SHIFT) || InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    /**
     * Called by ChatScreenMixin on a left click in the open chat (x / y = gui coordinates).
     * Returns true when the click hit a nick and was used (the vanilla click is then skipped).
     */
    public static boolean onChatClick(double x, double y) {
        if (!active() || !chatClick.b()) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return false;
        String name = ChatPick.nameAt(mc, x, y);
        if (name == null) return false;
        if (name.equalsIgnoreCase(mc.player.getName().getString())) return false;   // you can not friend yourself

        if (shiftDown()) {
            boolean now = Social.toggleAdmin(name);
            say(mc, name + (now ? " is now marked as ADMIN" : " is no longer marked as admin"),
                    now ? Formatting.RED : Formatting.GRAY);
        } else {
            boolean now = Social.toggleFriend(name);
            say(mc, name + (now ? " is now your friend" : " is no longer your friend"),
                    now ? Formatting.GREEN : Formatting.GRAY);
        }
        return true;
    }

    public static void say(MinecraftClient mc, String s, Formatting f) {
        if (message != null && !message.b()) return;
        if (mc.player != null) mc.player.sendMessage(Text.literal(s).formatted(f), true);   // action bar
    }
}
