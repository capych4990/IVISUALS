package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

/**
 * Fullbright, two layers so it works even if one of them is ignored:
 *  1) gamma is forced far above the normal slider range (the classic fullbright);
 *  2) a client-side, particle-free Night Vision effect is kept alive.
 * Everything is restored when the module is switched off or the game closes.
 */
public final class Fullbright {
    private Fullbright() {}

    private static final double GAMMA = 16.0;

    private static Field valueField;
    private static boolean fieldSearched;
    private static Object savedGamma;
    private static boolean gammaForced;
    private static boolean effectAddedByUs;

    private static Field valueField() {
        if (!fieldSearched) {
            fieldSearched = true;
            // SimpleOption<T> has exactly one non-static, non-final field of erased type Object: the value.
            for (Field f : SimpleOption.class.getDeclaredFields()) {
                int mod = f.getModifiers();
                if (!Modifier.isStatic(mod) && !Modifier.isFinal(mod) && f.getType() == Object.class) {
                    try {
                        f.setAccessible(true);
                        valueField = f;
                    } catch (Throwable ignored) {}
                    break;
                }
            }
        }
        return valueField;
    }

    @SuppressWarnings("unchecked")
    private static void setGamma(MinecraftClient mc, Object value) {
        Field f = valueField();
        if (f == null) return;
        try {
            f.set(mc.options.getGamma(), value);
        } catch (Throwable ignored) {}
    }

    public static void tick(MinecraftClient mc) {
        if (mc.options == null) return;

        // layer 1: gamma
        Field f = valueField();
        if (f != null) {
            try {
                Object cur = f.get(mc.options.getGamma());
                if (!gammaForced) {
                    savedGamma = cur;
                    gammaForced = true;
                }
                if (!(cur instanceof Double d) || d != GAMMA) setGamma(mc, GAMMA);
            } catch (Throwable ignored) {}
        }

        // layer 2: night vision
        if (mc.player != null) {
            StatusEffectInstance cur = mc.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 400) {
                mc.player.addStatusEffect(new StatusEffectInstance(
                        StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
                effectAddedByUs = true;
            }
        }
    }

    public static void disable(MinecraftClient mc) {
        if (mc == null) return;
        if (gammaForced && mc.options != null) {
            setGamma(mc, savedGamma != null ? savedGamma : (Object) 0.5);
        }
        gammaForced = false;
        savedGamma = null;
        if (effectAddedByUs && mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        effectAddedByUs = false;
    }
}
