package com.ivisuals;

import java.util.ArrayList;
import java.util.List;

/** A see-through wireframe player model (head, body, arms, legs) drawn as a 2D overlay. No Minecraft classes. */
public final class GhostGfx {
    private GhostGfx() {}

    // {minX, maxX, minY, maxY, minZ, maxZ} in model space (x = to the right, z = forward), feet at y = 0
    private static final double[][] PARTS = {
            {-0.225, 0.225, 1.350, 1.800, -0.225, 0.225},   // head
            {-0.225, 0.225, 0.675, 1.350, -0.1125, 0.1125}, // body
            {-0.450, -0.225, 0.675, 1.350, -0.1125, 0.1125},// right arm
            {0.225, 0.450, 0.675, 1.350, -0.1125, 0.1125},  // left arm
            {-0.225, 0.000, 0.000, 0.675, -0.1125, 0.1125}, // right leg
            {0.000, 0.225, 0.000, 0.675, -0.1125, 0.1125},  // left leg
    };

    private static final int[][] FACES = {
            {0, 1, 3, 2}, {4, 5, 7, 6}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 2, 6, 4}, {1, 3, 7, 5}};
    private static final int[][] EDGES = {
            {0, 1}, {1, 3}, {3, 2}, {2, 0}, {4, 5}, {5, 7}, {7, 6}, {6, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};

    /** Draws the model with its feet at (x, y, z), turned by yawDeg (Minecraft convention). */
    public static void draw(Canvas c, Proj cam, double x, double y, double z, float yawDeg,
                            int rgb, float alpha, int lineW) {
        double yaw = Math.toRadians(yawDeg);
        double rx = -Math.cos(yaw), rz = -Math.sin(yaw);     // model +x in world
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);      // model +z (forward) in world

        for (double[] p : PARTS) {
            double[][] w = new double[8][];
            double[][] v = new double[8][];
            for (int i = 0; i < 8; i++) {
                double lx = (i & 1) == 0 ? p[0] : p[1];
                double ly = (i & 2) == 0 ? p[2] : p[3];
                double lz = (i & 4) == 0 ? p[4] : p[5];
                w[i] = new double[]{x + rx * lx + fx * lz, y + ly, z + rz * lx + fz * lz};
                v[i] = cam.view(w[i][0], w[i][1], w[i][2]);
            }
            double cx = x + (rx * (p[0] + p[1]) + fx * (p[4] + p[5])) / 2, cy = y + (p[2] + p[3]) / 2,
                    cz = z + (rz * (p[0] + p[1]) + fz * (p[4] + p[5])) / 2;

            // translucent faces turned to the camera
            for (int[] f : FACES) {
                double[] a = w[f[0]], b = w[f[1]], d = w[f[3]];
                double ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
                double tx = d[0] - a[0], ty = d[1] - a[1], tz = d[2] - a[2];
                double nx = uy * tz - uz * ty, ny = uz * tx - ux * tz, nz = ux * ty - uy * tx;
                double mx = (a[0] + w[f[2]][0]) / 2, my = (a[1] + w[f[2]][1]) / 2, mz = (a[2] + w[f[2]][2]) / 2;
                double outx = mx - cx, outy = my - cy, outz = mz - cz;
                if (nx * outx + ny * outy + nz * outz < 0) { nx = -nx; ny = -ny; nz = -nz; }
                if (nx * (cam.cx - mx) + ny * (cam.cy - my) + nz * (cam.cz - mz) <= 0) continue;
                List<double[]> poly = new ArrayList<>();
                for (int k = 0; k < 4; k++) poly.add(v[f[k]]);
                poly = Proj.clipPoly(poly);
                if (poly.size() < 3) continue;
                double[] xs = new double[poly.size()], ys = new double[poly.size()];
                for (int i = 0; i < poly.size(); i++) {
                    double[] s = cam.screen(poly.get(i));
                    xs[i] = s[0];
                    ys[i] = s[1];
                }
                Fx.fillPoly(c, cam.sw, cam.sh, xs, ys, poly.size(), Fx.withAlpha(rgb, alpha * 0.16f));
            }

            // glowing edges
            for (int[] e : EDGES) {
                double[][] seg = Proj.clipSegment(v[e[0]], v[e[1]]);
                if (seg == null) continue;
                double[] s0 = cam.screen(seg[0]), s1 = cam.screen(seg[1]);
                Fx.line(c, cam.sw, cam.sh, s0[0], s0[1], s1[0], s1[1], lineW + 2, Fx.withAlpha(rgb, alpha * 0.12f));
                Fx.line(c, cam.sw, cam.sh, s0[0], s0[1], s1[0], s1[1], lineW, Fx.withAlpha(rgb, alpha));
            }
        }

        // a short line on the face shows where the model looks
        double[] a = cam.view(x + fx * 0.225, y + 1.62, z + fz * 0.225);
        double[] b = cam.view(x + fx * 0.75, y + 1.62, z + fz * 0.75);
        double[][] seg = Proj.clipSegment(a, b);
        if (seg != null) {
            double[] s0 = cam.screen(seg[0]), s1 = cam.screen(seg[1]);
            Fx.line(c, cam.sw, cam.sh, s0[0], s0[1], s1[0], s1[1], lineW, Fx.withAlpha(rgb, alpha * 0.9f));
        }
    }
}
