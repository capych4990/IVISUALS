package com.ivisuals;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

/** Size / position / rotation of the main hand and the off hand (items follow the hand). */
public final class HandTweaks {
    private HandTweaks() {}

    private static final String[] NAMES = {"Scale", "X", "Y", "Z", "Rot X", "Rot Y", "Rot Z"};
    private static final Setting[] MAIN = new Setting[7];
    private static final Setting[] OFF = new Setting[7];

    public static void setup(Module m) {
        for (int h = 0; h < 2; h++) {
            String pre = h == 0 ? "Main " : "Off ";
            Setting[] t = h == 0 ? MAIN : OFF;
            t[0] = m.slider(pre + NAMES[0], 1f, 0.1f, 2.5f, 0.05f);
            for (int i = 1; i <= 3; i++) t[i] = m.slider(pre + NAMES[i], 0f, -1f, 1f, 0.02f);
            for (int i = 4; i <= 6; i++) t[i] = m.slider(pre + NAMES[i], 0f, -180f, 180f, 5f);
        }
    }

    /** {x, y, z, scale} currently applied to a hand (zeros / 1 when Hand Tweaks is off). Used by Held Glow. */
    public static float[] offset(boolean mainHand) {
        if (!ModuleManager.HANDS.enabled) return new float[]{0f, 0f, 0f, 1f};
        Setting[] s = mainHand ? MAIN : OFF;
        return new float[]{s[1].f(), s[2].f(), s[3].f(), s[0].f()};
    }

    /** Applied at the start of the first-person hand render, around the hand's own pivot. */
    public static void apply(MatrixStack m, Arm arm, boolean mainHand) {
        Setting[] s = mainHand ? MAIN : OFF;
        float sc = s[0].f();
        float side = arm == Arm.RIGHT ? 1f : -1f;
        // where the hand sits in camera space (vanilla item position)
        float px = 0.56f * side, py = -0.52f, pz = -0.72f;
        m.translate(px + s[1].f(), py + s[2].f(), pz + s[3].f());
        if (s[4].f() != 0f) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(s[4].f()));
        if (s[5].f() != 0f) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(s[5].f()));
        if (s[6].f() != 0f) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(s[6].f()));
        m.scale(sc, sc, sc);
        m.translate(-px, -py, -pz);
    }
}
