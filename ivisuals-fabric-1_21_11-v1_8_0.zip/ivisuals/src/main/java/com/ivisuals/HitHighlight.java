package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The entity you hit glows (in a color you pick) for a set time. Players / mobs / both.
 *
 * FIX 1.6.0: the old version called entity.setGlowing(true) on the client, which does nothing there (the glow flag is
 * only written on the server side), so nothing ever lit up. Now EntityMixin answers "isGlowing" itself for the ids
 * listed here (see glows()), so it works on every server.
 */
public final class HitHighlight {
    private HitHighlight() {}

    private static final class Rec {
        volatile long end;
        volatile boolean on = true;
    }

    private static final Map<Integer, Rec> ACTIVE = new ConcurrentHashMap<>();
    private static Setting targets, duration, color, blink;

    public static void setup(Module m) {
        targets = m.mode("Targets", 2, "Players", "Mobs", "Players + Mobs");
        duration = m.slider("Duration (s)", 3f, 0.5f, 15f, 0.5f);
        color = m.mode("Color", 0, Fx.COLORS);
        blink = m.toggle("Blink at end", true);
    }

    private static boolean accepts(Entity e) {
        int t = targets.i();
        if (e instanceof PlayerEntity) return t == 0 || t == 2;
        if (e instanceof LivingEntity) return t == 1 || t == 2;
        return false;
    }

    public static void onAttack(Entity e) {
        if (!ModuleManager.HIT_HIGHLIGHT.enabled || e == null || !accepts(e)) return;
        Rec r = ACTIVE.computeIfAbsent(e.getId(), k -> new Rec());
        r.end = System.currentTimeMillis() + (long) (duration.f() * 1000f);
        r.on = true;
    }

    /** Used by EntityMixin.isGlowing: true while this entity should show the outline (client thread only). */
    public static boolean glows(int entityId) {
        if (ACTIVE.isEmpty()) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || !mc.isOnThread()) return false;      // the integrated server must not see our client-only glow
        Rec r = ACTIVE.get(entityId);
        return r != null && r.on;
    }

    /** Outline color for the render hook (RGB) or null when the entity is not highlighted. */
    public static Integer colorFor(int entityId) {
        if (ACTIVE.isEmpty() || !ACTIVE.containsKey(entityId)) return null;
        return Fx.color(color.i(), HudFx.time(), (entityId % 7) / 7f);
    }

    public static void tick(MinecraftClient mc) {
        if (ACTIVE.isEmpty() || mc.world == null) return;
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<Integer, Rec>> it = ACTIVE.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Rec> en = it.next();
            Entity e = mc.world.getEntityById(en.getKey());
            Rec r = en.getValue();
            long left = r.end - now;
            if (e == null || !e.isAlive() || left <= 0) {
                it.remove();
                continue;
            }
            r.on = !(blink.b() && left < 700) || ((now / 90) % 2) == 0;
        }
    }

    /** Remove every highlight (module switched off / world left). */
    public static void clear(MinecraftClient mc) {
        ACTIVE.clear();
    }
}
