package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/** Custom particles when you hit something: dollars, ducks, crowns, hearts, sparks or vanilla crits. */
public final class HitParticles {
    private HitParticles() {}

    private static final String[] STYLES = {"Dollar", "Duck", "Crown", "Heart", "Spark", "Mix", "Vanilla"};
    private static final Particles2D SYS = new Particles2D();
    private static long lastNano;

    private static Setting style, count, size, life, gravity, speed;

    public static void setup(Module m) {
        style = m.mode("Particle", 5, STYLES);
        count = m.slider("Amount", 8f, 1f, 40f, 1f);
        size = m.slider("Size", 1f, 0.3f, 3f, 0.1f);
        life = m.slider("Lifetime (s)", 1.1f, 0.3f, 4f, 0.1f);
        gravity = m.slider("Gravity", 1f, 0f, 2.5f, 0.1f);
        speed = m.slider("Speed", 1f, 0.3f, 3f, 0.1f);
    }

    public static void clear() { SYS.clear(); }

    public static void onAttack(MinecraftClient mc, Entity target) {
        if (!ModuleManager.HIT_PARTICLES.enabled || target == null) return;
        Box bb = target.getBoundingBox();
        Vec3d c = bb.getCenter();
        double x = c.x, y = bb.minY + (bb.maxY - bb.minY) * 0.65, z = c.z;
        Random r = SYS.rnd();
        int n = Math.round(count.f());
        int st = style.i();

        if (st == 6) {                                            // vanilla particles
            for (int i = 0; i < n; i++) {
                mc.particleManager.addParticle(ParticleTypes.CRIT, x, y, z,
                        (r.nextDouble() - 0.5) * 0.8 * speed.f(),
                        (r.nextDouble() * 0.6 + 0.1) * speed.f(),
                        (r.nextDouble() - 0.5) * 0.8 * speed.f());
            }
            return;
        }
        for (int i = 0; i < n; i++) {
            Sprites.Sprite spr = switch (st) {
                case 0 -> Sprites.DOLLAR;
                case 1 -> Sprites.DUCK;
                case 2 -> Sprites.CROWN;
                case 3 -> Sprites.HEART;
                case 4 -> Sprites.SPARK;
                default -> Sprites.MIX[r.nextInt(Sprites.MIX.length)];
            };
            int tint = Fx.hsv(r.nextFloat() * 0.15f + 0.08f, 0.5f + r.nextFloat() * 0.5f, 1f);
            float sz = spr == Sprites.SPARK ? size.f() * 0.35f : size.f() * 0.55f;
            SYS.spawn(x, y, z, spr, tint, speed.f(), life.f(), sz);
        }
    }

    public static void render(DrawContext ctx, MinecraftClient mc, float tickProgress) {
        long now = System.nanoTime();
        float dt = lastNano == 0 ? 0.016f : Math.min((now - lastNano) / 1e9f, 0.1f);
        lastNano = now;
        if (!ModuleManager.HIT_PARTICLES.enabled || mc.world == null) { SYS.clear(); return; }
        if (SYS.isEmpty()) return;
        SYS.update(dt, gravity.f());
        Proj cam = HudFx.camera(mc, tickProgress);
        if (cam != null) SYS.draw(HudFx.canvas(ctx), cam);
    }
}
