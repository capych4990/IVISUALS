package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Glue between the game and the pure overlay code (Proj / Canvas). */
public final class HudFx {
    private HudFx() {}

    public static Canvas canvas(DrawContext ctx) {
        return (x1, y1, x2, y2, argb) -> ctx.fill(x1, y1, x2, y2, argb);
    }

    /** Camera of the local player in first person, or null (third person, no world...). */
    public static Proj camera(MinecraftClient mc, float tickProgress) {
        PlayerEntity p = mc.player;
        if (p == null || mc.world == null) return null;
        if (!mc.options.getPerspective().isFirstPerson()) return null;
        Vec3d pos = p.getCameraPosVec(tickProgress);
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        double fov = mc.options.getFov().getValue();
        return new Proj(pos.x, pos.y, pos.z, p.getYaw(tickProgress), p.getPitch(tickProgress), fov, sw, sh);
    }

    public static float time() {
        return (System.currentTimeMillis() % 1_000_000L) / 1000f;
    }
}
