package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** A movable / resizable on-screen element. Content is drawn in local coords (0..w, 0..h). */
public abstract class HudWidget {
    public final String id;
    public final String title;
    public final String moduleName;
    public int x, y;
    public float scale = 1f;

    protected HudWidget(String id, String title, String moduleName, int x, int y) {
        this.id = id;
        this.title = title;
        this.moduleName = moduleName;
        this.x = x;
        this.y = y;
    }

    /** Unscaled size. */
    public abstract int w();
    public abstract int h();

    protected abstract void content(DrawContext c, MinecraftClient mc);

    public boolean enabled() { return ModuleManager.isOn(moduleName); }

    /** On-screen (scaled) size. */
    public int sw() { return Math.round(w() * scale); }
    public int sh() { return Math.round(h() * scale); }

    public void clamp(int screenW, int screenH) {
        x = Math.max(0, Math.min(x, Math.max(0, screenW - sw())));
        y = Math.max(0, Math.min(y, Math.max(0, screenH - sh())));
    }

    public boolean contains(double mx, double my) {
        return mx >= x && mx <= x + sw() && my >= y && my <= y + sh();
    }

    public void draw(DrawContext c, MinecraftClient mc, int screenW, int screenH) {
        clamp(screenW, screenH);
        var m = c.getMatrices();
        m.pushMatrix();
        m.translate((float) x, (float) y);
        m.scale(scale, scale);
        content(c, mc);
        m.popMatrix();
    }
}
