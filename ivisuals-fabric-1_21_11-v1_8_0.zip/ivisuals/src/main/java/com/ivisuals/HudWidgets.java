package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class HudWidgets {
    private HudWidgets() {}

    public static final HudWidget INVENTORY = new InventoryWidget();
    public static final HudWidget ARMOR = new ArmorWidget();
    public static final HudWidget INFO = new InfoWidget();
    public static final HudWidget EFFECTS = new EffectsWidget();
    public static final HudWidget KEYBINDS = new KeybindsWidget();
    public static final List<HudWidget> ALL = List.of(INVENTORY, ARMOR, INFO, EFFECTS, KEYBINDS);

    // options of the Info widget (module "Info")
    private static Setting infoName, infoFps, infoPing;

    public static void setupInfo(Module m) {
        infoName = m.toggle("Show Name", true);
        infoFps = m.toggle("Show FPS", true);
        infoPing = m.toggle("Show Ping", true);
    }

    private static final int WHITE = 0xFFFFFF;

    private static void glass(DrawContext c, int w, int h) {
        Draw.roundRectV(c, 0, 0, w, h, 6, Draw.argb(170, 0x131316), Draw.argb(170, 0x070709));
        int ac = Theme.accent(Neon.now());
        Draw.ring(c, 0, 0, w, h, 6, Draw.argb(120, ac), Draw.argb(30, ac));
    }

    // ------------------------------------------------------------------
    /** Client name, FPS and ping in one small pill. */
    private static final class InfoWidget extends HudWidget {
        InfoWidget() { super("info", "Info", "Info", 184, 6); }

        private static int ping(MinecraftClient mc) {
            try {
                if (mc.player == null || mc.getNetworkHandler() == null) return 0;
                var e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                return e == null ? 0 : e.getLatency();
            } catch (Exception ex) {
                return 0;
            }
        }

        private static int pingColor(int ms) {
            return ms < 60 ? 0xFF46D369 : ms < 130 ? 0xFFF5C542 : 0xFFE5484D;
        }

        private static int fpsColor(int fps) {
            return fps >= 100 ? 0xFF46D369 : fps >= 40 ? 0xFFF5C542 : 0xFFE5484D;
        }

        /** The parts that are switched on: {text, argb}. */
        private static java.util.List<Object[]> parts(MinecraftClient mc) {
            java.util.List<Object[]> out = new java.util.ArrayList<>();
            float t = Neon.now();
            if (infoName == null || infoName.b()) out.add(new Object[]{"Ivisuals", Draw.argb(255, Neon.strong(t, 0f))});
            if (infoFps == null || infoFps.b()) {
                int fps = mc.getCurrentFps();
                out.add(new Object[]{fps + " FPS", fpsColor(fps)});
            }
            if (infoPing == null || infoPing.b()) {
                int ms = ping(mc);
                out.add(new Object[]{ms + " ms", pingColor(ms)});
            }
            return out;
        }

        @Override public int w() {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.textRenderer == null) return 100;
            int w = 12;
            var list = parts(mc);
            for (int i = 0; i < list.size(); i++) {
                w += mc.textRenderer.getWidth((String) list.get(i)[0]);
                if (i > 0) w += 11;
            }
            return Math.max(40, w);
        }

        @Override public int h() { return 18; }

        @Override
        protected void content(DrawContext c, MinecraftClient mc) {
            int W = w(), H = h();
            glass(c, W, H);
            var list = parts(mc);
            int x = 6;
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) {
                    c.fill(x + 4, 4, x + 5, H - 4, Draw.argb(60, WHITE));
                    x += 11;
                }
                String s = (String) list.get(i)[0];
                c.drawText(mc.textRenderer, s, x, 5, (Integer) list.get(i)[1], false);
                x += mc.textRenderer.getWidth(s);
            }
        }
    }

    // ------------------------------------------------------------------
    /** The 27 inner inventory slots (NOT the hotbar). */
    private static final class InventoryWidget extends HudWidget {
        private static ItemStack[] sample;

        InventoryWidget() { super("inventory", "Inventory", "Inventory HUD", 6, 6); }

        @Override public int w() { return 9 * 18 + 8; }
        @Override public int h() { return 3 * 18 + 8; }

        private static ItemStack[] sample() {
            if (sample == null) {
                sample = new ItemStack[27];
                java.util.Arrays.fill(sample, ItemStack.EMPTY);
                sample[0] = new ItemStack(Items.DIAMOND_PICKAXE);
                sample[1] = new ItemStack(Items.GOLDEN_APPLE, 5);
                sample[2] = new ItemStack(Items.COBBLESTONE, 64);
                sample[10] = new ItemStack(Items.ENDER_PEARL, 16);
                sample[13] = new ItemStack(Items.TORCH, 32);
                sample[20] = new ItemStack(Items.OAK_LOG, 48);
            }
            return sample;
        }

        @Override
        protected void content(DrawContext c, MinecraftClient mc) {
            glass(c, w(), h());
            for (int r = 0; r < 3; r++) {
                for (int col = 0; col < 9; col++) {
                    int sx = 4 + col * 18, sy = 4 + r * 18;
                    c.fill(sx + 1, sy + 1, sx + 17, sy + 17, Draw.argb(26, WHITE));
                    int idx = r * 9 + col;
                    ItemStack s = mc.player != null ? mc.player.getInventory().getStack(9 + idx) : sample()[idx];
                    if (s != null && !s.isEmpty()) {
                        c.drawItem(s, sx + 1, sy + 1);
                        c.drawStackOverlay(mc.textRenderer, s, sx + 1, sy + 1);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    /** Durability of the four armor pieces. */
    private static final class ArmorWidget extends HudWidget {
        private static final EquipmentSlot[] SLOTS =
                {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        private static ItemStack[] sample;

        ArmorWidget() { super("armor", "Armor", "Armor HUD", 6, 80); }

        @Override public int w() { return 118; }
        @Override public int h() { return 4 * 20 + 6; }

        private static ItemStack[] sample() {
            if (sample == null) {
                sample = new ItemStack[]{
                        new ItemStack(Items.DIAMOND_HELMET), new ItemStack(Items.DIAMOND_CHESTPLATE),
                        new ItemStack(Items.DIAMOND_LEGGINGS), new ItemStack(Items.DIAMOND_BOOTS)};
                sample[0].setDamage(40);
                sample[1].setDamage(300);
                sample[2].setDamage(150);
                sample[3].setDamage(20);
            }
            return sample;
        }

        private static int healthColor(float f) {
            int red = 0xFFE5484D, yellow = 0xFFF5C542, green = 0xFF46D369;
            return f > 0.5f ? Draw.lerp(yellow, green, (f - 0.5f) * 2f) : Draw.lerp(red, yellow, f * 2f);
        }

        @Override
        protected void content(DrawContext c, MinecraftClient mc) {
            glass(c, w(), h());
            int W = w();
            for (int i = 0; i < 4; i++) {
                int ry = 3 + i * 20;
                ItemStack s = mc.player != null ? mc.player.getEquippedStack(SLOTS[i]) : sample()[i];
                if (s == null || s.isEmpty()) {
                    c.drawText(mc.textRenderer, "-", 26, ry + 6, Draw.argb(90, WHITE), false);
                    continue;
                }
                c.drawItem(s, 4, ry + 2);
                if (s.isDamageable()) {
                    int max = s.getMaxDamage();
                    int left = Math.max(0, max - s.getDamage());
                    float f = max <= 0 ? 0f : (float) left / max;
                    int col = healthColor(f);
                    c.drawText(mc.textRenderer, left + "/" + max, 26, ry + 3, col, false);
                    String pct = Math.round(f * 100f) + "%";
                    c.drawText(mc.textRenderer, pct, W - 4 - mc.textRenderer.getWidth(pct), ry + 3,
                            Draw.argb(170, WHITE), false);
                    int bx = 26, bw = W - 4 - bx;
                    c.fill(bx, ry + 14, bx + bw, ry + 16, Draw.argb(50, WHITE));
                    c.fill(bx, ry + 14, bx + Math.max(1, Math.round(bw * f)), ry + 16, col);
                } else {
                    c.drawText(mc.textRenderer, "no durability", 26, ry + 6, Draw.argb(110, WHITE), false);
                }
            }
        }
    }

    // ------------------------------------------------------------------
    /** Every active potion effect with its level and the time that is left. */
    private static final class EffectsWidget extends HudWidget {
        private static final class Row {
            String name, time;
            float frac;
            boolean good;
            int ticks;      // < 0 = no end
        }

        /** Longest duration seen per effect, so that the bar can show "how much is left". */
        private static final Map<String, Integer> MAX = new HashMap<>();

        EffectsWidget() { super("effects", "Effects", "Effects HUD", 6, 172); }

        private static String roman(int n) {
            String[] r = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
            return n >= 0 && n < r.length ? r[n] : String.valueOf(n);
        }

        private static String time(int ticks) {
            if (ticks < 0) return "inf";
            int s = (ticks + 19) / 20;
            if (s >= 3600) return String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
            return String.format("%d:%02d", s / 60, s % 60);
        }

        private static Row row(String name, int ticks, int max, boolean good) {
            Row r = new Row();
            r.name = name;
            r.ticks = ticks;
            r.time = time(ticks);
            r.good = good;
            r.frac = ticks < 0 ? 1f : Math.max(0f, Math.min(1f, max <= 0 ? 1f : (float) ticks / max));
            return r;
        }

        private static List<Row> sample() {
            List<Row> l = new ArrayList<>();
            l.add(row("Speed II", 20 * 95, 20 * 180, true));
            l.add(row("Strength", 20 * 24, 20 * 90, true));
            l.add(row("Poison", 20 * 8, 20 * 20, false));
            return l;
        }

        private static boolean editor(MinecraftClient mc) { return mc.currentScreen instanceof MenuScreen; }

        /** Real rows (empty when you have no effects). */
        private static List<Row> real(MinecraftClient mc) {
            List<Row> out = new ArrayList<>();
            if (mc.player == null) return out;
            Set<String> alive = new HashSet<>();
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                StatusEffect fx = e.getEffectType().value();
                String name = fx.getName().getString();
                if (e.getAmplifier() > 0) name += " " + roman(e.getAmplifier() + 1);
                String key = name;
                alive.add(key);
                int ticks = e.isInfinite() ? -1 : e.getDuration();
                if (ticks >= 0) MAX.merge(key, ticks, Math::max);
                out.add(row(name, ticks, MAX.getOrDefault(key, ticks), fx.getCategory() == StatusEffectCategory.BENEFICIAL));
            }
            MAX.keySet().retainAll(alive);
            // good effects first, then the ones that end soonest
            out.sort((a, b) -> {
                if (a.good != b.good) return a.good ? -1 : 1;
                int ta = a.ticks < 0 ? Integer.MAX_VALUE : a.ticks, tb = b.ticks < 0 ? Integer.MAX_VALUE : b.ticks;
                return Integer.compare(ta, tb);
            });
            return out;
        }

        private static List<Row> rows(MinecraftClient mc) {
            List<Row> r = real(mc);
            if (r.isEmpty() && editor(mc)) return sample();
            return r;
        }

        private static final int ROW_H = 16;

        private int widthOf(MinecraftClient mc, List<Row> rows) {
            if (mc.textRenderer == null) return 120;
            int nw = 0, tw = 0;
            for (Row r : rows) {
                nw = Math.max(nw, mc.textRenderer.getWidth(r.name));
                tw = Math.max(tw, mc.textRenderer.getWidth(r.time));
            }
            return Math.max(110, 12 + nw + 14 + tw + 8);
        }

        @Override public int w() {
            MinecraftClient mc = MinecraftClient.getInstance();
            List<Row> r = rows(mc);
            return widthOf(mc, r.isEmpty() ? sample() : r);
        }

        @Override public int h() {
            MinecraftClient mc = MinecraftClient.getInstance();
            List<Row> r = rows(mc);
            return 6 + (r.isEmpty() ? 3 : r.size()) * ROW_H;
        }

        @Override
        protected void content(DrawContext c, MinecraftClient mc) {
            List<Row> rows = rows(mc);
            if (rows.isEmpty()) return;                       // no effects = nothing on screen
            int W = widthOf(mc, rows), H = 6 + rows.size() * ROW_H;
            glass(c, W, H);
            for (int i = 0; i < rows.size(); i++) {
                Row r = rows.get(i);
                int ry = 3 + i * ROW_H;
                int col = r.good ? 0xFF46D369 : 0xFFE5484D;
                c.fill(5, ry + 2, 7, ry + ROW_H - 3, col);                              // good / bad mark
                c.drawText(mc.textRenderer, r.name, 11, ry + 2, Draw.argb(240, WHITE), false);
                int tc = r.ticks < 0 ? Draw.argb(200, WHITE)
                        : r.ticks < 200 ? 0xFFE5484D : r.ticks < 600 ? 0xFFF5C542 : Draw.argb(230, WHITE);
                c.drawText(mc.textRenderer, r.time, W - 6 - mc.textRenderer.getWidth(r.time), ry + 2, tc, false);
                int bx = 11, bw = W - 6 - bx;                                          // time left bar
                c.fill(bx, ry + 12, bx + bw, ry + 13, Draw.argb(45, WHITE));
                c.fill(bx, ry + 12, bx + Math.max(1, Math.round(bw * r.frac)), ry + 13, col);
            }
        }
    }

    // ------------------------------------------------------------------
    /** All keys you bound in the menu (Alt + key on a card). */
    private static final class KeybindsWidget extends HudWidget {
        private static final class Row {
            String key, name;
            boolean on;
        }

        KeybindsWidget() { super("keybinds", "Keybinds", "Keybinds HUD", 184, 30); }

        private static final int ROW_H = 14;

        private static List<Row> sample() {
            List<Row> l = new ArrayList<>();
            Row a = new Row(); a.key = "R"; a.name = "Quick Swap 1  Ender Pearl > Main Hand"; a.on = true; l.add(a);
            Row b = new Row(); b.key = "G"; b.name = "Fullbright"; b.on = true; l.add(b);
            Row c = new Row(); c.key = "H"; c.name = "Trajectories"; c.on = false; l.add(c);
            return l;
        }

        private static List<Row> real() {
            List<Row> out = new ArrayList<>();
            for (Module m : ModuleManager.MODULES) {
                if (m.bind == Module.NO_KEY) continue;
                Row r = new Row();
                r.key = MenuScreen.keyName(m.bind);
                r.name = m.name;
                if (m.name.startsWith("Quick Swap ")) {
                    try {
                        int idx = Integer.parseInt(m.name.substring("Quick Swap ".length()).trim()) - 1;
                        String d = QuickSwap.describe(idx);
                        if (!d.isEmpty()) r.name += "  " + d;
                    } catch (Exception ignored) {}
                }
                r.on = m.enabled;
                out.add(r);
            }
            return out;
        }

        private static List<Row> rows(MinecraftClient mc) {
            List<Row> r = real();
            if (r.isEmpty() && mc.currentScreen instanceof MenuScreen) return sample();
            return r;
        }

        private static int keyW(MinecraftClient mc, String key) { return mc.textRenderer.getWidth(key) + 8; }

        private int widthOf(MinecraftClient mc, List<Row> rows) {
            if (mc.textRenderer == null) return 120;
            int kw = 0, nw = 0;
            for (Row r : rows) {
                kw = Math.max(kw, keyW(mc, r.key));
                nw = Math.max(nw, mc.textRenderer.getWidth(r.name));
            }
            return Math.max(100, 5 + kw + 6 + nw + 8);
        }

        @Override public int w() {
            MinecraftClient mc = MinecraftClient.getInstance();
            List<Row> r = rows(mc);
            return widthOf(mc, r.isEmpty() ? sample() : r);
        }

        @Override public int h() {
            MinecraftClient mc = MinecraftClient.getInstance();
            List<Row> r = rows(mc);
            return 6 + (r.isEmpty() ? 3 : r.size()) * ROW_H;
        }

        @Override
        protected void content(DrawContext c, MinecraftClient mc) {
            List<Row> rows = rows(mc);
            if (rows.isEmpty()) return;                       // no binds = nothing on screen
            int W = widthOf(mc, rows), H = 6 + rows.size() * ROW_H;
            int kw = 0;
            for (Row r : rows) kw = Math.max(kw, keyW(mc, r.key));
            glass(c, W, H);
            int ac = Theme.accent(Neon.now());
            for (int i = 0; i < rows.size(); i++) {
                Row r = rows.get(i);
                int ry = 3 + i * ROW_H;
                int a = r.on ? 255 : 110;                      // a bound module that is switched off is dimmed
                Draw.roundRectV(c, 5, ry + 1, kw, ROW_H - 2, 4, Draw.argb(a / 4, WHITE), Draw.argb(a / 9, WHITE));
                Draw.ring(c, 5, ry + 1, kw, ROW_H - 2, 4, Draw.argb(a * 2 / 3, ac), Draw.argb(a / 5, ac));
                c.drawText(mc.textRenderer, r.key, 5 + (kw - mc.textRenderer.getWidth(r.key)) / 2, ry + 3,
                        Draw.argb(a, WHITE), false);
                c.drawText(mc.textRenderer, r.name, 5 + kw + 6, ry + 3, Draw.argb(a * 9 / 10, WHITE), false);
            }
        }
    }
}
