package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/** Keeps the movement keys working while an inventory/container screen is open. */
public final class InventoryMove {
    private InventoryMove() {}

    public static void tick(MinecraftClient mc) {
        Screen s = mc.currentScreen;
        if (!(s instanceof HandledScreen<?>)) return;
        // screens with a text field: typing must not move the player
        if (s instanceof AnvilScreen || s instanceof CreativeInventoryScreen) return;
        if (mc.player == null || mc.getWindow() == null) return;

        GameOptions o = mc.options;
        KeyBinding[] keys = {o.forwardKey, o.backKey, o.leftKey, o.rightKey, o.jumpKey, o.sneakKey, o.sprintKey};
        for (KeyBinding kb : keys) {
            InputUtil.Key k = InputUtil.fromTranslationKey(kb.getBoundKeyTranslationKey());
            if (k.getCategory() == InputUtil.Type.KEYSYM) {
                kb.setPressed(InputUtil.isKeyPressed(mc.getWindow(), k.getCode()));
            }
        }
    }
}
