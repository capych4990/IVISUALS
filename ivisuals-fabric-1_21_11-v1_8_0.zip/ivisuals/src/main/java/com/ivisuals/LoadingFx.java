package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/**
 * Startup screen: black background, white neon shapes drifting across it and the "IVISUALS" title drawn
 * with glowing strokes (own vector letters, so it does not need the game's fonts - they are not loaded yet).
 * Drawn on top of the vanilla loading overlay, then faded out over the title screen.
 */
public final class LoadingFx {
    private LoadingFx() {}

    private static long t0 = -1, fadeStart = -1;
    private static boolean sawOverlay, done;

    private static final int N = 26;
    // x, y, vx, vy, size, rot, rotSpeed, sides, phase, inner
    private static final float[][] SH = new float[N][];

    static {
        Random r = new Random(1337);
        int[] sides = {3, 4, 5, 6, 24, 4, 8};
        for (int i = 0; i < N; i++) {
            SH[i] = new float[]{
                    r.nextFloat(), r.nextFloat(),
                    (r.nextFloat() - 0.5f) * 0.035f, (r.nextFloat() - 0.5f) * 0.02f - 0.004f,
                    10 + r.nextFloat() * 46,
                    r.nextFloat() * 6.28f, (r.nextFloat() - 0.5f) * 0.9f,
                    sides[r.nextInt(sides.length)],
                    r.nextFloat() * 6.28f,
                    r.nextFloat() < 0.4f ? 1 : 0};
        }
    }

    // letter strokes in a 0.6 x 1 box (y down). Several polylines per letter.
    private static float[][][] letter(char c) {
        return switch (c) {
            case 'I' -> new float[][][]{{{0.3f, 0}, {0.3f, 1}}};
            case 'V' -> new float[][][]{{{0, 0}, {0.3f, 1}, {0.6f, 0}}};
            case 'S' -> new float[][][]{{{0.6f, 0}, {0, 0}, {0, 0.5f}, {0.6f, 0.5f}, {0.6f, 1}, {0, 1}}};
            case 'U' -> new float[][][]{{{0, 0}, {0, 1}, {0.6f, 1}, {0.6f, 0}}};
            case 'A' -> new float[][][]{{{0, 1}, {0.3f, 0}, {0.6f, 1}}, {{0.12f, 0.66f}, {0.48f, 0.66f}}};
            case 'L' -> new float[][][]{{{0, 0}, {0, 1}, {0.6f, 1}}};
            default -> new float[][][]{};
        };
    }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    // ---- hooks ----

    /** Called at the end of the vanilla SplashOverlay.render. */
    public static void onOverlay(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (done || mc.world != null) return;        // first launch only, not for in-game resource reloads
        if (t0 < 0) t0 = System.currentTimeMillis();
        sawOverlay = true;
        draw(ctx, 1f);
    }

    /** Called after any screen is rendered: fades our screen out once the vanilla overlay is gone. */
    public static void afterScreen(DrawContext ctx) {
        if (!sawOverlay || done) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getOverlay() != null) return;
        long now = System.currentTimeMillis();
        if (fadeStart < 0) fadeStart = now;
        float k = 1f - (now - fadeStart) / 650f;
        if (k <= 0f) { done = true; return; }
        draw(ctx, k * k);
    }

    // ---- drawing ----

    private static void glowLine(Canvas c, int w, int h, double x0, double y0, double x1, double y1, int rgb, float a) {
        Fx.line(c, w, h, x0, y0, x1, y1, 5, Fx.withAlpha(rgb, a * 0.07f));
        Fx.line(c, w, h, x0, y0, x1, y1, 3, Fx.withAlpha(rgb, a * 0.18f));
        Fx.line(c, w, h, x0, y0, x1, y1, 1, Fx.withAlpha(rgb, a));
    }

    private static void polygon(Canvas c, int w, int h, double cx, double cy, double r, double rot, int sides, int rgb, float a) {
        double px = 0, py = 0, fx = 0, fy = 0;
        for (int i = 0; i <= sides; i++) {
            double ang = rot + i * Math.PI * 2 / sides;
            double x = cx + Math.cos(ang) * r, y = cy + Math.sin(ang) * r;
            if (i > 0) glowLine(c, w, h, px, py, x, y, rgb, a);
            px = x; py = y;
        }
    }

    private static void draw(DrawContext ctx, float a) {
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        float time = (System.currentTimeMillis() - t0) / 1000f;
        float appear = clamp01(time / 0.6f);
        Canvas c = HudFx.canvas(ctx);

        ctx.fill(0, 0, w, h, Draw.argb((int) (255 * a), 0x000000));
        ctx.fillGradient(0, 0, w, h / 2, Draw.argb(0, 0xFFFFFF), Draw.argb((int) (14 * a), 0xFFFFFF));
        ctx.fillGradient(0, h / 2, w, h, Draw.argb((int) (14 * a), 0xFFFFFF), Draw.argb(0, 0xFFFFFF));

        // drifting shapes
        float m = 80f;
        for (float[] s : SH) {
            double fxp = (((s[0] + s[2] * time) % 1.0) + 1.0) % 1.0;
            double fyp = (((s[1] + s[3] * time) % 1.0) + 1.0) % 1.0;
            double x = -m + fxp * (w + 2 * m);
            double y = -m + fyp * (h + 2 * m) + Math.sin(time * 0.8 + s[8]) * 6;
            float pulse = 0.55f + 0.45f * (float) Math.sin(time * 1.3 + s[8]);
            float al = appear * a * (0.35f + 0.5f * pulse);
            double rot = s[5] + s[6] * time;
            int rgb = Fx.mix(0xFFFFFF, Neon.rgb(time, s[8] * 0.1f), 0.25f);
            polygon(c, w, h, x, y, s[4], rot, (int) s[7], rgb, al);
            if (s[9] > 0.5f) polygon(c, w, h, x, y, s[4] * 0.55, -rot * 1.4, (int) s[7], rgb, al * 0.7f);
        }

        // title
        String title = "IVISUALS";
        float lh = Math.max(26f, Math.min(64f, h / 8f));
        float lw = lh * 0.6f, adv = lh * 0.95f;
        float total = adv * (title.length() - 1) + lw;
        float tx = (w - total) / 2f, ty = h * 0.40f - lh / 2f;
        for (int i = 0; i < title.length(); i++) {
            float la = clamp01((time - 0.2f - i * 0.12f) / 0.45f) * a;
            if (la <= 0f) continue;
            float shimmer = 0.88f + 0.12f * (float) Math.sin(time * 3 + i);
            int rgb = Fx.mix(0xFFFFFF, Neon.rgb(time, i * 0.06f), 0.18f);
            float ox = tx + i * adv, rise = (1f - la) * 8f;
            for (float[][] stroke : letter(title.charAt(i))) {
                for (int k = 0; k + 1 < stroke.length; k++) {
                    glowLine(c, w, h, ox + stroke[k][0] * lh, ty + stroke[k][1] * lh + rise,
                            ox + stroke[k + 1][0] * lh, ty + stroke[k + 1][1] * lh + rise, rgb, la * shimmer);
                }
            }
        }

        // shimmering loading line
        float bw = Math.min(w * 0.4f, 170f), bx = (w - bw) / 2f, by = ty + lh + 26f;
        float ba = clamp01((time - 0.8f) / 0.5f) * a;
        if (ba > 0f) {
            ctx.fill((int) bx, (int) by, (int) (bx + bw), (int) by + 1, Draw.argb((int) (55 * ba), 0xFFFFFF));
            float head = ((time * 0.55f) % 1.5f) - 0.25f;
            for (int i = 0; i < (int) bw; i += 2) {
                float d = Math.abs(i / bw - head);
                float g = (float) Math.exp(-(d * d) / 0.006f);
                if (g < 0.03f) continue;
                int rgb = Fx.mix(0xFFFFFF, Neon.strong(time, i / bw), 0.45f);
                ctx.fill((int) bx + i, (int) by - 1, (int) bx + i + 2, (int) by + 2, Draw.argb((int) (255 * g * ba), rgb));
            }
        }
    }
}
