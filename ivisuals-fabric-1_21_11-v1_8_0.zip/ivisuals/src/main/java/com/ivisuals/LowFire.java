package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;

/**
 * Small fire: instead of the huge vanilla flames covering half of the screen, a thin strip of pixel flames
 * is drawn along the bottom edge while you burn (first person). The vanilla overlay is switched off by
 * making Entity.isOnFire() report false for the local player (see EntityMixin) while we are the ones asking.
 */
public final class LowFire {
    private LowFire() {}

    private static Setting style, width, height, opacity, hideVanilla;
    private static boolean querying;
    private static float intensity;
    private static long lastNano;

    public static void setup(Module m) {
        style = m.mode("Style", 0, "Neon", "Classic");
        width = m.slider("Width %", 40f, 10f, 100f, 5f);
        height = m.slider("Height", 22f, 6f, 80f, 2f);
        opacity = m.slider("Opacity", 0.9f, 0.2f, 1f, 0.05f);
        hideVanilla = m.toggle("Hide Vanilla Fire", true);
    }

    /** Called from EntityMixin: true = pretend the entity is not burning (first-person fire overlay only). */
    public static boolean shouldHideVanilla(Entity e) {
        if (querying) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || e != mc.player || mc.options == null) return false;
        if (ModuleManager.LOW_FIRE == null || !ModuleManager.LOW_FIRE.enabled || !hideVanilla.b()) return false;
        return mc.options.getPerspective().isFirstPerson();
    }

    private static boolean burning(MinecraftClient mc) {
        querying = true;
        try {
            return mc.player.isOnFire();
        } finally {
            querying = false;
        }
    }

    public static void render(DrawContext ctx, MinecraftClient mc, float tp) {
        long now = System.nanoTime();
        float dt = lastNano == 0 ? 0.016f : Math.min((now - lastNano) / 1e9f, 0.1f);
        lastNano = now;
        if (!ModuleManager.LOW_FIRE.enabled || mc.player == null) { intensity = 0; return; }

        boolean on = mc.options.getPerspective().isFirstPerson() && burning(mc);
        intensity += ((on ? 1f : 0f) - intensity) * Math.min(1f, dt * 8f);
        if (intensity < 0.02f) return;

        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        float t = HudFx.time();
        int colW = 3;
        int total = Math.max(colW * 4, (int) (sw * width.f() / 100f));
        int x0 = (sw - total) / 2;
        int cols = total / colW;
        float maxH = height.f() * intensity;
        float op = opacity.f() * Math.min(1f, intensity * 1.5f);
        boolean neon = style.i() == 0;

        // soft light on the screen edge
        ctx.fillGradient(x0, sh - (int) (maxH * 1.6f), x0 + total, sh,
                Draw.argb(0, 0xFF8A20), Draw.argb((int) (46 * op), neon ? 0xFFFFFF : 0xFF6A10));

        for (int i = 0; i < cols; i++) {
            float fx = (i + 0.5f) / cols;
            float taper = 0.30f + 0.70f * (float) Math.sin(fx * Math.PI);
            float n = 0.55f + 0.25f * (float) Math.sin(t * 11f + i * 0.9f)
                    + 0.20f * (float) Math.sin(t * 17f - i * 1.7f)
                    + 0.12f * (float) Math.sin(t * 5f + i * 0.31f);
            n = Math.max(0.12f, Math.min(1.15f, n));
            int h = Math.max(1, (int) (maxH * taper * n));
            int x = x0 + i * colW;

            int outer, mid, core;
            if (neon) {
                int rgb = Neon.strong(t, fx * 0.8f);
                outer = Draw.argb((int) (190 * op), rgb);
                mid = Draw.argb((int) (230 * op), Fx.mix(rgb, 0xFFFFFF, 0.55f));
                core = Draw.argb((int) (255 * op), 0xFFFFFF);
            } else {
                outer = Draw.argb((int) (200 * op), 0xE8400C);
                mid = Draw.argb((int) (230 * op), 0xFF9A1E);
                core = Draw.argb((int) (255 * op), 0xFFE680);
            }
            ctx.fill(x, sh - h, x + colW, sh, outer);
            ctx.fill(x, sh - (int) (h * 0.68f), x + colW, sh, mid);
            ctx.fill(x, sh - (int) (h * 0.36f), x + colW, sh, core);
        }
    }
}
