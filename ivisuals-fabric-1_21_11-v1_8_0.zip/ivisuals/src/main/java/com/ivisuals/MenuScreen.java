package com.ivisuals;

import com.ivisuals.Module.Category;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MenuScreen extends Screen {
    private static final int SIDE = 108, GAP = 8, CARD_H = 60, MIN_CARD = 150, SEARCH_H = 22, R = 14;
    private static final int WHITE = 0xFFFFFF;
    private static final long START = System.currentTimeMillis();

    private final long openTime = System.currentTimeMillis();
    private long lastNano = System.nanoTime();
    private boolean closing;
    private long closeTime;
    private float bgAlpha;

    private enum Mode { MENU, HUD }
    private enum Drag { NONE, MOVE, SCALE }

    private Mode mode = Mode.MENU;
    private float modeAnim;           // 0 = menu, 1 = hud
    private static final int TOP = 40, BAR_W = 160, BAR_H = 22;
    private double centerY;

    private Module bindingModule;
    private Module lastClicked;         // card you clicked last (Alt then binds this one when the mouse is not over a card)
    private int lastMx, lastMy;
    private int acc = WHITE;            // accent color of the client theme (white when the theme is Default)
    private Module openModule;          // module whose settings page is open (null = card list)
    private Setting dragSetting;        // slider being dragged
    private static final int SROW = 24;
    private HudWidget selected;
    private Drag drag = Drag.NONE;
    private double dragDX, dragDY;

    private Category tab = Category.VISUALS;
    private long tabSwitchTime = System.currentTimeMillis();
    private float selY = -1;
    private final float[] itemHover = new float[Category.values().length];

    private String query = "";
    private boolean searchFocused;
    private float searchAnim;

    private float scroll, scrollTarget;
    private boolean resizing;
    private float handleAnim;

    // layout, recomputed every frame
    private int px, py, lx, ly, lw, lh, cols, cardW;

    public MenuScreen() {
        super(Text.literal("Ivisuals"));
    }

    @Override public boolean shouldPause() { return false; }

    // ---------- helpers ----------
    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
    private static float easeOutCubic(float t) { float u = 1f - t; return 1f - u * u * u; }
    private static float easeOutBack(float t) {
        float c1 = 1.70158f, c3 = c1 + 1f, u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }

    private void layout() {
        int maxW = Math.max(200, width - 24), maxH = Math.max(160, height - TOP - 10);
        Config.winW = clamp(Config.winW, Math.min(380, maxW), maxW);
        Config.winH = clamp(Config.winH, Math.min(230, maxH), maxH);
        centerY = TOP + maxH / 2.0;
        px = (width - Config.winW) / 2;
        py = (int) (centerY - Config.winH / 2.0);
        lx = px + SIDE + 14;
        ly = py + 14 + SEARCH_H + 12;
        lw = Config.winW - SIDE - 28;
        lh = Config.winH - (ly - py) - 14;
        cols = Math.max(1, (lw + GAP) / (MIN_CARD + GAP));
        cardW = (lw - GAP * (cols - 1)) / cols;
    }

    private int itemY(int i) { return py + 52 + i * 28; }

    private List<Module> visible() {
        List<Module> out = new ArrayList<>();
        String q = query.trim().toLowerCase(Locale.ROOT);
        for (Module m : ModuleManager.MODULES) {
            if (q.isEmpty() ? m.category == tab : m.name.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        }
        return out;
    }

    private boolean nearCorner(double mx, double my) {
        int W = Config.winW, H = Config.winH;
        boolean nx = Math.abs(mx - px) <= 16 || Math.abs(mx - (px + W)) <= 16;
        boolean ny = Math.abs(my - py) <= 16 || Math.abs(my - (py + H)) <= 16;
        return nx && ny;
    }

    private Module moduleAt(double mx, double my) {
        if (my < ly - 2 || my > ly + lh + 2) return null;
        List<Module> list = visible();
        for (int i = 0; i < list.size(); i++) {
            int x = lx + (i % cols) * (cardW + GAP);
            int y = ly + (i / cols) * (CARD_H + GAP) - (int) scroll;
            if (mx >= x && mx <= x + cardW && my >= y && my <= y + CARD_H) return list.get(i);
        }
        return null;
    }

    // ---------- close with animation ----------
    @Override
    public void close() {
        if (!closing) {
            closing = true;
            closeTime = System.currentTimeMillis();
            Config.save();
        }
    }

    @Override
    public void renderBackground(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, Draw.argb((int) (140 * bgAlpha), 0x000000));
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long nowMs = System.currentTimeMillis();
        long nowN = System.nanoTime();
        float dt = Math.min((nowN - lastNano) / 1e9f, 0.05f);
        lastNano = nowN;
        float time = (nowMs - START) / 1000f;
        acc = Theme.accent(Neon.now());
        lastMx = mx;
        lastMy = my;

        float a, scale;
        if (!closing) {
            float t = clamp01((nowMs - openTime) / 520f);
            a = easeOutCubic(clamp01(t * 1.5f));
            scale = 0.84f + 0.16f * easeOutBack(t);
        } else {
            float t = 1f - clamp01((nowMs - closeTime) / 200f);
            if (t <= 0f) { super.close(); return; }
            a = t;
            scale = 0.94f + 0.06f * t;
        }
        bgAlpha = a;
        layout();
        super.render(c, mx, my, delta);

        var m = c.getMatrices();
        m.pushMatrix();
        m.translate(width / 2f, height / 2f + (1f - a) * 10f);
        m.scale(scale, scale);
        m.translate(-width / 2f, -height / 2f);

        modeAnim += ((mode == Mode.HUD ? 1f : 0f) - modeAnim) * Math.min(1f, dt * 14f);

        if (mode == Mode.MENU) {
            drawPanel(c, a, time);
            drawSidebar(c, mx, my, dt, a);
            drawSearch(c, dt, a, time);
            drawCards(c, mx, my, dt, a, nowMs);
            drawHandles(c, mx, my, dt, a);
        } else {
            drawEditor(c, mx, my, a);
        }

        m.popMatrix();
        drawTopBar(c, mx, my, a);
    }

    private void drawPanel(DrawContext c, float a, float time) {
        int W = Config.winW, H = Config.winH;
        Draw.glow(c, px, py, W, H, R, acc, 8, (acc == WHITE ? 0.10f : 0.20f) * a);
        Draw.roundRectV(c, px, py, W, H, R,
                Draw.argb((int) (208 * a), 0x131316), Draw.argb((int) (208 * a), 0x070709));
        waves(c, px, py, W, H, R, time, a);
        int pc = Draw.lerp(Draw.argb(0, WHITE), Draw.argb(0, Neon.rgb(time, 0f)), 0.4f);
        Draw.ring(c, px, py, W, H, R,
                Draw.argb((int) (130 * a), pc), Draw.argb((int) (34 * a), Neon.rgb(time, 0.5f)));
    }

    /** Soft white translucent waves flowing across the panel. */
    private void waves(DrawContext c, int x, int y, int w, int h, int r, float time, float a) {
        int top = y + r, bot = y + h - r;
        for (int k = 0; k < 3; k++) {
            float amp = 9f + k * 5f;
            float freq = 0.017f + k * 0.006f;
            float sp = 0.65f + k * 0.30f;
            float ph = k * 2.1f;
            float base = y + h * (0.50f + 0.14f * k);
            int al = (int) ((30 - k * 7) * a);
            for (int cx = 0; cx < w; cx += 2) {
                float wy = base
                        + amp * (float) Math.sin(cx * freq + time * sp + ph)
                        + amp * 0.5f * (float) Math.sin(cx * freq * 2.3f - time * sp * 0.8f);
                int y1 = (int) wy, y2 = y1 + 36;
                if (wy >= top && wy < bot) {
                    c.fill(x + cx, y1, x + cx + 2, y1 + 1, Draw.argb(al * 2, WHITE));
                }
                y1 = Math.max(y1, top);
                y2 = Math.min(y2, bot);
                if (y2 > y1) {
                    c.fillGradient(x + cx, y1, x + cx + 2, y2, Draw.argb(al, WHITE), Draw.argb(0, WHITE));
                }
            }
        }
    }

    private void drawSidebar(DrawContext c, int mx, int my, float dt, float a) {
        int W = Config.winW, H = Config.winH;
        Draw.text(c, textRenderer, "Ivisuals", px + 18, py + 17, 1.35f, Draw.argb((int) (255 * a), acc));
        c.fill(px + SIDE, py + 16, px + SIDE + 1, py + H - 16, Draw.argb((int) (22 * a), WHITE));

        Category[] cats = Category.values();
        int sel = tab.ordinal();
        boolean searching = !query.trim().isEmpty();
        float target = itemY(sel);
        if (selY < 0) selY = target;
        selY += (target - selY) * Math.min(1f, dt * 14f);

        float pa = searching ? 0.25f : 1f;
        int pw = SIDE - 20;
        Draw.roundRectV(c, px + 10, (int) selY, pw, 22, 8,
                Draw.argb((int) (46 * a * pa), acc), Draw.argb((int) (18 * a * pa), acc));
        Draw.ring(c, px + 10, (int) selY, pw, 22, 8,
                Draw.argb((int) (100 * a * pa), acc), Draw.argb((int) (28 * a * pa), acc));

        for (int i = 0; i < cats.length; i++) {
            int y = itemY(i);
            boolean hov = mx >= px + 10 && mx <= px + SIDE - 10 && my >= y && my <= y + 22;
            itemHover[i] += ((hov ? 1f : 0f) - itemHover[i]) * Math.min(1f, dt * 12f);
            float on = (i == sel && !searching) ? 1f : 0f;
            float br = Math.max(on, itemHover[i] * 0.7f);
            int col = Draw.argb((int) ((120 + 135 * br) * a), (i == sel && !searching) ? acc : WHITE);
            Draw.roundRect(c, px + 20, y + 9, 4, 4, 2, col);
            Draw.text(c, textRenderer, cats[i].label, px + 32, y + 7, 1.0f, col);
        }

        Draw.text(c, textRenderer, "Alt, key  bind", px + 18, py + H - 40, 0.75f, Draw.argb((int) (80 * a), WHITE));
        Draw.text(c, textRenderer, "Alt, Del  unbind", px + 18, py + H - 30, 0.75f, Draw.argb((int) (80 * a), WHITE));
        Draw.text(c, textRenderer, "RShift  close", px + 18, py + H - 20, 0.75f, Draw.argb((int) (80 * a), WHITE));
    }

    private void drawSearch(DrawContext c, float dt, float a, float time) {
        int sx = lx, sy = py + 14, sw = lw, sh = SEARCH_H;
        searchAnim += ((searchFocused ? 1f : 0f) - searchAnim) * Math.min(1f, dt * 12f);
        float f = searchAnim;
        Draw.roundRectV(c, sx, sy, sw, sh, 11,
                Draw.argb((int) ((30 + 16 * f) * a), WHITE), Draw.argb((int) ((12 + 10 * f) * a), WHITE));
        Draw.ring(c, sx, sy, sw, sh, 11,
                Draw.argb((int) ((80 + 110 * f) * a), acc), Draw.argb((int) ((24 + 50 * f) * a), acc));

        // magnifier icon
        int ix = sx + 11, iy = sy + 6;
        int ic = Draw.argb((int) (190 * a), WHITE);
        Draw.ring(c, ix, iy, 9, 9, 4, ic, ic);
        for (int k = 0; k < 4; k++) c.fill(ix + 7 + k, iy + 7 + k, ix + 9 + k, iy + 9 + k, ic);

        int tw = sw - 44;
        String shown = query.isEmpty() ? "Search" : textRenderer.trimToWidth(query, tw, true);
        int tcol = query.isEmpty() ? Draw.argb((int) (110 * a), WHITE) : Draw.argb((int) (255 * a), WHITE);
        Draw.text(c, textRenderer, shown, sx + 27, sy + 7, 1.0f, tcol);
        if (searchFocused && ((int) (time * 2f) % 2 == 0)) {
            int cxp = sx + 27 + (query.isEmpty() ? 0 : textRenderer.getWidth(shown)) + 1;
            c.fill(cxp, sy + 6, cxp + 1, sy + sh - 6, Draw.argb((int) (255 * a), WHITE));
        }
    }

    private void drawCards(DrawContext c, int mx, int my, float dt, float a, long nowMs) {
        if (openModule != null) { drawSettings(c, mx, my, dt, a); return; }
        int W = Config.winW;
        List<Module> list = visible();
        int rows = (list.size() + cols - 1) / cols;
        int contentH = rows == 0 ? 0 : rows * (CARD_H + GAP) - GAP;
        float maxScroll = Math.max(0, contentH - lh);
        scrollTarget = Math.max(0f, Math.min(scrollTarget, maxScroll));
        scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);

        if (list.isEmpty()) {
            String t1 = query.trim().isEmpty() ? "Nothing here yet" : "No results";
            String t2 = query.trim().isEmpty() ? "Features will appear here" : "Try another name";
            int cxm = lx + lw / 2, cym = ly + lh / 2;
            Draw.text(c, textRenderer, t1, cxm - Draw.textWidth(textRenderer, t1, 1.1f) / 2f, cym - 10, 1.1f,
                    Draw.argb((int) (150 * a), WHITE));
            Draw.text(c, textRenderer, t2, cxm - Draw.textWidth(textRenderer, t2, 0.8f) / 2f, cym + 4, 0.8f,
                    Draw.argb((int) (80 * a), WHITE));
            return;
        }

        boolean clip = maxScroll > 0;
        if (clip) c.enableScissor(lx - 8, ly - 2, lx + lw + 8, ly + lh + 2);
        boolean inArea = my >= ly - 2 && my <= ly + lh + 2;

        for (int i = 0; i < list.size(); i++) {
            Module m = list.get(i);
            int x = lx + (i % cols) * (cardW + GAP);
            int y0 = ly + (i / cols) * (CARD_H + GAP) - (int) scroll;
            boolean hov = inArea && !resizing && mx >= x && mx <= x + cardW && my >= y0 && my <= y0 + CARD_H;
            m.hoverAnim += ((hov ? 1f : 0f) - m.hoverAnim) * Math.min(1f, dt * 12f);
            m.toggleAnim += ((m.enabled ? 1f : 0f) - m.toggleAnim) * Math.min(1f, dt * 11f);
            if (y0 + CARD_H < ly - 4 || y0 > ly + lh + 4) continue;

            float raOpen = clamp01(a * 1.6f - i * 0.07f);
            float raCat = clamp01((nowMs - tabSwitchTime) / 260f - i * 0.06f);
            float ra = Math.min(raOpen, raCat);
            ra = ra * ra * (3f - 2f * ra);
            int y = y0 + (int) ((1f - ra) * 10f);
            float ta = m.toggleAnim, ho = m.hoverAnim;

            int accent = Neon.rgb(Neon.now(), i * 0.07f);
            if (ta > 0.02f) Draw.glow(c, x, y, cardW, CARD_H, 9, accent, 5, 0.12f * ta * ra);

            // liquid glass body
            Draw.roundRectV(c, x, y, cardW, CARD_H, 9,
                    Draw.argb((int) ((34 + 22 * ta + 14 * ho) * ra), WHITE),
                    Draw.argb((int) ((12 + 14 * ta + 8 * ho) * ra), WHITE));
            c.fillGradient(x + 9, y + 1, x + cardW - 9, y + CARD_H / 2,
                    Draw.argb((int) (22 * ra), WHITE), Draw.argb(0, WHITE));
            int ringCol = Draw.lerp(Draw.argb(0, WHITE), Draw.argb(0, accent), 0.15f + 0.65f * Math.max(ta, ho));
            Draw.ring(c, x, y, cardW, CARD_H, 9,
                    Draw.argb((int) ((90 + 80 * ta + 40 * ho) * ra), ringCol),
                    Draw.argb((int) ((24 + 40 * ta) * ra), ringCol));

            int tcol = Draw.argb((int) ((200 + 55 * Math.max(ta, ho)) * ra), WHITE);
            Draw.text(c, textRenderer, m.name, x + 11, y + 10, 1.0f, tcol);
            boolean binding = bindingModule == m;
            String descSrc = binding ? "Press any key  -  Del = remove" : m.description;
            String desc = textRenderer.trimToWidth(descSrc, (int) ((cardW - 22) / 0.78f));
            Draw.text(c, textRenderer, desc, x + 11, y + 23, 0.78f,
                    binding ? Draw.argb((int) (235 * ra), acc) : Draw.argb((int) (120 * ra), WHITE));
            if (!m.settings.isEmpty()) {
                int dxp = x + cardW - 20, dyp = y + 12;
                for (int k = 0; k < 3; k++) {
                    c.fill(dxp + k * 4, dyp, dxp + k * 4 + 2, dyp + 2, Draw.argb((int) ((90 + 120 * ho) * ra), WHITE));
                }
            }

            // switch
            int sw = 28, sh = 12, sx = x + 11, sy = y + CARD_H - 19;
            if (ta > 0.02f) Draw.glow(c, sx, sy, sw, sh, 6, accent, 4, 0.34f * ta * ra);
            Draw.roundRect(c, sx, sy, sw, sh, 6,
                    Draw.mulAlpha(Draw.lerp(Draw.argb(60, WHITE), Draw.argb(240, acc), ta), ra));
            int knobX = (int) (sx + 2 + (sw - 12) * ta);
            Draw.roundRect(c, knobX, sy + 2, 8, 8, 4,
                    Draw.mulAlpha(Draw.lerp(Draw.argb(235, WHITE), Draw.argb(255, 0x0A0A0C), ta), ra));
            Draw.text(c, textRenderer, m.enabled ? "On" : "Off", sx + sw + 8, sy + 2, 0.8f,
                    Draw.argb((int) ((90 + 120 * ta) * ra), WHITE));

            // keybind label
            String bl;
            int bcol;
            if (bindingModule == m) {
                bl = "[ ... ]";
                bcol = Draw.argb((int) ((150 + 105 * (((int) (nowMs / 350) % 2 == 0) ? 1f : 0.3f)) * ra), acc);
            } else if (m.bind != Module.NO_KEY) {
                bl = "[" + keyName(m.bind) + "]";
                bcol = Draw.argb((int) (230 * ra), WHITE);
            } else if (ho > 0.3f) {
                bl = m.settings.isEmpty() ? "Alt: bind" : "RMB: settings  Alt: bind";
                bcol = Draw.argb((int) (90 * ho * ra), WHITE);
            } else {
                bl = null;
                bcol = 0;
            }
            if (bl != null) {
                Draw.text(c, textRenderer, bl, x + cardW - 11 - Draw.textWidth(textRenderer, bl, 0.75f),
                        sy + 2, 0.75f, bcol);
            }
        }

        if (clip) {
            c.disableScissor();
            int barH = Math.max(12, (int) (lh * (float) lh / contentH));
            int by = ly + (int) ((lh - barH) * (scroll / maxScroll));
            Draw.roundRect(c, px + W - 9, by, 2, barH, 1, Draw.argb((int) (70 * a), WHITE));
        }
    }

    // ---------- settings page ----------
    private int sTop() { return ly + 20; }
    private int trackX() { return lx + 118; }
    private int trackW() { return Math.max(40, lw - 118 - 56); }
    private int rowY(int i) { return sTop() + i * SROW - (int) scroll; }

    private void closeSettings() {
        openModule = null;
        dragSetting = null;
        scroll = 0;
        scrollTarget = 0;
        tabSwitchTime = System.currentTimeMillis();
    }

    private void drawSettings(DrawContext c, int mx, int my, float dt, float a) {
        Module m = openModule;
        boolean backHov = mx >= lx && mx <= lx + 44 && my >= ly - 4 && my <= ly + 14;
        Draw.text(c, textRenderer, "< Back", lx, ly + 2, 0.9f, Draw.argb((int) ((backHov ? 255 : 170) * a), WHITE));
        Draw.text(c, textRenderer, m.name, lx + 52, ly + 1, 1.05f, Draw.argb((int) (255 * a), WHITE));
        String rs = "Reset";
        int rw = Draw.textWidth(textRenderer, rs, 0.85f);
        boolean rsHov = mx >= lx + lw - rw - 8 && mx <= lx + lw && my >= ly - 4 && my <= ly + 14;
        Draw.text(c, textRenderer, rs, lx + lw - rw - 4, ly + 3, 0.85f, Draw.argb((int) ((rsHov ? 255 : 130) * a), WHITE));

        int top = sTop(), bottom = ly + lh;
        int viewH = bottom - top;
        int contentH = m.settings.size() * SROW;
        float maxScroll = Math.max(0, contentH - viewH);
        scrollTarget = Math.max(0f, Math.min(scrollTarget, maxScroll));
        scroll += (scrollTarget - scroll) * Math.min(1f, dt * 14f);

        c.enableScissor(lx - 6, top, lx + lw + 8, bottom);
        for (int i = 0; i < m.settings.size(); i++) {
            Setting s = m.settings.get(i);
            int y = rowY(i);
            if (y + SROW < top || y > bottom) continue;
            int rh = SROW - 4;
            boolean hov = mx >= lx && mx <= lx + lw && my >= Math.max(y, top) && my <= Math.min(y + rh, bottom);
            Draw.roundRectV(c, lx, y, lw, rh, 7,
                    Draw.argb((int) ((28 + (hov ? 14 : 0)) * a), WHITE), Draw.argb((int) ((10 + (hov ? 8 : 0)) * a), WHITE));
            Draw.ring(c, lx, y, lw, rh, 7, Draw.argb((int) (60 * a), WHITE), Draw.argb((int) (16 * a), WHITE));
            Draw.text(c, textRenderer, s.name, lx + 9, y + (rh - 8) / 2f, 0.9f, Draw.argb((int) (225 * a), WHITE));

            switch (s.type) {
                case SLIDER -> {
                    int tx = trackX(), tw = trackW(), ty = y + rh / 2 - 2;
                    Draw.roundRect(c, tx, ty, tw, 4, 2, Draw.argb((int) (55 * a), WHITE));
                    int fw = (int) (tw * s.frac());
                    if (fw > 0) Draw.roundRect(c, tx, ty, Math.max(4, fw), 4, 2, Draw.argb((int) (210 * a), acc));
                    int kx = tx + fw - 4;
                    Draw.glow(c, kx, ty - 2, 8, 8, 4, acc, 3, 0.25f * a);
                    Draw.roundRect(c, kx, ty - 2, 8, 8, 4, Draw.argb((int) (255 * a), WHITE));
                    String v = s.text();
                    Draw.text(c, textRenderer, v, lx + lw - 8 - Draw.textWidth(textRenderer, v, 0.85f),
                            y + (rh - 8) / 2f, 0.85f, Draw.argb((int) (200 * a), WHITE));
                }
                case MODE -> {
                    int pxx = lx + 118, pw = lw - 118 - 8, ph = rh - 4;
                    Draw.roundRectV(c, pxx, y + 2, pw, ph, 6,
                            Draw.argb((int) (44 * a), WHITE), Draw.argb((int) (16 * a), WHITE));
                    Draw.ring(c, pxx, y + 2, pw, ph, 6, Draw.argb((int) (100 * a), acc), Draw.argb((int) (30 * a), acc));
                    String v = s.mode();
                    int vw = Draw.textWidth(textRenderer, v, 0.9f);
                    Draw.text(c, textRenderer, v, pxx + (pw - vw) / 2f, y + (rh - 8) / 2f, 0.9f,
                            Draw.argb((int) (255 * a), WHITE));
                    int arr = Draw.argb((int) (150 * a), WHITE);
                    Draw.text(c, textRenderer, "<", pxx + 6, y + (rh - 8) / 2f, 0.9f, arr);
                    Draw.text(c, textRenderer, ">", pxx + pw - 6 - Draw.textWidth(textRenderer, ">", 0.9f),
                            y + (rh - 8) / 2f, 0.9f, arr);
                }
                case TOGGLE -> {
                    int sw = 28, sh = 12, sx = lx + lw - 8 - sw, sy = y + (rh - sh) / 2;
                    float on = s.b() ? 1f : 0f;
                    Draw.roundRect(c, sx, sy, sw, sh, 6,
                            Draw.lerp(Draw.argb((int) (60 * a), WHITE), Draw.argb((int) (240 * a), acc), on));
                    int knobX = (int) (sx + 2 + (sw - 12) * on);
                    Draw.roundRect(c, knobX, sy + 2, 8, 8, 4,
                            Draw.lerp(Draw.argb((int) (235 * a), WHITE), Draw.argb((int) (255 * a), 0x0A0A0C), on));
                }
            }
        }
        c.disableScissor();

        if (maxScroll > 0) {
            int barH = Math.max(12, (int) (viewH * (float) viewH / contentH));
            int by = top + (int) ((viewH - barH) * (scroll / maxScroll));
            Draw.roundRect(c, px + Config.winW - 9, by, 2, barH, 1, Draw.argb((int) (70 * a), WHITE));
        }
    }

    private void setFromMouse(Setting s, double mx) {
        float f = (float) Math.max(0.0, Math.min(1.0, (mx - trackX()) / trackW()));
        s.set(s.min + f * (s.max - s.min));
    }

    private boolean settingsClicked(double mx, double my, int button) {
        Module m = openModule;
        if (button == 0 && my >= ly - 4 && my <= ly + 14) {
            if (mx >= lx && mx <= lx + 44) { closeSettings(); return true; }
            int rw = Draw.textWidth(textRenderer, "Reset", 0.85f);
            if (mx >= lx + lw - rw - 8 && mx <= lx + lw) {
                for (Setting s : m.settings) s.reset();
                Config.save();
                return true;
            }
        }
        if (my < sTop() || my > ly + lh) return false;
        for (int i = 0; i < m.settings.size(); i++) {
            int y = rowY(i);
            if (my < y || my > y + SROW - 4 || mx < lx || mx > lx + lw) continue;
            Setting s = m.settings.get(i);
            switch (s.type) {
                case SLIDER -> {
                    if (button == 0 && mx >= trackX() - 8 && mx <= trackX() + trackW() + 8) {
                        dragSetting = s;
                        setFromMouse(s, mx);
                        return true;
                    }
                }
                case MODE -> {
                    if (mx >= lx + 100) { s.cycle(button == 1 ? -1 : 1); Config.save(); return true; }
                }
                case TOGGLE -> {
                    if (button == 0 && mx >= lx + 100) { s.cycle(1); Config.save(); return true; }
                }
            }
        }
        return false;
    }

    private void drawHandles(DrawContext c, int mx, int my, float dt, float a) {
        int W = Config.winW, H = Config.winH;
        float target = (resizing || nearCorner(mx, my)) ? 1f : 0f;
        handleAnim += (target - handleAnim) * Math.min(1f, dt * 12f);
        int col = Draw.argb((int) ((45 + 150 * handleAnim) * a), acc);
        // top-left
        c.fill(px + 6, py + 6, px + 14, py + 7, col);
        c.fill(px + 6, py + 6, px + 7, py + 14, col);
        // top-right
        c.fill(px + W - 14, py + 6, px + W - 6, py + 7, col);
        c.fill(px + W - 7, py + 6, px + W - 6, py + 14, col);
        // bottom-left
        c.fill(px + 6, py + H - 7, px + 14, py + H - 6, col);
        c.fill(px + 6, py + H - 14, px + 7, py + H - 6, col);
        // bottom-right
        c.fill(px + W - 14, py + H - 7, px + W - 6, py + H - 6, col);
        c.fill(px + W - 7, py + H - 14, px + W - 6, py + H - 6, col);

        if (resizing) {
            String s = W + " x " + H;
            Draw.text(c, textRenderer, s, px + W / 2f - Draw.textWidth(textRenderer, s, 0.85f) / 2f,
                    py + H - 20, 0.85f, Draw.argb((int) (170 * a), WHITE));
        }
    }

    // ---------- top bar (Menu | HUD) ----------
    private void drawTopBar(DrawContext c, int mx, int my, float a) {
        int bx = (width - BAR_W) / 2, by = 10;
        Draw.glow(c, bx, by, BAR_W, BAR_H, 11, acc, 5, 0.08f * a);
        Draw.roundRectV(c, bx, by, BAR_W, BAR_H, 11,
                Draw.argb((int) (215 * a), 0x131316), Draw.argb((int) (215 * a), 0x070709));
        float nt = Neon.now();
        Draw.ring(c, bx, by, BAR_W, BAR_H, 11,
                Draw.argb((int) (130 * a), Neon.rgb(nt, 0f)), Draw.argb((int) (34 * a), Neon.rgb(nt, 0.5f)));

        int segW = (BAR_W - 4) / 2;
        int hx = bx + 2 + (int) (segW * modeAnim);
        Draw.roundRectV(c, hx, by + 2, segW, BAR_H - 4, 9,
                Draw.argb((int) (60 * a), WHITE), Draw.argb((int) (24 * a), WHITE));
        Draw.ring(c, hx, by + 2, segW, BAR_H - 4, 9,
                Draw.argb((int) (120 * a), acc), Draw.argb((int) (36 * a), acc));

        String[] labels = {"Menu", "HUD"};
        for (int i = 0; i < 2; i++) {
            boolean on = (i == 0) == (mode == Mode.MENU);
            int tw = textRenderer.getWidth(labels[i]);
            int tx = bx + 2 + i * segW + (segW - tw) / 2;
            c.drawText(textRenderer, labels[i], tx, by + 7, Draw.argb((int) ((on ? 255 : 120) * a), WHITE), false);
        }
    }

    private boolean topBarClick(double mx, double my) {
        int bx = (width - BAR_W) / 2, by = 10;
        if (mx < bx || mx > bx + BAR_W || my < by || my > by + BAR_H) return false;
        Mode m = mx < bx + BAR_W / 2.0 ? Mode.MENU : Mode.HUD;
        if (m != mode) {
            mode = m;
            searchFocused = false;
            bindingModule = null;
            openModule = null;
            dragSetting = null;
            drag = Drag.NONE;
            tabSwitchTime = System.currentTimeMillis();
        }
        return true;
    }

    // ---------- HUD editor ----------
    private int[] chipRect(HudWidget w) {
        String s = w.title + "  " + (w.enabled() ? "On" : "Off");
        int cw = (int) (textRenderer.getWidth(s) * 0.85f) + 12;
        int ch = 12;
        int cx = Math.max(2, Math.min(w.x, width - cw - 2));
        int cy = w.y - ch - 2;
        if (cy < 2) cy = w.y + w.sh() + 2;
        return new int[]{cx, cy, cw, ch};
    }

    private void drawEditor(DrawContext c, int mx, int my, float a) {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (HudWidget w : HudWidgets.ALL) {
            w.draw(c, mc, width, height);
            int x = w.x, y = w.y, sw = w.sw(), sh = w.sh();
            boolean on = w.enabled();
            if (!on) c.fill(x, y, x + sw, y + sh, Draw.argb(130, 0x000000));

            boolean sel = w == selected, hov = w.contains(mx, my);
            int col = Draw.argb((int) ((sel ? 240 : hov ? 180 : 90) * a), acc);
            c.fill(x - 1, y - 1, x + sw + 1, y, col);
            c.fill(x - 1, y + sh, x + sw + 1, y + sh + 1, col);
            c.fill(x - 1, y, x, y + sh, col);
            c.fill(x + sw, y, x + sw + 1, y + sh, col);
            // resize handle
            c.fill(x + sw - 3, y + sh - 3, x + sw + 4, y + sh + 4, Draw.argb((int) (230 * a), WHITE));

            // on/off chip
            int[] r = chipRect(w);
            boolean chov = mx >= r[0] && mx <= r[0] + r[2] && my >= r[1] && my <= r[1] + r[3];
            Draw.roundRectV(c, r[0], r[1], r[2], r[3], 6,
                    Draw.argb((int) ((on ? 70 : 28) * a + (chov ? 20 : 0)), WHITE),
                    Draw.argb((int) ((on ? 28 : 12) * a), WHITE));
            Draw.ring(c, r[0], r[1], r[2], r[3], 6,
                    Draw.argb((int) ((on ? 170 : 80) * a), WHITE), Draw.argb((int) (40 * a), WHITE));
            Draw.text(c, textRenderer, w.title + "  " + (on ? "On" : "Off"), r[0] + 6, r[1] + 3, 0.85f,
                    Draw.argb((int) ((on ? 255 : 130) * a), WHITE));
        }

        if (drag == Drag.SCALE && selected != null) {
            String s = String.format(Locale.ROOT, "x%.2f", selected.scale);
            Draw.text(c, textRenderer, s, selected.x + selected.sw() + 8, selected.y + selected.sh() - 8, 0.9f,
                    Draw.argb((int) (220 * a), WHITE));
        }

        String h1 = "Drag - move      Drag corner or scroll - resize      Click the label - on / off";
        Draw.text(c, textRenderer, h1, width / 2f - Draw.textWidth(textRenderer, h1, 0.8f) / 2f,
                height - 16, 0.8f, Draw.argb((int) (110 * a), WHITE));
    }

    private boolean hudClicked(double mx, double my, int button) {
        if (button != 0) return false;
        // chips first, then corner handles, then bodies
        for (HudWidget w : HudWidgets.ALL) {
            int[] r = chipRect(w);
            if (mx >= r[0] && mx <= r[0] + r[2] && my >= r[1] && my <= r[1] + r[3]) {
                Module m = ModuleManager.get(w.moduleName);
                if (m != null) m.toggle();
                selected = w;
                return true;
            }
        }
        for (HudWidget w : HudWidgets.ALL) {
            int hx = w.x + w.sw(), hy = w.y + w.sh();
            if (Math.abs(mx - hx) <= 6 && Math.abs(my - hy) <= 6) {
                selected = w;
                drag = Drag.SCALE;
                return true;
            }
        }
        for (int i = HudWidgets.ALL.size() - 1; i >= 0; i--) {
            HudWidget w = HudWidgets.ALL.get(i);
            if (w.contains(mx, my)) {
                selected = w;
                drag = Drag.MOVE;
                dragDX = mx - w.x;
                dragDY = my - w.y;
                return true;
            }
        }
        selected = null;
        return false;
    }

    // ---------- keys ----------
    static String keyName(int code) {
        switch (code) {
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LShift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RShift";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCtrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCtrl";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LAlt";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RAlt";
            case GLFW.GLFW_KEY_SPACE: return "Space";
            case GLFW.GLFW_KEY_TAB: return "Tab";
            case GLFW.GLFW_KEY_ENTER: return "Enter";
            case GLFW.GLFW_KEY_CAPS_LOCK: return "Caps";
            case GLFW.GLFW_KEY_UP: return "Up";
            case GLFW.GLFW_KEY_DOWN: return "Down";
            case GLFW.GLFW_KEY_LEFT: return "Left";
            case GLFW.GLFW_KEY_RIGHT: return "Right";
            case GLFW.GLFW_KEY_INSERT: return "Insert";
            case GLFW.GLFW_KEY_HOME: return "Home";
            case GLFW.GLFW_KEY_END: return "End";
            case GLFW.GLFW_KEY_PAGE_UP: return "PgUp";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "PgDn";
            default:
        }
        if (code >= GLFW.GLFW_KEY_F1 && code <= GLFW.GLFW_KEY_F25) return "F" + (code - GLFW.GLFW_KEY_F1 + 1);
        String n = GLFW.glfwGetKeyName(code, 0);
        if (n != null && !n.isEmpty()) return n.toUpperCase(Locale.ROOT);
        return "Key " + code;
    }

    private static boolean altDown() {
        var w = MinecraftClient.getInstance().getWindow();
        return InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_LEFT_ALT) || InputUtil.isKeyPressed(w, GLFW.GLFW_KEY_RIGHT_ALT);
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int button = click.button();
        layout();
        if (button == 0 && topBarClick(mx, my)) return true;

        if (mode == Mode.HUD) {
            if (hudClicked(mx, my, button)) return true;
            return super.mouseClicked(click, doubled);
        }

        if (button == 1 && nearCorner(mx, my)) {
            resizing = true;
            return true;
        }
        if (openModule != null && settingsClicked(mx, my, button)) return true;
        if (button == 1 && openModule == null) {                 // right click a card -> its settings
            Module hit = moduleAt(mx, my);
            if (hit != null && !hit.settings.isEmpty()) {
                openModule = hit;
                scroll = 0;
                scrollTarget = 0;
                bindingModule = null;
                return true;
            }
        }
        if (button == 0) {
            bindingModule = null;

            // search
            boolean inSearch = mx >= lx && mx <= lx + lw && my >= py + 14 && my <= py + 14 + SEARCH_H;
            searchFocused = inSearch;
            if (inSearch) { closeSettings(); return true; }

            // sidebar
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                int y = itemY(i);
                if (mx >= px + 10 && mx <= px + SIDE - 10 && my >= y && my <= y + 22) {
                    tab = cats[i];
                    query = "";
                    closeSettings();
                    scrollTarget = 0;
                    tabSwitchTime = System.currentTimeMillis();
                    return true;
                }
            }
            // cards
            Module hit = openModule == null ? moduleAt(mx, my) : null;
            if (hit != null) {
                lastClicked = hit;
                if (altDown()) bindingModule = hit;   // Alt held while clicking works too
                else hit.toggle();
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        double mx = click.x(), my = click.y();
        if (dragSetting != null && click.button() == 0) {
            setFromMouse(dragSetting, mx);
            return true;
        }
        if (mode == Mode.HUD && click.button() == 0 && selected != null) {
            if (drag == Drag.MOVE) {
                selected.x = (int) (mx - dragDX);
                selected.y = (int) (my - dragDY);
                selected.clamp(width, height);
                return true;
            }
            if (drag == Drag.SCALE) {
                double sx = (mx - selected.x) / selected.w();
                double sy = (my - selected.y) / selected.h();
                float s = (float) Math.max(sx, sy);
                s = Math.round(s * 20f) / 20f;
                selected.scale = Math.max(0.5f, Math.min(4f, s));
                selected.clamp(width, height);
                return true;
            }
        }
        if (mode == Mode.MENU && resizing && click.button() == 1) {
            Config.winW = (int) (2 * Math.abs(mx - width / 2.0));
            Config.winH = (int) (2 * Math.abs(my - centerY));
            layout();
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragSetting != null && click.button() == 0) {
            dragSetting = null;
            Config.save();
            return true;
        }
        if (drag != Drag.NONE && click.button() == 0) {
            drag = Drag.NONE;
            Config.save();
            return true;
        }
        if (resizing && click.button() == 1) {
            resizing = false;
            Config.save();
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        if (mode == Mode.HUD) {
            HudWidget t = null;
            for (HudWidget w : HudWidgets.ALL) if (w.contains(mx, my)) t = w;
            if (t == null) t = selected;
            if (t != null) {
                t.scale = Math.max(0.5f, Math.min(4f, Math.round((t.scale + (float) vAmount * 0.1f) * 20f) / 20f));
                t.clamp(width, height);
                selected = t;
                Config.save();
            }
            return true;
        }
        scrollTarget -= (float) (vAmount * 26);
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        int cp = input.codepoint();
        if (mode == Mode.MENU && searchFocused && cp >= 32 && cp != 127 && query.length() < 24) {
            query += new String(Character.toChars(cp));
            scrollTarget = 0;
            tabSwitchTime = System.currentTimeMillis();
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int keyCode = input.key();

        // step 2: waiting for the key (any key binds, Delete removes the bind, Esc cancels)
        if (bindingModule != null) {
            if (keyCode == GLFW.GLFW_KEY_LEFT_ALT || keyCode == GLFW.GLFW_KEY_RIGHT_ALT) {
                return true;                          // the Alt you just pressed is not the key
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                bindingModule = null;
            } else if (keyCode == GLFW.GLFW_KEY_DELETE) {
                bindingModule.bind = Module.NO_KEY;
                bindingModule.bindWasDown = false;
                bindingModule = null;
                Config.save();
            } else if (keyCode != IVisualsClient.MENU_KEY && keyCode != GLFW.GLFW_KEY_UNKNOWN) {
                bindingModule.bind = keyCode;
                bindingModule.bindWasDown = true;   // do not fire immediately
                bindingModule = null;
                Config.save();
            }
            return true;
        }

        // step 1: Alt = "bind this one" (settings page > card under the mouse > card you clicked last)
        if (mode == Mode.MENU && !searchFocused
                && (keyCode == GLFW.GLFW_KEY_LEFT_ALT || keyCode == GLFW.GLFW_KEY_RIGHT_ALT)) {
            Module target = openModule != null ? openModule : moduleAt(lastMx, lastMy);
            if (target == null) target = lastClicked;
            if (target != null) bindingModule = target;
            return true;
        }

        if (openModule != null && keyCode == GLFW.GLFW_KEY_ESCAPE) {
            closeSettings();
            return true;
        }

        if (mode == Mode.MENU && searchFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!query.isEmpty()) {
                    query = query.substring(0, query.length() - 1);
                    tabSwitchTime = System.currentTimeMillis();
                }
            } else if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
                searchFocused = false;
            }
            return true;
        }
        if (keyCode == IVisualsClient.MENU_KEY) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }
}
