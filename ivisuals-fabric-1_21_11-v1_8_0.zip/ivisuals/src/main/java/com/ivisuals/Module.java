package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Module {
    public enum Category {
        VISUALS("Visuals"), COMBAT("Combat"), PLAYER("Player"), PERFORMANCE("Performance"), HUD("HUD");
        public final String label;
        Category(String label) { this.label = label; }
    }

    public static final int NO_KEY = -1;

    public final String name;
    public final String description;
    public final Category category;
    public boolean enabled;

    /** Options shown on the module's settings page (right-click the card). */
    public final List<Setting> settings = new ArrayList<>();

    /** GLFW key code, or NO_KEY. Set with Alt+Click on the card in the menu. */
    public int bind = NO_KEY;
    boolean bindWasDown;

    // animation state (0..1), used by the menu
    public float toggleAnim;
    public float hoverAnim;

    private Consumer<MinecraftClient> tickHandler;
    private Consumer<Boolean> toggleHandler;
    private Consumer<MinecraftClient> pressHandler;

    public Module(String name, Category category, String description) {
        this.name = name;
        this.category = category;
        this.description = description;
    }

    // ---- settings builders ----
    public Setting slider(String name, float def, float min, float max, float step) {
        Setting s = Setting.slider(name, def, min, max, step);
        settings.add(s);
        return s;
    }

    public Setting mode(String name, int def, String... options) {
        Setting s = Setting.mode(name, def, options);
        settings.add(s);
        return s;
    }

    public Setting toggle(String name, boolean def) {
        Setting s = Setting.toggle(name, def);
        settings.add(s);
        return s;
    }

    /** Called every client tick while the module is enabled. */
    public Module onTick(Consumer<MinecraftClient> handler) {
        this.tickHandler = handler;
        return this;
    }

    /** Called when the module is switched on or off. */
    public Module onToggle(Consumer<Boolean> handler) {
        this.toggleHandler = handler;
        return this;
    }

    /**
     * Makes the bound key DO something (instead of switching the module on / off). The card's ON/OFF switch then
     * decides whether the key is active.
     */
    public Module onPress(Consumer<MinecraftClient> handler) {
        this.pressHandler = handler;
        return this;
    }

    public boolean hasPress() { return pressHandler != null; }

    public void press(MinecraftClient mc) {
        if (enabled && pressHandler != null) pressHandler.accept(mc);
    }

    /** Enabled by default (until a saved config says otherwise). */
    public Module defaultOn() {
        this.enabled = true;
        this.toggleAnim = 1f;
        return this;
    }

    public void setEnabled(boolean value) {
        if (enabled == value) return;
        enabled = value;
        if (toggleHandler != null) toggleHandler.accept(value);
    }

    /** Toggle from the menu / keybind and save to config. */
    public void toggle() {
        setEnabled(!enabled);
        Config.save();
    }

    void tick(MinecraftClient mc) {
        if (enabled && tickHandler != null) tickHandler.accept(mc);
    }
}
