package com.ivisuals;

import com.ivisuals.Module.Category;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Add a feature with ONE line in the static block:
 *
 *     add("My Feature", Category.VISUALS, "Short description")
 *         .onTick(mc -> { ... })
 *         .onToggle(on -> { ... });
 *
 * It gets a card in the menu, search, a saved ON/OFF state and an
 * Alt+Click keybind automatically.
 */
public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();

    public static Module FULLBRIGHT, HANDS, BLOCK_HIGHLIGHT, SWING, HIT_PARTICLES, HIT_HIGHLIGHT, OPTIMIZER,
            TRAJECTORIES, LOW_FIRE, NEON_UI, CLIENT_COLOR, ITEM_ESP, HELD_TINT, HATS, WINGS, INFO,
            NAMETAGS, FRIENDS, SEE_INVISIBLE,
            JUMP_FX, TARGET_FX, TRAIL_FX, TNT_TIMER, DAMAGE_FX, LANTERNS, FIREFLIES, SKY;

    static {
        // ---- VISUALS ----
        CLIENT_COLOR = add("Client Color", Category.VISUALS, "Make the whole client red, blue, rainbow...").defaultOn();
        Theme.setup(CLIENT_COLOR);

        SKY = add("Sky", Category.VISUALS, "Rainbow, neon, aurora, galaxy sky and clouds");
        SkyFx.setup(SKY);

        LANTERNS = add("Sky Lanterns", Category.VISUALS, "Chinese lanterns drifting up over the map")
                .onTick(Ambient.LANTERNS::tick)
                .onToggle(on -> { if (!on) Ambient.LANTERNS.clear(); });
        Ambient.LANTERNS.setup(LANTERNS);

        FIREFLIES = add("Fireflies", Category.VISUALS, "Soft glowing dots floating around you")
                .onTick(Ambient.FIREFLIES::tick)
                .onToggle(on -> { if (!on) Ambient.FIREFLIES.clear(); });
        Ambient.FIREFLIES.setup(FIREFLIES);

        JUMP_FX = add("Jump Circles", Category.VISUALS, "Neon rings on the ground when you jump / land")
                .onTick(Effects::tickJump)
                .onToggle(on -> { if (!on) Effects.clearJump(); });
        Effects.setupJump(JUMP_FX);

        TRAIL_FX = add("Player Trail", Category.VISUALS, "Glowing trail behind you")
                .onTick(Effects::tickTrail)
                .onToggle(on -> { if (!on) Effects.clearTrail(); });
        Effects.setupTrail(TRAIL_FX);

        TARGET_FX = add("Target Circle", Category.VISUALS, "Neon circle around who you look at");
        Effects.setupTarget(TARGET_FX);

        TNT_TIMER = add("TNT Timer", Category.VISUALS, "Countdown + blast ring over lit TNT")
                .onTick(Effects::tickTnt)
                .onToggle(on -> { if (!on) Effects.clearTnt(); });
        Effects.setupTnt(TNT_TIMER);

        DAMAGE_FX = add("Damage Numbers", Category.VISUALS, "Floating numbers when something is hurt")
                .onTick(Effects::tickDamage)
                .onToggle(on -> { if (!on) Effects.clearDamage(); });
        Effects.setupDamage(DAMAGE_FX);

        ITEM_ESP = add("Item ESP", Category.VISUALS, "Glow + name on items lying on the ground")
                .onTick(ItemEsp::tick)
                .onToggle(on -> { if (!on) ItemEsp.clear(MinecraftClient.getInstance()); });
        ItemEsp.setup(ITEM_ESP);

        HELD_TINT = add("Held Tint", Category.VISUALS, "See-through color coat on the item in your hand");
        HeldTint.setup(HELD_TINT);

        HATS = add("Hats", Category.VISUALS, "Pick a hat: top hat, crown, halo, wizard...");
        Cosmetics.setupHats(HATS);

        WINGS = add("Wings", Category.VISUALS, "Pick wings for your back: angel, demon, dragon...");
        Cosmetics.setupWings(WINGS);

        NAMETAGS = add("Nametags", Category.VISUALS, "Pretty nicks over players: admins red, friends starred")
                .defaultOn();
        Nametags.setup(NAMETAGS);

        FULLBRIGHT = add("Fullbright", Category.VISUALS, "Max brightness")
                .onTick(Fullbright::tick)
                .onToggle(on -> { if (!on) Fullbright.disable(MinecraftClient.getInstance()); });

        HANDS = add("Hand Tweaks", Category.VISUALS, "Size and position of hands");
        HandTweaks.setup(HANDS);

        BLOCK_HIGHLIGHT = add("Block Highlight", Category.VISUALS, "Glow on the block you look at");
        BlockHighlight.setup(BLOCK_HIGHLIGHT);

        LOW_FIRE = add("Small Fire", Category.VISUALS, "Tiny flames instead of the huge fire overlay");
        LowFire.setup(LOW_FIRE);

        NEON_UI = add("Neon Buttons", Category.VISUALS, "White / black neon buttons everywhere").defaultOn();
        NeonButtons.setup(NEON_UI);

        // ---- COMBAT ----
        TRAJECTORIES = add("Trajectories", Category.COMBAT, "Where pearls, arrows & potions land")
                .onTick(Trajectories::tick)
                .onToggle(on -> { if (!on) Trajectories.clear(); })
                .defaultOn();
        Trajectories.setup(TRAJECTORIES);

        SEE_INVISIBLE = add("See Invisible", Category.COMBAT, "Players under invisibility are drawn as a ghost")
                .onTick(SeeInvisible::tick)
                .onToggle(on -> { if (!on) SeeInvisible.clear(); });
        SeeInvisible.setup(SEE_INVISIBLE);

        SWING = add("Swing Animation", Category.COMBAT, "Pick how your hit swings");
        SwingAnimation.setup(SWING);

        HIT_PARTICLES = add("Hit Particles", Category.COMBAT, "Dollars, ducks, crowns on hit")
                .onToggle(on -> { if (!on) HitParticles.clear(); });
        HitParticles.setup(HIT_PARTICLES);

        HIT_HIGHLIGHT = add("Hit Highlight", Category.COMBAT, "Target glows after your hit")
                .onTick(HitHighlight::tick)
                .onToggle(on -> { if (!on) HitHighlight.clear(MinecraftClient.getInstance()); });
        HitHighlight.setup(HIT_HIGHLIGHT);

        // ---- PLAYER ----
        add("Inventory Move", Category.PLAYER, "Walk with inventory open")
                .onTick(InventoryMove::tick);

        // Friends: click a nick in the chat -> friend (glows through walls). Shift + click = admin (red nick).
        FRIENDS = add("Friends", Category.PLAYER, "Click a nick in the chat: friend, visible through walls")
                .onTick(Friends::tick)
                .onToggle(on -> { if (!on) Friends.clear(); })
                .defaultOn();
        Friends.setup(FRIENDS);

        // Quick Swap: bind a key to the card (Alt, then the key) -> the item jumps into your hand
        for (int i = 0; i < 3; i++) {
            final int slot = i;
            Module qs = add("Quick Swap " + (i + 1), Category.PLAYER, "Key = chosen item jumps into your hand")
                    .onPress(mc -> QuickSwap.press(mc, slot))
                    .defaultOn();
            QuickSwap.setup(qs, i);
        }

        // ---- PERFORMANCE ----
        OPTIMIZER = add("Optimizer", Category.PERFORMANCE, "Hard FPS boost")
                .onTick(Optimizer::tick)
                .onToggle(on -> { if (!on) Optimizer.disable(MinecraftClient.getInstance()); });
        Optimizer.setup(OPTIMIZER);

        // ---- HUD ----
        INFO = add("Info", Category.HUD, "Client name, FPS and ping").defaultOn();
        HudWidgets.setupInfo(INFO);
        add("Inventory HUD", Category.HUD, "Your inventory on screen").defaultOn();
        add("Armor HUD", Category.HUD, "Armor durability").defaultOn();
        add("Effects HUD", Category.HUD, "All your potion effects and the time they last").defaultOn();
        add("Keybinds HUD", Category.HUD, "List of all the keys you bound").defaultOn();
    }

    public static Module add(String name, Category cat, String description) {
        Module m = new Module(name, cat, description);
        MODULES.add(m);
        return m;
    }

    public static void tick(MinecraftClient mc) {
        boolean free = mc.currentScreen == null;
        for (Module m : MODULES) {
            if (m.bind != Module.NO_KEY && mc.getWindow() != null) {
                boolean down = InputUtil.isKeyPressed(mc.getWindow(), m.bind);
                if (down && !m.bindWasDown && free) {
                    if (m.hasPress()) m.press(mc);       // Quick Swap: the key does the action
                    else m.toggle();
                }
                m.bindWasDown = down;
            }
            m.tick(mc);
        }
    }

    public static boolean isOn(String name) {
        for (Module m : MODULES) if (m.name.equals(name)) return m.enabled;
        return false;
    }

    public static Module get(String name) {
        for (Module m : MODULES) if (m.name.equals(name)) return m;
        return null;
    }
}
