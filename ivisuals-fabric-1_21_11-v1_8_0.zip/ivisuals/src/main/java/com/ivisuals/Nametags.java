package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * Nametags: pretty custom nicks over every player. Admins are RED (with an ADMIN badge), friends get a star and your
 * friend color, everybody else uses the color picked in the menu. The vanilla name tag of players is hidden
 * (PlayerRendererMixin) so you never see two.
 *
 * Admin detection: (1) nicks you marked (Shift + click in chat, or /ivisuals admin <nick>), (2) a rank in front of /
 * behind the nick (team prefix or tab list name) that starts with Admin / Owner / Founder / Админ / Овнер ...
 * The client can not read other players' op level, so there is no way to detect real operators.
 */
public final class Nametags {
    private Nametags() {}

    public static final int ADMIN_RGB = 0xFF3B3B;

    private static final Pattern ADMIN_RE = Pattern.compile(
            "(?iu)(?<![\\p{L}])(admin|adm|owner|ceo|founder|админ|адм|овнер|владелец|основател|создател)");

    private static Setting style, normalColor, size, range, showHealth, showDistance, showRank, autoAdmin,
            hideVanilla, showSelf, hideBehindWalls;

    public static void setup(Module m) {
        style = m.mode("Style", 0, "Glass", "Neon", "Minimal");
        normalColor = m.mode("Normal Players Color", 7, Fx.COLORS);      // White
        autoAdmin = m.toggle("Detect Admins (rank)", true);
        showRank = m.toggle("Show Rank", true);
        showHealth = m.toggle("Show Health", true);
        showDistance = m.toggle("Show Distance", true);
        size = m.slider("Size", 1f, 0.5f, 2f, 0.05f);
        range = m.slider("Range", 64f, 8f, 128f, 4f);
        hideVanilla = m.toggle("Hide Vanilla Name", true);
        hideBehindWalls = m.toggle("Hide Behind Walls", false);
        showSelf = m.toggle("Show Own (3rd person)", false);
    }

    public static boolean hidesVanilla() {
        return ModuleManager.NAMETAGS != null && ModuleManager.NAMETAGS.enabled && hideVanilla != null && hideVanilla.b();
    }

    // ------------------------------------------------------------------ hide the vanilla label

    private static Field[] labelFields;

    /**
     * Called by PlayerRendererMixin after the render state of a player is filled: removes the vanilla name text.
     * The field is found by its type (Text), so it does not depend on the mapping names.
     */
    public static void stripVanillaLabel(EntityRenderState st) {
        if (!hidesVanilla()) return;
        try {
            if (labelFields == null) {
                List<Field> l = new ArrayList<>();
                for (Field f : EntityRenderState.class.getDeclaredFields()) {
                    if (f.getType() == Text.class && !Modifier.isStatic(f.getModifiers())) {
                        f.setAccessible(true);
                        l.add(f);
                    }
                }
                labelFields = l.toArray(new Field[0]);
            }
            for (Field f : labelFields) f.set(st, null);
        } catch (Throwable ignored) {}
    }

    // ------------------------------------------------------------------ rank / admin info (cached)

    private static final class Info {
        String rank = "";
        boolean admin;
        long at;
    }

    private static final Map<UUID, Info> CACHE = new HashMap<>();

    private static Info info(MinecraftClient mc, AbstractClientPlayerEntity p, String name) {
        long now = System.currentTimeMillis();
        Info in = CACHE.get(p.getUuid());
        if (in != null && now - in.at < 1000) return in;
        if (in == null) {
            if (CACHE.size() > 300) CACHE.clear();
            in = new Info();
            CACHE.put(p.getUuid(), in);
        }
        in.at = now;

        // everything the server writes around the nick: team prefix / suffix and the tab list name
        StringBuilder sb = new StringBuilder();
        try { sb.append(p.getDisplayName().getString()); } catch (Throwable ignored) {}
        try {
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
                if (e != null && e.getDisplayName() != null) sb.append(' ').append(e.getDisplayName().getString());
            }
        } catch (Throwable ignored) {}
        String deco = sb.toString().replace(name, " ").replaceAll("\\s+", " ").trim();
        in.rank = deco.length() > 0 && deco.length() <= 16 ? deco : "";
        in.admin = Social.isManualAdmin(name) || (autoAdmin.b() && ADMIN_RE.matcher(deco).find());
        return in;
    }

    /** True when this player is shown as an admin. */
    public static boolean isAdmin(MinecraftClient mc, AbstractClientPlayerEntity p) {
        return info(mc, p, p.getName().getString()).admin;
    }

    // ------------------------------------------------------------------ render

    public static void render(DrawContext ctx, MinecraftClient mc, float tp) {
        if (!ModuleManager.NAMETAGS.enabled || mc.world == null || mc.player == null) return;
        Proj cam = Cosmetics.camera(mc, tp);
        if (cam == null) return;
        boolean first = mc.options.getPerspective().isFirstPerson();
        double r = range.f(), r2 = r * r;
        boolean seeInv = SeeInvisible.active();

        List<AbstractClientPlayerEntity> list = new ArrayList<>();
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player && (first || !showSelf.b())) continue;
            if (p.isSpectator() || p.isRemoved()) continue;
            if (p.isInvisible() && !seeInv) continue;                 // like vanilla: invisible = no name
            if (p.squaredDistanceTo(cam.cx, cam.cy, cam.cz) > r2) continue;
            if (hideBehindWalls.b() && p != mc.player && !mc.player.canSee(p)) continue;
            list.add(p);
        }
        list.sort(Comparator.comparingDouble(p -> -p.squaredDistanceTo(cam.cx, cam.cy, cam.cz)));   // far first
        int from = Math.max(0, list.size() - 40);
        float t = HudFx.time();
        for (int i = from; i < list.size(); i++) drawTag(ctx, mc, list.get(i), cam, tp, t, r);
    }

    private static void drawTag(DrawContext ctx, MinecraftClient mc, AbstractClientPlayerEntity p, Proj cam,
                                float tp, float t, double r) {
        Vec3d pos = p.getLerpedPos(tp);
        double[] sc = cam.project(pos.x, pos.y + p.getHeight() + 0.55, pos.z);
        if (sc == null || sc[0] < -150 || sc[0] > cam.sw + 150 || sc[1] < -40 || sc[1] > cam.sh + 40) return;

        double dist = Math.sqrt(p.squaredDistanceTo(cam.cx, cam.cy, cam.cz));
        String name = p.getName().getString();
        Info in = info(mc, p, name);
        boolean admin = in.admin;
        boolean friend = Friends.isFriend(name);
        float phase = (p.getId() % 7) / 7f;

        int rgb;
        if (admin) rgb = ADMIN_RGB;
        else if (friend) rgb = Friends.colorRgb(t, phase);
        else rgb = Fx.color(normalColor.i(), t, phase);

        float fade = (float) Math.max(0.3, 1.0 - Math.max(0.0, dist - r * 0.7) / (r * 0.3));
        if (p.isSneaking()) fade *= 0.6f;
        float sz = size.f() * (float) Math.max(0.6, Math.min(1.2, 1.35 - dist / Math.max(1.0, r) * 0.8));

        // ---- the pieces of the line: {text, argb, scale}
        List<Object[]> parts = new ArrayList<>();
        if (friend) parts.add(new Object[]{"\u2605", Draw.argb((int) (255 * fade), Friends.colorRgb(t, phase)), sz});
        if (admin) {
            String badge = showRank.b() && !in.rank.isEmpty() ? in.rank : "ADMIN";
            parts.add(new Object[]{badge, Draw.argb((int) (255 * fade), 0xFFFFFF), sz * 0.72f, "badge"});
        } else if (showRank.b() && !in.rank.isEmpty()) {
            parts.add(new Object[]{in.rank, Draw.argb((int) (170 * fade), rgb), sz * 0.72f});
        }
        parts.add(new Object[]{name, Draw.argb((int) (255 * fade), rgb), sz});
        if (showHealth.b()) {
            float hp = p.getHealth() + p.getAbsorptionAmount();
            float f = Math.max(0f, Math.min(1f, p.getMaxHealth() <= 0 ? 0f : p.getHealth() / p.getMaxHealth()));
            int hc = f > 0.5f ? Draw.lerp(0xFFF5C542, 0xFF46D369, (f - 0.5f) * 2f) : Draw.lerp(0xFFE5484D, 0xFFF5C542, f * 2f);
            parts.add(new Object[]{"\u2665" + Math.round(hp), Draw.mulAlpha(hc, fade), sz * 0.8f});
        }
        if (showDistance.b() && p != mc.player) {
            parts.add(new Object[]{Math.round(dist) + "m", Draw.argb((int) (150 * fade), 0xFFFFFF), sz * 0.7f});
        }

        // ---- measure
        int gap = Math.max(2, Math.round(4 * sz));
        int padX = Math.max(3, Math.round(5 * sz)), padY = Math.max(2, Math.round(3 * sz));
        int lineH = Math.max(6, Math.round(8f * sz));
        int[] widths = new int[parts.size()];
        int tw = 0;
        for (int i = 0; i < parts.size(); i++) {
            Object[] pt = parts.get(i);
            widths[i] = Draw.textWidth(mc.textRenderer, (String) pt[0], (Float) pt[2]);
            tw += widths[i];
            if (i > 0) tw += gap;
        }
        int w = tw + padX * 2, h = lineH + padY * 2;
        int x = Math.round((float) sc[0] - w / 2f), y = Math.round((float) sc[1] - h - 4);

        // ---- background
        int st = style.i();
        int rad = Math.max(3, Math.round(5 * sz));
        if (st == 0) {                                                       // Glass
            if (admin) Draw.glow(ctx, x, y, w, h, rad, rgb, 3, 0.22f * fade);
            Draw.roundRectV(ctx, x, y, w, h, rad, Draw.argb((int) (178 * fade), 0x17171B), Draw.argb((int) (178 * fade), 0x08080A));
            Draw.ring(ctx, x, y, w, h, rad, Draw.argb((int) (230 * fade), rgb), Draw.argb((int) (90 * fade), rgb));
        } else if (st == 1) {                                                // Neon
            Draw.glow(ctx, x, y, w, h, rad, rgb, 4, 0.38f * fade);
            Draw.roundRect(ctx, x, y, w, h, rad, Draw.argb((int) (210 * fade), 0x050507));
            Draw.ring(ctx, x, y, w, h, rad, Draw.argb((int) (255 * fade), rgb), Draw.argb((int) (255 * fade), rgb));
        } else {                                                             // Minimal: no box, a thin line under the text
            ctx.fill(x + padX, y + h - 1, x + w - padX, y + h, Draw.argb((int) (200 * fade), rgb));
        }

        // ---- text
        int cx = x + padX;
        for (int i = 0; i < parts.size(); i++) {
            Object[] pt = parts.get(i);
            float ps = (Float) pt[2];
            int th = Math.max(5, Math.round(8f * ps));
            int ty = y + padY + (lineH - th) / 2;
            if (pt.length > 3) {                                             // admin badge: small solid red pill
                int bw = widths[i] + 4;
                Draw.roundRect(ctx, cx - 2, ty - 1, bw, th + 2, 3, Draw.argb((int) (235 * fade), ADMIN_RGB));
            }
            Draw.text(ctx, mc.textRenderer, (String) pt[0], cx, ty, ps, (Integer) pt[1]);
            cx += widths[i] + gap;
        }

        // little marker pointing at the head
        if (st != 2) {
            int mx = Math.round((float) sc[0]);
            ctx.fill(mx - 1, y + h + 1, mx + 1, y + h + 3, Draw.argb((int) (230 * fade), rgb));
        }
    }
}
