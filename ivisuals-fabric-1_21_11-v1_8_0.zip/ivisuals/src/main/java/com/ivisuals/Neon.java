package com.ivisuals;

/** White / iridescent neon colors shared by the whole UI. No Minecraft classes. */
public final class Neon {
    private Neon() {}

    /** Color presets for trajectories etc. Index 0 = Neon (white with an iridescent shimmer). */
    public static final String[] COLORS = {
            "Neon", "Rainbow", "White", "Cyan", "Pink", "Gold", "Purple", "Red", "Green", "Aqua-Pink"
    };

    public static float now() {
        return (System.currentTimeMillis() % 1_000_000L) / 1000f;
    }

    /** Pastel iridescent neon (almost white, hue slowly drifting). RGB. */
    public static int rgb(float time, float phase) {
        if (Theme.active()) return Theme.soft(time, phase);
        return Fx.hsv(time * 0.12f + phase, 0.50f, 1f);
    }

    /** Saturated iridescent neon. RGB. */
    public static int strong(float time, float phase) {
        if (Theme.active()) return Theme.strong(time, phase);
        return Fx.hsv(time * 0.12f + phase, 0.85f, 1f);
    }

    /** Color for a preset index of COLORS. */
    public static int pick(int mode, float time, float phase) {
        if (mode <= 0) return rgb(time, phase);
        return Fx.color(mode - 1, time, phase);
    }
}
