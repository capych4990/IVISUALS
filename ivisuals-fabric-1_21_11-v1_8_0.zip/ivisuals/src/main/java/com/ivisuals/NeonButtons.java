package com.ivisuals;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Black / white minimal buttons with an iridescent neon edge: a slowly shifting pastel outline, a bright
 * "comet" running around it and a glow on hover. Drawn on top of every vanilla button / slider (the black
 * body itself comes from the resource-pack textures shipped in the mod).
 */
public final class NeonButtons {
    private NeonButtons() {}

    private static Setting style, glow, speed;
    private static final Map<ClickableWidget, float[]> STATE = new WeakHashMap<>();   // [hover, lastTime]

    public static void setup(Module m) {
        style = m.mode("Style", 0, "Iridescent", "White");
        glow = m.slider("Glow", 1f, 0f, 2f, 0.1f);
        speed = m.slider("Speed", 1f, 0.2f, 3f, 0.1f);
    }

    public static void draw(DrawContext ctx, ClickableWidget w) {
        if (!ModuleManager.NEON_UI.enabled || !w.visible) return;
        if (!(w instanceof ButtonWidget || w instanceof CyclingButtonWidget<?> || w instanceof SliderWidget)) return;
        int W = w.getWidth(), H = w.getHeight();
        if (W < 12 || H < 10) return;
        int x = w.getX(), y = w.getY();

        float time = Neon.now();
        float[] st = STATE.computeIfAbsent(w, k -> new float[]{0f, time});
        float dt = Math.min(0.1f, Math.max(0f, time - st[1]));
        st[1] = time;
        boolean hov = (w.isHovered() || w.isFocused()) && w.active;
        st[0] += ((hov ? 1f : 0f) - st[0]) * Math.min(1f, dt * 12f);
        float hv = st[0];

        boolean iri = style.i() == 0;
        float sp = speed.f();
        float g = glow.f();

        if (!w.active) {                                   // disabled: dim gray edge
            edge(ctx, x, y, W, H, 4, Draw.argb(60, 0x909090), null, 0, 0, 0, 0f, false);
            return;
        }

        // glow around the button
        if (hv > 0.02f && g > 0.01f) {
            int gc = iri ? Neon.rgb(time * sp, 0.15f) : 0xFFFFFF;
            ctx.fill(x - 1, y - 1, x + W + 1, y, Draw.argb((int) (70 * hv * g), gc));
            ctx.fill(x - 1, y + H, x + W + 1, y + H + 1, Draw.argb((int) (70 * hv * g), gc));
            ctx.fill(x - 1, y, x, y + H, Draw.argb((int) (70 * hv * g), gc));
            ctx.fill(x + W, y, x + W + 1, y + H, Draw.argb((int) (70 * hv * g), gc));
            ctx.fill(x - 2, y - 2, x + W + 2, y - 1, Draw.argb((int) (26 * hv * g), gc));
            ctx.fill(x - 2, y + H + 1, x + W + 2, y + H + 2, Draw.argb((int) (26 * hv * g), gc));
        }

        float perim = 2f * (W + H);
        float head = ((time * 0.30f * sp) % 1f) * perim;
        edge(ctx, x, y, W, H, 4, 0, iri ? Boolean.TRUE : Boolean.FALSE, head, perim, time * sp, hv, true);
    }

    /** One pixel outline around the button; either a fixed argb (flat) or the animated neon one. */
    private static void edge(DrawContext ctx, int x, int y, int W, int H, int step, int flat, Boolean iri,
                             float head, float perim, float time, float hv, boolean animated) {
        float pos = 0f;
        // top (left -> right), right (top -> bottom), bottom (right -> left), left (bottom -> top)
        for (int i = 1; i < W - 1; i += step) {
            int len = Math.min(step, W - 1 - i);
            seg(ctx, x + i, y, len, 1, pos + i, W, H, flat, iri, head, perim, time, hv, animated);
        }
        pos += W;
        for (int i = 1; i < H - 1; i += step) {
            int len = Math.min(step, H - 1 - i);
            seg(ctx, x + W - 1, y + i, 1, len, pos + i, W, H, flat, iri, head, perim, time, hv, animated);
        }
        pos += H;
        for (int i = 1; i < W - 1; i += step) {
            int len = Math.min(step, W - 1 - i);
            seg(ctx, x + W - 1 - i - len + 1, y + H - 1, len, 1, pos + i, W, H, flat, iri, head, perim, time, hv, animated);
        }
        pos += W;
        for (int i = 1; i < H - 1; i += step) {
            int len = Math.min(step, H - 1 - i);
            seg(ctx, x, y + H - 1 - i - len + 1, 1, len, pos + i, W, H, flat, iri, head, perim, time, hv, animated);
        }
    }

    private static void seg(DrawContext ctx, int x, int y, int w, int h, float pos, int W, int H, int flat, Boolean iri,
                            float head, float perim, float time, float hv, boolean animated) {
        if (!animated) { ctx.fill(x, y, x + w, y + h, flat); return; }
        float d = Math.abs(pos - head);
        d = Math.min(d, perim - d);
        float comet = (float) Math.exp(-(d * d) / (perim * perim * 0.004f));
        int rgb = iri ? Neon.rgb(time, pos / perim * 1.3f) : 0xFFFFFF;
        float a = 0.30f + 0.45f * hv + 0.60f * comet;
        if (iri) rgb = Fx.mix(0xFFFFFF, rgb, 0.45f + 0.5f * hv);       // hovered = more color, idle = near white
        ctx.fill(x, y, x + w, y + h, Draw.argb((int) (255 * Math.min(1f, a)), rgb));
    }
}
