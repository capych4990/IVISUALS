package com.ivisuals;

import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.particle.ParticlesMode;

import java.util.Objects;

/**
 * "Hard optimization": drops the heavy video options to the minimum and puts the old values back when it is
 * switched off. The original values are also kept in the config, so they come back even if the game was
 * closed while the module was on.
 *
 * v1.4: every option is applied on its own (one failing option no longer aborts the rest), the values are
 * re-applied every half second (the video settings screen / other mods could silently put them back, which
 * made the module look dead), and the FPS cap + VSync - the most common reason for "no FPS gain" - are lifted.
 */
public final class Optimizer {
    private Optimizer() {}

    private static Setting level, lowerDistance, unlockFps;

    // saved originals
    private static boolean saved;
    private static int sView, sSim, sBlend, sMaxFps = 120;
    private static double sEntity;
    private static boolean sShadows, sBob, sVsync = true;
    private static String sParticles = "ALL", sClouds = "FANCY", sGraphics = "FANCY";

    private static int appliedLevel = -1, counter;
    private static boolean appliedDistance, appliedFps;

    // per level: view, simulation (min 5), blend, entity scale
    private static final int[] VIEW = {8, 6, 4};
    private static final int[] SIM = {8, 6, 5};
    private static final int[] BLEND = {1, 0, 0};
    private static final double[] ENTITY = {0.75, 0.5, 0.5};

    public static void setup(Module m) {
        level = m.mode("Level", 1, "Medium", "Hard", "Extreme");
        lowerDistance = m.toggle("Lower Render Distance", true);
        unlockFps = m.toggle("Unlock FPS (no cap / VSync)", true);
    }

    /** Sets an option only when it differs; never throws. */
    private static <T> void set(SimpleOption<T> opt, T value) {
        try {
            if (!Objects.equals(opt.getValue(), value)) opt.setValue(value);
        } catch (Throwable ignored) {}
    }

    private static void save(GameOptions o) {
        try { sView = o.getViewDistance().getValue(); } catch (Throwable ignored) {}
        try { sSim = o.getSimulationDistance().getValue(); } catch (Throwable ignored) {}
        try { sBlend = o.getBiomeBlendRadius().getValue(); } catch (Throwable ignored) {}
        try { sEntity = o.getEntityDistanceScaling().getValue(); } catch (Throwable ignored) {}
        try { sShadows = o.getEntityShadows().getValue(); } catch (Throwable ignored) {}
        try { sBob = o.getBobView().getValue(); } catch (Throwable ignored) {}
        try { sParticles = o.getParticles().getValue().name(); } catch (Throwable ignored) {}
        try { sClouds = o.getCloudRenderMode().getValue().name(); } catch (Throwable ignored) {}
        try { sGraphics = o.getPreset().getValue().name(); } catch (Throwable ignored) {}
        try { sMaxFps = o.getMaxFps().getValue(); } catch (Throwable ignored) {}
        try { sVsync = o.getEnableVsync().getValue(); } catch (Throwable ignored) {}
        saved = true;
        Config.save();
    }

    /** @param first true when the level changed: also sets the graphics preset (it resets other options, so only once). */
    private static void enforce(GameOptions o, boolean first) {
        int lv = level.i();
        boolean dist = lowerDistance.b();
        boolean fps = unlockFps.b();

        if (first) set(o.getPreset(), GraphicsMode.FAST);
        set(o.getParticles(), lv == 0 ? ParticlesMode.DECREASED : ParticlesMode.MINIMAL);
        set(o.getEntityShadows(), false);
        set(o.getCloudRenderMode(), CloudRenderMode.OFF);
        set(o.getBiomeBlendRadius(), BLEND[lv]);
        set(o.getEntityDistanceScaling(), ENTITY[lv]);
        set(o.getBobView(), lv >= 1 ? Boolean.FALSE : Boolean.valueOf(sBob));

        if (dist) {
            set(o.getViewDistance(), Math.min(sView, VIEW[lv]));
            set(o.getSimulationDistance(), Math.min(sSim, SIM[lv]));
        } else {
            set(o.getViewDistance(), sView);
            set(o.getSimulationDistance(), sSim);
        }

        if (fps) {
            set(o.getMaxFps(), 260);                 // 260 = "unlimited"
            set(o.getEnableVsync(), Boolean.FALSE);
        } else {
            set(o.getMaxFps(), sMaxFps);
            set(o.getEnableVsync(), Boolean.valueOf(sVsync));
        }
        appliedLevel = lv;
        appliedDistance = dist;
        appliedFps = fps;
    }

    /** Called every tick while the module is on. */
    public static void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        GameOptions o = mc.options;
        if (!saved) save(o);
        boolean changed = appliedLevel != level.i() || appliedDistance != lowerDistance.b() || appliedFps != unlockFps.b();
        if (changed) {
            enforce(o, appliedLevel != level.i());
            counter = 0;
        } else if (++counter >= 10) {                // twice a second: keep the values from being undone
            counter = 0;
            enforce(o, false);
        }
    }

    public static void disable(MinecraftClient mc) {
        appliedLevel = -1;
        counter = 0;
        if (!saved || mc == null || mc.options == null) return;
        GameOptions o = mc.options;
        try { set(o.getPreset(), GraphicsMode.valueOf(sGraphics)); } catch (Throwable ignored) {}
        set(o.getViewDistance(), sView);
        set(o.getSimulationDistance(), sSim);
        set(o.getBiomeBlendRadius(), sBlend);
        set(o.getEntityDistanceScaling(), sEntity);
        set(o.getEntityShadows(), sShadows);
        set(o.getBobView(), sBob);
        try { set(o.getParticles(), ParticlesMode.valueOf(sParticles)); } catch (Throwable ignored) {}
        try { set(o.getCloudRenderMode(), CloudRenderMode.valueOf(sClouds)); } catch (Throwable ignored) {}
        set(o.getMaxFps(), sMaxFps);
        set(o.getEnableVsync(), sVsync);
        try { o.write(); } catch (Throwable ignored) {}
        saved = false;
        Config.save();
    }

    // ---- persistence of the original values ----
    public static void saveTo(JsonObject root) {
        if (!saved) return;
        JsonObject o = new JsonObject();
        o.addProperty("view", sView);
        o.addProperty("sim", sSim);
        o.addProperty("blend", sBlend);
        o.addProperty("entity", sEntity);
        o.addProperty("shadows", sShadows);
        o.addProperty("bob", sBob);
        o.addProperty("particles", sParticles);
        o.addProperty("clouds", sClouds);
        o.addProperty("graphics", sGraphics);
        o.addProperty("maxfps", sMaxFps);
        o.addProperty("vsync", sVsync);
        root.add("optimizerBackup", o);
    }

    public static void loadFrom(JsonObject root) {
        try {
            if (!root.has("optimizerBackup")) return;
            JsonObject o = root.getAsJsonObject("optimizerBackup");
            sView = o.get("view").getAsInt();
            sSim = o.get("sim").getAsInt();
            sBlend = o.get("blend").getAsInt();
            sEntity = o.get("entity").getAsDouble();
            sShadows = o.get("shadows").getAsBoolean();
            sBob = o.get("bob").getAsBoolean();
            sParticles = o.get("particles").getAsString();
            sClouds = o.get("clouds").getAsString();
            sGraphics = o.get("graphics").getAsString();
            if (o.has("maxfps")) sMaxFps = o.get("maxfps").getAsInt();
            if (o.has("vsync")) sVsync = o.get("vsync").getAsBoolean();
            saved = true;
        } catch (Exception ignored) {}
    }
}
