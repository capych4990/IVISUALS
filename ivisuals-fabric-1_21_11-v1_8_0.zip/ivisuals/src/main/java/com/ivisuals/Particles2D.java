package com.ivisuals;

import java.util.ArrayList;
import java.util.Random;

/**
 * Hit particles simulated in world space and drawn as pixel sprites on the HUD layer
 * (projected through Proj). No Minecraft classes, so no particle-API version problems.
 */
public final class Particles2D {
    private static final int MAX = 400;

    private static final class P {
        double x, y, z, vx, vy, vz;
        float age, life, size;
        Sprites.Sprite spr;
        int tint;
    }

    private final ArrayList<P> list = new ArrayList<>();
    private final Random rnd = new Random();

    public boolean isEmpty() { return list.isEmpty(); }
    public void clear() { list.clear(); }
    public Random rnd() { return rnd; }

    public void spawn(double x, double y, double z, Sprites.Sprite spr, int tint, float speed, float life, float size) {
        if (list.size() >= MAX) list.remove(0);
        P p = new P();
        p.x = x + (rnd.nextDouble() - 0.5) * 0.3;
        p.y = y + (rnd.nextDouble() - 0.5) * 0.3;
        p.z = z + (rnd.nextDouble() - 0.5) * 0.3;
        double ang = rnd.nextDouble() * Math.PI * 2;
        double hs = (1.2 + rnd.nextDouble() * 2.2) * speed;
        p.vx = Math.cos(ang) * hs;
        p.vz = Math.sin(ang) * hs;
        p.vy = (1.8 + rnd.nextDouble() * 2.4) * speed;
        p.life = life * (0.75f + rnd.nextFloat() * 0.5f);
        p.size = size * (0.85f + rnd.nextFloat() * 0.3f);
        p.spr = spr;
        p.tint = tint;
        list.add(p);
    }

    public void update(float dt, float gravity) {
        for (int i = list.size() - 1; i >= 0; i--) {
            P p = list.get(i);
            p.age += dt;
            if (p.age >= p.life) { list.remove(i); continue; }
            p.vy -= 9.0 * gravity * dt;
            double drag = Math.pow(0.45, dt); // light horizontal drag
            p.vx *= drag;
            p.vz *= drag;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.z += p.vz * dt;
        }
    }

    public void draw(Canvas c, Proj cam) {
        for (P p : list) {
            double[] s = cam.project(p.x, p.y, p.z);
            if (s == null) continue;
            float t = p.age / p.life;
            float pop = Math.min(1f, p.age / 0.12f);
            pop = 1f + 2.70158f * (float) Math.pow(pop - 1f, 3) + 1.70158f * (float) Math.pow(pop - 1f, 2);
            float fade = t > 0.65f ? Math.max(0f, (1f - t) / 0.35f) : 1f;
            double world = p.size * pop * 0.5;               // world size of a sprite (blocks)
            double px = world * cam.focal / s[2];            // size on screen in px
            int cell = Math.max(1, (int) Math.round(px / p.spr.w));
            int wTot = cell * p.spr.w, hTot = cell * p.spr.h;
            int x0 = (int) Math.round(s[0]) - wTot / 2, y0 = (int) Math.round(s[1]) - hTot / 2;
            if (x0 > cam.sw || y0 > cam.sh || x0 + wTot < 0 || y0 + hTot < 0) continue;
            int a = (int) (255 * fade) << 24;
            for (int row = 0; row < p.spr.h; row++) {
                int col = 0;
                while (col < p.spr.w) {
                    int v = p.spr.px[row * p.spr.w + col];
                    if (v == 0) { col++; continue; }
                    int rgb = p.spr.tinted ? p.tint : (v & 0xFFFFFF);
                    int end = col + 1;
                    while (end < p.spr.w) {
                        int v2 = p.spr.px[row * p.spr.w + end];
                        if (v2 == 0 || (!p.spr.tinted && (v2 & 0xFFFFFF) != rgb)) break;
                        end++;
                    }
                    c.fill(x0 + col * cell, y0 + row * cell, x0 + end * cell, y0 + (row + 1) * cell, a | rgb);
                    col = end;
                }
            }
        }
    }
}
