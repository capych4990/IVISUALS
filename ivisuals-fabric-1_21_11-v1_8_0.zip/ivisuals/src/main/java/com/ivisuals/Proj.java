package com.ivisuals;

import java.util.ArrayList;
import java.util.List;

/**
 * Pinhole camera for drawing world-space things (block boxes, particles) as a 2D overlay.
 * yaw / pitch in degrees, Minecraft convention. Pure math, no Minecraft classes.
 */
public final class Proj {
    public static final double NEAR = 0.05;

    public final double cx, cy, cz;
    private final double rx, ry, rz, ux, uy, uz, fx, fy, fz;
    public final double focal, midX, midY;
    public final int sw, sh;

    public Proj(double cx, double cy, double cz, float yawDeg, float pitchDeg, double fovDeg, int sw, int sh) {
        this.cx = cx; this.cy = cy; this.cz = cz;
        this.sw = sw; this.sh = sh;
        double yaw = Math.toRadians(yawDeg), pitch = Math.toRadians(pitchDeg);
        fx = -Math.sin(yaw) * Math.cos(pitch);
        fy = -Math.sin(pitch);
        fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw);
        ry = 0;
        rz = -Math.sin(yaw);
        // up = right x forward
        ux = ry * fz - rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;
        focal = (sh / 2.0) / Math.tan(Math.toRadians(fovDeg) / 2.0);
        midX = sw / 2.0;
        midY = sh / 2.0;
    }

    /** World point -> view space {right, up, forward}. */
    public double[] view(double x, double y, double z) {
        double dx = x - cx, dy = y - cy, dz = z - cz;
        return new double[]{
                dx * rx + dy * ry + dz * rz,
                dx * ux + dy * uy + dz * uz,
                dx * fx + dy * fy + dz * fz};
    }

    /** View space point (z >= NEAR) -> screen {x, y}. */
    public double[] screen(double[] v) {
        return new double[]{midX + v[0] / v[2] * focal, midY - v[1] / v[2] * focal};
    }

    /** World point -> {x, y, depth}, or null when behind the camera. */
    public double[] project(double x, double y, double z) {
        double[] v = view(x, y, z);
        if (v[2] < NEAR) return null;
        double[] s = screen(v);
        return new double[]{s[0], s[1], v[2]};
    }

    /** Clips a polygon (view space) against the near plane. */
    public static List<double[]> clipPoly(List<double[]> in) {
        List<double[]> out = new ArrayList<>();
        int n = in.size();
        for (int i = 0; i < n; i++) {
            double[] a = in.get(i), b = in.get((i + 1) % n);
            boolean ai = a[2] >= NEAR, bi = b[2] >= NEAR;
            if (ai) out.add(a);
            if (ai != bi) out.add(cut(a, b));
        }
        return out;
    }

    /** Clips a segment against the near plane; returns null if fully behind. */
    public static double[][] clipSegment(double[] a, double[] b) {
        boolean ai = a[2] >= NEAR, bi = b[2] >= NEAR;
        if (!ai && !bi) return null;
        if (ai && bi) return new double[][]{a, b};
        double[] m = cut(a, b);
        return ai ? new double[][]{a, m} : new double[][]{m, b};
    }

    private static double[] cut(double[] a, double[] b) {
        double t = (NEAR - a[2]) / (b[2] - a[2]);
        return new double[]{a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, NEAR};
    }
}
