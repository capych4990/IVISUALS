package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Quick Swap: press the key you bound to the module (Alt on its card, then the key) and the chosen item jumps into
 * your hand. Done with the same inventory "swap" click the game itself uses, so no mouse / screen is needed:
 *  - item is in the hotbar: that hotbar slot is selected
 *  - item is in the inventory: it is swapped with the slot in your hand (hand empty = it just moves there,
 *    hand busy = the two items change places)
 *
 * Press the key AGAIN while the item is in your hand and the last swap is undone: the item you had before comes
 * back to your hand (and the swapped item goes back to where it was), so you never have to move things back by hand.
 * Switch it off with the option "Press Again = Swap Back".
 */
public final class QuickSwap {
    private QuickSwap() {}

    public static final String[] ITEMS = {
            "Ender Pearl", "Golden Apple", "Ench. Golden Apple", "Totem of Undying", "Shield", "Firework Rocket",
            "Water Bucket", "Cobweb", "Obsidian", "End Crystal", "Splash Potion", "Wind Charge", "XP Bottle",
            "Chorus Fruit", "Mace", "Elytra"};

    private static Item item(int i) {
        return switch (i) {
            case 0 -> Items.ENDER_PEARL;
            case 1 -> Items.GOLDEN_APPLE;
            case 2 -> Items.ENCHANTED_GOLDEN_APPLE;
            case 3 -> Items.TOTEM_OF_UNDYING;
            case 4 -> Items.SHIELD;
            case 5 -> Items.FIREWORK_ROCKET;
            case 6 -> Items.WATER_BUCKET;
            case 7 -> Items.COBWEB;
            case 8 -> Items.OBSIDIAN;
            case 9 -> Items.END_CRYSTAL;
            case 10 -> Items.SPLASH_POTION;
            case 11 -> Items.WIND_CHARGE;
            case 12 -> Items.EXPERIENCE_BOTTLE;
            case 13 -> Items.CHORUS_FRUIT;
            case 14 -> Items.MACE;
            default -> Items.ELYTRA;
        };
    }

    private static final class Slot {
        Setting item, hand, back;
        // what the last swap did, so that pressing again can undo it
        int undo;      // 0 = nothing, 1 = hotbar slot selected, 2 = inventory <-> hotbar slot, 3 = inventory/hotbar <-> off hand
        int a, b;      // 1: a = slot that was selected to, b = slot that was selected before
                       // 2: a = inventory slot id, b = hotbar slot (0-8)
                       // 3: a = screen handler slot id
    }

    private static final Slot[] SLOTS = {new Slot(), new Slot(), new Slot()};

    public static void setup(Module m, int index) {
        Slot s = SLOTS[index];
        int[] def = {0, 1, 3};
        s.item = m.mode("Item", def[index], ITEMS);
        s.hand = m.mode("Into", index == 2 ? 1 : 0, "Main Hand", "Off Hand");
        s.back = m.toggle("Press Again = Swap Back", true);
    }

    /** Short text for the keybind list: "Ender Pearl > Main Hand". */
    public static String describe(int index) {
        if (index < 0 || index >= SLOTS.length || SLOTS[index].item == null) return "";
        Slot s = SLOTS[index];
        return s.item.mode() + " > " + (s.hand.i() == 1 ? "Off Hand" : "Main Hand");
    }

    public static void press(MinecraftClient mc, int index) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;
        Slot s = SLOTS[index];
        Item want = item(s.item.i());
        boolean off = s.hand.i() == 1;
        PlayerInventory inv = p.getInventory();
        int syncId = p.playerScreenHandler.syncId;

        // already in the hand: a second press undoes the last swap
        if (off ? p.getOffHandStack().isOf(want) : p.getMainHandStack().isOf(want)) {
            if (s.back.b()) undo(mc, p, s, want);
            return;
        }

        int found = -1;                                    // hotbar first (0-8), then the inventory (9-35)
        for (int i = 0; i < 36 && found < 0; i++) if (inv.getStack(i).isOf(want)) found = i;
        if (found < 0) return;

        if (!off) {
            if (found < 9) {
                s.undo = 1;
                s.a = found;
                s.b = inv.getSelectedSlot();
                inv.setSelectedSlot(found);
            } else {
                // inventory slot <-> the hotbar slot that is in your hand
                s.undo = 2;
                s.a = found;
                s.b = inv.getSelectedSlot();
                mc.interactionManager.clickSlot(syncId, found, inv.getSelectedSlot(), SlotActionType.SWAP, p);
            }
        } else {
            int slotId = found < 9 ? 36 + found : found;   // hotbar slots are 36-44 in the inventory screen handler
            s.undo = 3;
            s.a = slotId;
            mc.interactionManager.clickSlot(syncId, slotId, 40, SlotActionType.SWAP, p);   // 40 = off hand
        }
    }

    /** Puts everything back the way it was before the last swap of this slot. */
    private static void undo(MinecraftClient mc, ClientPlayerEntity p, Slot s, Item want) {
        PlayerInventory inv = p.getInventory();
        int syncId = p.playerScreenHandler.syncId;
        switch (s.undo) {
            case 1 -> {
                if (inv.getSelectedSlot() == s.a) inv.setSelectedSlot(s.b);
            }
            case 2 -> {
                // the swap is its own opposite: doing the same click again puts both items back
                if (inv.getSelectedSlot() == s.b && inv.getStack(s.b).isOf(want)) {
                    mc.interactionManager.clickSlot(syncId, s.a, s.b, SlotActionType.SWAP, p);
                }
            }
            case 3 -> {
                if (p.getOffHandStack().isOf(want)) {
                    mc.interactionManager.clickSlot(syncId, s.a, 40, SlotActionType.SWAP, p);
                }
            }
            default -> { }
        }
        s.undo = 0;       // one step back only; the next press swaps forward again
    }
}
