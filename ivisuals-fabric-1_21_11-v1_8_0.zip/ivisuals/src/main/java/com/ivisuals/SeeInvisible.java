package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * See Invisible: players (or all living things) under the invisibility effect are drawn as a see-through ghost, the
 * same way the game shows them to spectators / teammates. Optional glow outline so you also find them through walls.
 *
 * How: EntityMixin answers "isInvisibleTo(you)" with false for the entities picked here, and the vanilla renderer
 * then draws the translucent version. The server still decides what it sends: an entity the server never sends can
 * not be shown.
 */
public final class SeeInvisible {
    private SeeInvisible() {}

    private static Setting targets, outline, color;
    private static final Set<Integer> GLOWING = ConcurrentHashMap.newKeySet();
    private static World lastWorld;

    public static void setup(Module m) {
        targets = m.mode("Targets", 0, "Players", "Players + Mobs");
        outline = m.toggle("Outline (see through walls)", true);
        color = m.mode("Outline Color", 1, Fx.COLORS);       // Cyan
    }

    public static boolean active() {
        return ModuleManager.SEE_INVISIBLE != null && ModuleManager.SEE_INVISIBLE.enabled;
    }

    private static boolean accepts(Entity e) {
        if (e instanceof PlayerEntity) return true;
        return targets.i() == 1 && e instanceof LivingEntity;
    }

    /** EntityMixin.isInvisibleTo: true = draw this invisible entity as a ghost for the local player. */
    public static boolean reveals(Entity e) {
        if (!active()) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || !mc.isOnThread() || mc.world == null) return false;   // the integrated server must not see it
        return accepts(e);
    }

    public static boolean glows(int entityId) {
        if (GLOWING.isEmpty()) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc != null && mc.isOnThread() && GLOWING.contains(entityId);
    }

    public static Integer colorFor(int entityId) {
        if (GLOWING.isEmpty() || !GLOWING.contains(entityId)) return null;
        return Fx.color(color.i(), HudFx.time(), (entityId % 7) / 7f);
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { GLOWING.clear(); lastWorld = null; return; }
        if (mc.world != lastWorld) { GLOWING.clear(); lastWorld = mc.world; }
        Set<Integer> seen = new HashSet<>();
        if (outline.b()) {
            for (Entity e : mc.world.getEntities()) {
                if (e == mc.player || e.isRemoved() || !e.isInvisible() || !accepts(e)) continue;
                GLOWING.add(e.getId());
                seen.add(e.getId());
            }
        }
        Iterator<Integer> it = GLOWING.iterator();
        while (it.hasNext()) if (!seen.contains(it.next())) it.remove();
    }

    public static void clear() { GLOWING.clear(); }
}
