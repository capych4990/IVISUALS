package com.ivisuals;

import java.util.Locale;

/** One option of a module: slider, mode (cycle list) or toggle. */
public final class Setting {
    public enum Type { SLIDER, MODE, TOGGLE }

    public final Type type;
    public final String name;
    public final float min, max, step, def;
    public final String[] options;
    private float value;

    private Setting(Type type, String name, float def, float min, float max, float step, String[] options) {
        this.type = type;
        this.name = name;
        this.def = def;
        this.min = min;
        this.max = max;
        this.step = step;
        this.options = options;
        this.value = def;
    }

    public static Setting slider(String name, float def, float min, float max, float step) {
        return new Setting(Type.SLIDER, name, def, min, max, step, null);
    }

    public static Setting mode(String name, int def, String... options) {
        return new Setting(Type.MODE, name, def, 0, options.length - 1, 1, options);
    }

    public static Setting toggle(String name, boolean def) {
        return new Setting(Type.TOGGLE, name, def ? 1f : 0f, 0, 1, 1, null);
    }

    public float f() { return value; }
    public int i() { return Math.round(value); }
    public boolean b() { return value >= 0.5f; }
    public String mode() { return options[i()]; }

    public void set(float v) {
        switch (type) {
            case SLIDER -> {
                v = Math.max(min, Math.min(max, v));
                v = Math.round((v - min) / step) * step + min;
                v = Math.round(v * 10000f) / 10000f;
                value = Math.max(min, Math.min(max, v));
            }
            case MODE -> value = Math.max(0, Math.min(options.length - 1, Math.round(v)));
            case TOGGLE -> value = v >= 0.5f ? 1f : 0f;
        }
    }

    public void reset() { value = def; }

    /** Next / previous option (wraps around). */
    public void cycle(int dir) {
        if (type == Type.MODE) {
            int n = options.length;
            value = ((i() + dir) % n + n) % n;
        } else if (type == Type.TOGGLE) {
            value = b() ? 0f : 1f;
        }
    }

    public float frac() { return max <= min ? 0f : (value - min) / (max - min); }

    public String text() {
        return switch (type) {
            case SLIDER -> step >= 1f ? String.valueOf(Math.round(value)) : String.format(Locale.ROOT, "%.2f", value);
            case MODE -> mode();
            case TOGGLE -> b() ? "On" : "Off";
        };
    }
}
