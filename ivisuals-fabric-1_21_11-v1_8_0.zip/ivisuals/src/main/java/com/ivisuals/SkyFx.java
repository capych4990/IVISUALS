package com.ivisuals;

/** Custom sky / cloud color: animated modes picked in the "Sky" card. Read by the ClientWorld mixins. */
public final class SkyFx {
    private SkyFx() {}

    private static Setting mode, speed, solid, clouds, bright;

    public static void setup(Module m) {
        mode = m.mode("Style", 0, "Rainbow", "Neon Pulse", "Sunset", "Aurora", "Galaxy", "Black & White", "Solid Color");
        speed = m.slider("Speed", 1f, 0.1f, 4f, 0.1f);
        bright = m.slider("Brightness", 1f, 0.3f, 1.4f, 0.05f);
        solid = m.mode("Solid Color", 1, Fx.COLORS);
        clouds = m.toggle("Tint Clouds", true);
    }

    public static boolean active() {
        return ModuleManager.SKY != null && ModuleManager.SKY.enabled;
    }

    public static boolean tintClouds() { return active() && clouds.b(); }

    private static float time() { return HudFx.time() * speed.f(); }

    /** RGB of the sky. phase shifts the color a bit (used for the clouds). */
    public static int rgb(float phase) {
        float t = time();
        int c;
        switch (mode.i()) {
            case 1 -> c = Fx.mix(0x00E5FF, 0xFF4FD8, 0.5f + 0.5f * (float) Math.sin(t * 0.9f + phase * 6.283f));
            case 2 -> {                                         // sunset: orange <-> magenta <-> violet
                float k = 0.5f + 0.5f * (float) Math.sin(t * 0.35f + phase * 3f);
                c = k < 0.5f ? Fx.mix(0xFF7A2F, 0xFF3C7D, k * 2f) : Fx.mix(0xFF3C7D, 0x7B3CFF, (k - 0.5f) * 2f);
            }
            case 3 -> {                                         // aurora: green / teal / violet
                float k = 0.5f + 0.5f * (float) Math.sin(t * 0.5f + phase * 4f);
                c = k < 0.5f ? Fx.mix(0x16FF9A, 0x18B6FF, k * 2f) : Fx.mix(0x18B6FF, 0xA23BFF, (k - 0.5f) * 2f);
            }
            case 4 -> {                                         // galaxy: deep blue / purple
                float k = 0.5f + 0.5f * (float) Math.sin(t * 0.3f + phase * 2f);
                c = Fx.mix(0x0B0630, 0x5A1FA8, k);
            }
            case 5 -> {                                         // black & white breathing
                float k = 0.5f + 0.5f * (float) Math.sin(t * 0.6f + phase * 2f);
                int g = (int) (20 + 200 * k);
                c = (g << 16) | (g << 8) | g;
            }
            case 6 -> c = Fx.color(solid.i(), t, phase);
            default -> c = Fx.hsv(t * 0.08f + phase * 0.25f, 0.65f, 1f);
        }
        float b = bright.f();
        int r = Math.min(255, (int) (((c >> 16) & 255) * b));
        int g = Math.min(255, (int) (((c >> 8) & 255) * b));
        int bl = Math.min(255, (int) ((c & 255) * b));
        return (r << 16) | (g << 8) | bl;
    }

    /** Same color as a 0..1 vector (for the variants that return a Vec3d). */
    public static net.minecraft.util.math.Vec3d vec(float phase) {
        int c = rgb(phase);
        return new net.minecraft.util.math.Vec3d(((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0, (c & 255) / 255.0);
    }

    // The sky / cloud color getters return either an int (ARGB) or a Vec3d depending on the game version. Both
    // mixin variants are installed; at run time we look at the real return type (by shape, names are obfuscated)
    // so only the matching one answers.
    private static int skyKind = -1, cloudKind = -1;           // 0 = none, 1 = int, 2 = Vec3d

    private static void scan() {
        if (skyKind >= 0) return;
        skyKind = 0;
        cloudKind = 0;
        try {
            for (java.lang.reflect.Method m : net.minecraft.client.world.ClientWorld.class.getDeclaredMethods()) {
                Class<?>[] p = m.getParameterTypes();
                Class<?> r = m.getReturnType();
                int kind = r == int.class ? 1 : r == net.minecraft.util.math.Vec3d.class ? 2 : 0;
                if (kind == 0) continue;
                if (p.length == 2 && p[0] == net.minecraft.util.math.Vec3d.class && p[1] == float.class) skyKind = kind;
                else if (p.length == 1 && p[0] == float.class) cloudKind = cloudKind == 0 ? kind : -2;
            }
        } catch (Throwable ignored) {}
        if (cloudKind == -2) cloudKind = 0;
    }

    public static boolean skyInt() { scan(); return skyKind == 1; }
    public static boolean skyVec() { scan(); return skyKind == 2; }
    public static boolean cloudInt() { scan(); return cloudKind == 1; }
    public static boolean cloudVec() { scan(); return cloudKind == 2; }
}
