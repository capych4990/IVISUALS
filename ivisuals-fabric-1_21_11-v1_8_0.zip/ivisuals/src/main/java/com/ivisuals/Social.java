package com.ivisuals;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Friends and admins by nick. Saved in config/ivisuals.json ("friends" / "admins").
 * Names are compared ignoring case.
 */
public final class Social {
    private Social() {}

    private static final Map<String, String> FRIENDS = new ConcurrentHashMap<>();   // lower case -> as typed
    private static final Map<String, String> ADMINS = new ConcurrentHashMap<>();

    private static String key(String name) { return name.toLowerCase(Locale.ROOT); }

    public static boolean isFriend(String name) { return name != null && FRIENDS.containsKey(key(name)); }
    public static boolean isManualAdmin(String name) { return name != null && ADMINS.containsKey(key(name)); }

    /** Adds the nick or removes it when it is already there. Returns true when it is now in the list. */
    public static boolean toggleFriend(String name) { return toggle(FRIENDS, name); }
    public static boolean toggleAdmin(String name) { return toggle(ADMINS, name); }

    private static boolean toggle(Map<String, String> map, String name) {
        String k = key(name);
        boolean now;
        if (map.remove(k) != null) now = false;
        else { map.put(k, name); now = true; }
        Config.save();
        return now;
    }

    public static List<String> friends() { return new ArrayList<>(new TreeMap<>(FRIENDS).values()); }
    public static List<String> admins() { return new ArrayList<>(new TreeMap<>(ADMINS).values()); }

    // ------------------------------------------------------------------ config

    public static void loadFrom(JsonObject o) {
        read(o, "friends", FRIENDS);
        read(o, "admins", ADMINS);
    }

    private static void read(JsonObject o, String field, Map<String, String> into) {
        into.clear();
        if (!o.has(field) || !o.get(field).isJsonArray()) return;
        for (JsonElement e : o.getAsJsonArray(field)) {
            try {
                String s = e.getAsString();
                if (s != null && !s.isBlank()) into.put(key(s), s);
            } catch (Exception ignored) {}
        }
    }

    public static void saveTo(JsonObject o) {
        o.add("friends", write(FRIENDS));
        o.add("admins", write(ADMINS));
    }

    private static JsonArray write(Map<String, String> map) {
        JsonArray a = new JsonArray();
        for (String s : new TreeMap<>(map).values()) a.add(s);
        return a;
    }

    // ------------------------------------------------------------------ names of the players that are online

    /** Name of a GameProfile. The accessor is called name() in new versions and getName() in old ones. */
    private static String profileName(Object profile) {
        if (profile == null) return null;
        for (String m : new String[]{"name", "getName"}) {
            try {
                Method me = profile.getClass().getMethod(m);
                Object r = me.invoke(profile);
                if (r instanceof String s) return s;
            } catch (Throwable ignored) {}
        }
        return null;
    }

    /** Everybody in the tab list plus everybody you can see. */
    public static List<String> onlineNames(MinecraftClient mc) {
        List<String> out = new ArrayList<>();
        try {
            if (mc.getNetworkHandler() != null) {
                for (PlayerListEntry e : mc.getNetworkHandler().getPlayerList()) {
                    String n = profileName(e.getProfile());
                    if (n != null && !n.isEmpty() && !out.contains(n)) out.add(n);
                }
            }
        } catch (Throwable ignored) {}
        if (mc.world != null) {
            for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
                String n = p.getName().getString();
                if (!n.isEmpty() && !out.contains(n)) out.add(n);
            }
        }
        return out;
    }

    public static String nameOfProfileEntry(PlayerListEntry e) {
        return e == null ? null : profileName(e.getProfile());
    }
}
