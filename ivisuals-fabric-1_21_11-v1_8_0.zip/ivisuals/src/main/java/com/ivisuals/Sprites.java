package com.ivisuals;

import java.util.HashMap;
import java.util.Map;

/** Tiny pixel-art sprites drawn in code (no textures needed). */
public final class Sprites {
    private Sprites() {}

    public static final class Sprite {
        public final int w, h;
        /** 0 = transparent, otherwise RGB (alpha is added when drawing). */
        public final int[] px;
        /** If true every pixel is drawn in the particle's own tint instead. */
        public final boolean tinted;

        Sprite(String[] rows, Map<Character, Integer> pal, boolean tinted) {
            this.h = rows.length;
            this.w = rows[0].length();
            this.px = new int[w * h];
            this.tinted = tinted;
            for (int y = 0; y < h; y++) {
                if (rows[y].length() != w) throw new IllegalStateException("bad sprite row " + y);
                for (int x = 0; x < w; x++) {
                    Integer col = pal.get(rows[y].charAt(x));
                    px[y * w + x] = col == null ? 0 : (col | 0x1000000); // bit 24 marks "set" so black stays visible
                }
            }
        }
    }

    private static Map<Character, Integer> pal(Object... kv) {
        Map<Character, Integer> m = new HashMap<>();
        for (int i = 0; i < kv.length; i += 2) m.put((Character) kv[i], (Integer) kv[i + 1]);
        return m;
    }

    public static final Sprite DOLLAR = new Sprite(new String[]{
            "ddddddddddd",
            "dgggwwwgggd",
            "dglgwggglgd",
            "dgggwwwgggd",
            "dglgggwglgd",
            "dgggwwwgggd",
            "ddddddddddd"},
            pal('d', 0x1B5E20, 'g', 0x4CAF50, 'l', 0x81C784, 'w', 0xE8F5E9), false);

    public static final Sprite DUCK = new Sprite(new String[]{
            "...yyyy....",
            "..yyyyyy...",
            "..yyeyyy...",
            "ooyyyyyy...",
            "..yyyyyyy.y",
            ".yyyyyyyyyy",
            ".yyyhhhyyyy",
            "..yyyyyyyy.",
            "...yyyyyy.."},
            pal('y', 0xFFD83A, 'h', 0xE8B800, 'e', 0x202020, 'o', 0xFF8A00), false);

    public static final Sprite CROWN = new Sprite(new String[]{
            "y....y....y",
            "yy..yyy..yy",
            "yyyyyyyyyyy",
            "yyyyyyyyyyy",
            "yyryybyyryy",
            "yyyyyyyyyyy",
            "ddddddddddd"},
            pal('y', 0xFFD700, 'd', 0xC79100, 'r', 0xE53935, 'b', 0x1E88E5), false);

    public static final Sprite HEART = new Sprite(new String[]{
            ".rrr.rrr.",
            "rrrrrrrrr",
            "rrwrrrrrr",
            "rrrrrrrrr",
            ".rrrrrrr.",
            "..rrrrr..",
            "...rrr...",
            "....r...."},
            pal('r', 0xFF3B5C, 'w', 0xFFB3C1), false);

    public static final Sprite SPARK = new Sprite(new String[]{
            ".x.",
            "xxx",
            ".x."},
            pal('x', 0xFFFFFF), true);

    public static final Sprite[] MIX = {DOLLAR, DUCK, CROWN, HEART};
}
