package com.ivisuals;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

/** Replacement for the first-person swing: hits can go away from you, toward you, sideways... */
public final class SwingAnimation {
    private SwingAnimation() {}

    public static final String[] MODES = {
            "Vanilla", "Away", "Toward", "Left", "Right", "Chop", "Uppercut", "Spin", "Flip", "Shake"};

    private static Setting mode, amp;

    public static void setup(Module m) {
        mode = m.mode("Animation", 1, MODES);
        amp = m.slider("Amplitude", 1f, 0.2f, 2.5f, 0.05f);
    }

    private static void rx(MatrixStack m, float deg) { m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(deg)); }
    private static void ry(MatrixStack m, float deg) { m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(deg)); }
    private static void rz(MatrixStack m, float deg) { m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(deg)); }

    private static float ease(float t) { return t * t * (3f - 2f * t); }

    /** @return true if the swing was applied (vanilla swing must then be skipped) */
    public static boolean apply(MatrixStack m, Arm arm, float p) {
        int md = mode.i();
        if (md == 0) return false;
        float side = arm == Arm.RIGHT ? 1f : -1f;
        float a = amp.f();
        float s = (float) Math.sin(p * Math.PI);                 // 0 -> 1 -> 0
        float g = (float) Math.sin(Math.sqrt(p) * Math.PI);      // fast start, like vanilla
        switch (md) {
            case 1 -> {                                           // away from you
                m.translate(-side * 0.04f * a * g, 0.06f * a * g, -0.65f * a * g);
                rx(m, -22f * a * g);
            }
            case 2 -> {                                           // toward you
                m.translate(0f, 0.10f * a * g, 0.45f * a * g);
                rx(m, 25f * a * g);
            }
            case 3 -> {                                           // sweep to the left
                m.translate(-0.12f * a * s, 0f, 0f);
                ry(m, 75f * a * g);
                rz(m, -side * 25f * a * s);
            }
            case 4 -> {                                           // sweep to the right
                m.translate(0.12f * a * s, 0f, 0f);
                ry(m, -75f * a * g);
                rz(m, side * 25f * a * s);
            }
            case 5 -> {                                           // chop down
                m.translate(0f, -0.10f * a * s, -0.10f * a * s);
                rx(m, -105f * a * g);
            }
            case 6 -> {                                           // uppercut
                m.translate(0f, 0.10f * a * s, -0.15f * a * s);
                rx(m, 75f * a * g);
            }
            case 7 -> {                                           // spin (roll)
                m.translate(0f, 0f, -0.20f * a * s);
                rz(m, 360f * a * ease(p));
            }
            case 8 -> {                                           // front flip
                m.translate(0f, 0f, -0.20f * a * s);
                rx(m, -360f * a * ease(p));
            }
            case 9 -> {                                           // quick shake
                m.translate(0f, 0.05f * a * s, -0.20f * a * s);
                rz(m, side * 35f * a * (float) Math.sin(p * Math.PI * 4) * (1f - p));
            }
            default -> { return false; }
        }
        return true;
    }
}
