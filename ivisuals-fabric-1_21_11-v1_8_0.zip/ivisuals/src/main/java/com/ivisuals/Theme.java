package com.ivisuals;

/**
 * Client color. "Default" keeps the original white / iridescent look; any other preset (or Custom) turns the whole
 * client into that color: menu, HUD, highlights, neon edges (everything that uses Neon.rgb / Neon.strong).
 * Pure Java, no Minecraft classes.
 */
public final class Theme {
    private Theme() {}

    public static final String[] PRESETS = {
            "Default", "Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Pink", "White", "Rainbow", "Custom"
    };
    private static final int[] RGB = {
            0xFFFFFF, 0xFF2D2D, 0xFF8A1F, 0xFFE12E, 0x2DFF6A, 0x22E5FF, 0x3A6BFF, 0xA855FF, 0xFF4FD8, 0xFFFFFF
    };

    private static Module module;
    private static Setting preset, hue, sat, speed;

    public static void setup(Module m) {
        module = m;
        preset = m.mode("Color", 0, PRESETS);
        hue = m.slider("Custom Hue", 0f, 0f, 360f, 1f);
        sat = m.slider("Custom Saturation", 1f, 0f, 1f, 0.05f);
        speed = m.slider("Rainbow Speed", 1f, 0.2f, 4f, 0.1f);
    }

    /** True when the client is NOT using the original white / iridescent look. */
    public static boolean active() {
        return module != null && module.enabled && preset != null && preset.i() != 0;
    }

    private static int solid(float time, float phase) {
        int p = preset.i();
        if (p == 10) return Fx.hsv(time * 0.10f * speed.f() + phase * 0.6f, 0.90f, 1f);
        if (p == 11) return Fx.hsv(hue.f() / 360f, sat.f(), 1f);
        return RGB[Math.max(0, Math.min(RGB.length - 1, p))];
    }

    /** Soft themed color (a little lighter, shimmering). Used where Neon.rgb used to be pastel white. */
    public static int soft(float time, float phase) {
        int c = solid(time, phase);
        if (preset.i() == 9) return 0xFFFFFF;                      // plain white
        float shimmer = 0.10f + 0.10f * (float) Math.sin(time * 1.6f + phase * 6.283f);
        return Fx.mix(c, 0xFFFFFF, shimmer);
    }

    /** Full themed color. */
    public static int strong(float time, float phase) {
        return solid(time, phase);
    }

    /** Accent for flat UI parts (switches, sliders, selection). White while the theme is Default. */
    public static int accent(float time) {
        return active() ? solid(time, 0f) : 0xFFFFFF;
    }
}
