package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Shows where ender pearls, arrows, tridents and other throwables are going to land (drawn on the HUD
 * layer through Proj, first person). When ANOTHER player pearls, his pearl path is shown and a see-through
 * model of him appears where he will arrive (and stays there for a few seconds after the teleport).
 */
public final class Trajectories {
    private Trajectories() {}

    private static Setting color, width, opacity, pearls, arrows, others, myAim, marker, ghosts, ghostTime, origin, labels;

    public static void setup(Module m) {
        color = m.mode("Color", 0, Neon.COLORS);
        width = m.slider("Line Width", 1f, 1f, 3f, 1f);
        opacity = m.slider("Opacity", 0.9f, 0.1f, 1f, 0.05f);
        pearls = m.toggle("Ender Pearls", true);
        arrows = m.toggle("Arrows / Tridents", true);
        others = m.toggle("Snowballs / Potions / Eggs", true);
        myAim = m.toggle("My Aim (held item)", true);
        marker = m.toggle("Landing Marker", true);
        ghosts = m.toggle("Pearl Player Model", true);
        ghostTime = m.slider("Model Time (s)", 4f, 1f, 10f, 0.5f);
        origin = m.toggle("Model At Start", true);
        labels = m.toggle("Name / Distance", true);
    }

    // ------------------------------------------------------------------ data

    private static final class Info {
        Entity e;
        int group;                 // 0 pearl, 1 arrow-like, 2 other
        boolean still;
        Entity owner;
        boolean mine;
        Ballistics.Result path;
        double vx, vy, vz;
    }

    private static final class Track {
        Entity entity, owner;
        String name = "?";
        boolean mine;
        final List<double[]> trail = new ArrayList<>();
        double ox, oy, oz;
        float oyaw;
        int seen;
    }

    private static final class Landed {
        String name;
        List<double[]> trail;
        double x, y, z, ox, oy, oz;
        float yaw, oyaw;
        long end;
    }

    private static final List<Info> LIVE = new ArrayList<>();
    private static final Map<Integer, double[]> LAST = new HashMap<>();   // id -> x, y, z, ticks standing still
    private static final Map<Integer, Track> TRACKS = new HashMap<>();
    private static final List<Landed> LANDED = new ArrayList<>();
    private static Object lastWorld;
    private static int tickNo;

    public static void clear() {
        LIVE.clear();
        LAST.clear();
        TRACKS.clear();
        LANDED.clear();
    }

    // ------------------------------------------------------------------ physics table

    /** {gravity, drag, group} or null when the entity type is not a projectile we draw. */
    private static double[] params(String id) {
        return switch (id) {
            case "ender_pearl" -> new double[]{0.03, 0.99, 0};
            case "arrow", "spectral_arrow", "trident" -> new double[]{0.05, 0.99, 1};
            case "snowball", "egg" -> new double[]{0.03, 0.99, 2};
            case "splash_potion", "lingering_potion", "potion" -> new double[]{0.05, 0.99, 2};
            case "experience_bottle" -> new double[]{0.07, 0.99, 2};
            default -> null;
        };
    }

    private static boolean groupOn(int g) {
        return g == 0 ? pearls.b() : g == 1 ? arrows.b() : others.b();
    }

    private static Ballistics.Hit hitTest(MinecraftClient mc) {
        return (x0, y0, z0, x1, y1, z1) -> {
            BlockHitResult r = mc.world.raycast(new RaycastContext(new Vec3d(x0, y0, z0), new Vec3d(x1, y1, z1),
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
            if (r.getType() == HitResult.Type.MISS) return null;
            Vec3d p = r.getPos();
            return new double[]{p.x, p.y, p.z, r.getSide().ordinal()};
        };
    }

    // ------------------------------------------------------------------ tick

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { clear(); lastWorld = null; return; }
        if (mc.world != lastWorld) { clear(); lastWorld = mc.world; }
        tickNo++;
        LIVE.clear();
        Ballistics.Hit hit = hitTest(mc);
        double minY = mc.world.getBottomY() - 8;

        for (Entity e : mc.world.getEntities()) {
            if (e.isRemoved() || !(e instanceof ProjectileEntity pe)) continue;
            double[] prm = params(Registries.ENTITY_TYPE.getId(e.getType()).getPath());
            if (prm == null) continue;
            int g = (int) prm[2];
            if (!groupOn(g)) continue;

            // standing still (arrow stuck in a block)?
            double[] last = LAST.get(e.getId());
            boolean still = false;
            if (last == null) {
                LAST.put(e.getId(), new double[]{e.getX(), e.getY(), e.getZ(), 0});
            } else {
                double d = Math.abs(e.getX() - last[0]) + Math.abs(e.getY() - last[1]) + Math.abs(e.getZ() - last[2]);
                last[3] = d < 1e-4 ? last[3] + 1 : 0;
                last[0] = e.getX(); last[1] = e.getY(); last[2] = e.getZ();
                still = last[3] >= 2;
            }

            Info in = new Info();
            in.e = e;
            in.group = g;
            in.still = still;
            in.owner = pe.getOwner();
            in.mine = in.owner == mc.player;
            Vec3d v = e.getVelocity();
            in.vx = v.x; in.vy = v.y; in.vz = v.z;
            if (!still) {
                in.path = Ballistics.simulate(e.getX(), e.getY(), e.getZ(), v.x, v.y, v.z, prm[0], prm[1], 160, minY, hit);
            }
            LIVE.add(in);

            if (g == 0) trackPearl(mc, e, in);
        }

        // pearls that vanished = landed (teleport happened)
        Iterator<Map.Entry<Integer, Track>> it = TRACKS.entrySet().iterator();
        while (it.hasNext()) {
            Track t = it.next().getValue();
            if (t.seen == tickNo) continue;
            it.remove();
            if (t.trail.size() < 2 || !t.entity.isRemoved()) continue;
            double[] end = t.trail.get(t.trail.size() - 1);
            if (mc.player.squaredDistanceTo(end[0], end[1], end[2]) > 160 * 160) continue;   // just left render distance
            Landed l = new Landed();
            l.name = t.name;
            l.trail = new ArrayList<>(t.trail);
            l.x = end[0]; l.y = end[1]; l.z = end[2];
            l.ox = t.ox; l.oy = t.oy; l.oz = t.oz; l.oyaw = t.oyaw;
            l.yaw = t.owner != null && !t.owner.isRemoved() ? t.owner.getYaw() : t.oyaw;
            l.end = System.currentTimeMillis() + (long) (ghostTime.f() * 1000f);
            if (!t.mine) LANDED.add(l);
            else if (LANDED.size() < 8) { l.end = System.currentTimeMillis() + 1500; LANDED.add(l); }
        }
        long now = System.currentTimeMillis();
        LANDED.removeIf(l -> l.end < now);
        if (LAST.size() > 600) LAST.clear();
    }

    private static void trackPearl(MinecraftClient mc, Entity e, Info in) {
        Track t = TRACKS.get(e.getId());
        if (t == null) {
            t = new Track();
            t.entity = e;
            t.owner = in.owner;
            t.mine = in.mine;
            if (in.owner instanceof PlayerEntity p) t.name = p.getName().getString();
            Entity src = in.owner != null ? in.owner : e;
            t.ox = src.getX(); t.oy = src.getY(); t.oz = src.getZ(); t.oyaw = src.getYaw();
            TRACKS.put(e.getId(), t);
        }
        t.seen = tickNo;
        if (t.trail.size() < 400) t.trail.add(new double[]{e.getX(), e.getY(), e.getZ()});
    }

    // ------------------------------------------------------------------ render

    public static void render(DrawContext ctx, MinecraftClient mc, float tp) {
        if (!ModuleManager.TRAJECTORIES.enabled || mc.world == null || mc.player == null) return;
        Proj cam = HudFx.camera(mc, tp);
        if (cam == null) return;
        Canvas cv = HudFx.canvas(ctx);
        float t = HudFx.time();
        int w = Math.round(width.f());
        float a = opacity.f();
        int mode = color.i();

        for (Info in : LIVE) {
            if (in.e.isRemoved() || in.path == null || in.path.pts.size() < 2) continue;
            List<double[]> pts = new ArrayList<>(in.path.pts);
            // start where the entity is actually drawn (it is interpolated between ticks)
            pts.set(0, new double[]{in.e.getX() - in.vx * (1 - tp), in.e.getY() - in.vy * (1 - tp), in.e.getZ() - in.vz * (1 - tp)});
            polyline(cv, cam, pts, mode, t, a, w, in.e.getId() * 0.13f);

            double[] end = in.path.last();
            if (in.path.hit && marker.b()) marker(cv, cam, end, mode, t, a, w);

            boolean otherPearl = in.group == 0 && !in.mine && in.owner instanceof PlayerEntity;
            if (otherPearl && ghosts.b() && in.path.hit) {
                float yaw = ((PlayerEntity) in.owner).getYaw(tp);
                GhostGfx.draw(cv, cam, end[0], end[1], end[2], yaw, Neon.pick(mode, t, 0.3f), a * 0.9f, w);
                if (labels.b()) {
                    String s = ((PlayerEntity) in.owner).getName().getString() + "  "
                            + String.format("%.1fs", in.path.ticks / 20f);
                    label(ctx, mc, cam, end[0], end[1] + 2.15, end[2], s, a);
                }
            } else if (in.path.hit && labels.b() && marker.b()) {
                double d = Math.sqrt(mc.player.squaredDistanceTo(end[0], end[1], end[2]));
                label(ctx, mc, cam, end[0], end[1] + 0.35, end[2], String.format("%.0fm", d), a * 0.8f);
            }
        }

        // pearls that just landed: path + the player model where he arrived
        long now = System.currentTimeMillis();
        for (Landed l : LANDED) {
            float left = Math.min(1f, (l.end - now) / 1000f);
            if (left <= 0) continue;
            polyline(cv, cam, l.trail, mode, t, a * left * 0.8f, w, 0.5f);
            if (ghosts.b()) {
                int rgb = Neon.pick(mode, t, 0.3f);
                GhostGfx.draw(cv, cam, l.x, l.y, l.z, l.yaw, rgb, a * left, w);
                if (origin.b()) GhostGfx.draw(cv, cam, l.ox, l.oy, l.oz, l.oyaw, rgb, a * left * 0.45f, w);
                if (labels.b()) label(ctx, mc, cam, l.x, l.y + 2.15, l.z, l.name, a * left);
            }
        }

        if (myAim.b()) drawMyAim(ctx, mc, cam, tp, cv, mode, t, a, w);
    }

    // ------------------------------------------------------------------ own aim

    private static void drawMyAim(DrawContext ctx, MinecraftClient mc, Proj cam, float tp, Canvas cv,
                                  int mode, float t, float a, int w) {
        var p = mc.player;
        double gravity = 0.03, speed, roll = 0;
        ItemStack st = null;
        String id = null;
        for (ItemStack s : new ItemStack[]{p.getMainHandStack(), p.getOffHandStack()}) {
            if (s == null || s.isEmpty()) continue;
            String path = Registries.ITEM.getId(s.getItem()).getPath();
            if (path.equals("ender_pearl") || path.equals("snowball") || path.equals("egg")
                    || path.equals("splash_potion") || path.equals("lingering_potion")
                    || path.equals("experience_bottle") || path.equals("bow") || path.equals("trident")) {
                st = s;
                id = path;
                break;
            }
        }
        if (st == null) return;
        switch (id) {
            case "ender_pearl", "snowball", "egg" -> speed = 1.5;
            case "splash_potion", "lingering_potion" -> { speed = 0.5; gravity = 0.05; roll = -20; }
            case "experience_bottle" -> { speed = 0.7; gravity = 0.07; roll = -20; }
            case "bow" -> {
                if (!p.isUsingItem()) return;
                float f = p.getItemUseTime() / 20f;
                f = (f * f + f * 2f) / 3f;
                if (f < 0.1f) return;
                speed = Math.min(1f, f) * 3.0;
                gravity = 0.05;
            }
            default -> {                                   // trident
                if (!p.isUsingItem()) return;
                speed = 2.5;
                gravity = 0.05;
            }
        }
        double yaw = Math.toRadians(p.getYaw(tp)), pitch = Math.toRadians(p.getPitch(tp) + roll);
        double dx = -Math.sin(yaw) * Math.cos(pitch), dy = -Math.sin(pitch), dz = Math.cos(yaw) * Math.cos(pitch);
        Vec3d pv = p.getVelocity();
        double vx = dx * speed + pv.x, vy = dy * speed + (p.isOnGround() ? 0 : pv.y), vz = dz * speed + pv.z;

        Ballistics.Result r = Ballistics.simulate(cam.cx, cam.cy - 0.1, cam.cz, vx, vy, vz, gravity, 0.99, 160,
                mc.world.getBottomY() - 8, hitTest(mc));
        if (r.pts.size() < 2) return;
        polyline(cv, cam, r.pts, mode, t, a, w, 0.9f);
        if (r.hit) {
            if (marker.b()) marker(cv, cam, r.last(), mode, t, a, w);
            if (labels.b()) {
                double[] e = r.last();
                double d = Math.sqrt(p.squaredDistanceTo(e[0], e[1], e[2]));
                label(ctx, mc, cam, e[0], e[1] + 0.35, e[2], String.format("%.1fm  %.1fs", d, r.ticks / 20f), a * 0.9f);
            }
        }
    }

    // ------------------------------------------------------------------ drawing helpers

    private static void polyline(Canvas c, Proj cam, List<double[]> pts, int mode, float t, float alpha, int w, float seed) {
        int n = pts.size();
        if (n < 2) return;
        double[][] v = new double[n][];
        for (int i = 0; i < n; i++) v[i] = cam.view(pts.get(i)[0], pts.get(i)[1], pts.get(i)[2]);
        for (int i = 0; i < n - 1; i++) {
            double[][] seg = Proj.clipSegment(v[i], v[i + 1]);
            if (seg == null) continue;
            double[] s0 = cam.screen(seg[0]), s1 = cam.screen(seg[1]);
            float f = 1f - 0.5f * i / n;
            int rgb = Neon.pick(mode, t, seed + i * 0.025f);
            Fx.line(c, cam.sw, cam.sh, s0[0], s0[1], s1[0], s1[1], w + 3, Fx.withAlpha(rgb, alpha * f * 0.14f));
            Fx.line(c, cam.sw, cam.sh, s0[0], s0[1], s1[0], s1[1], w, Fx.withAlpha(rgb, alpha * f));
        }
    }

    /** A pulsing ring + cross on the ground where the projectile will land. */
    private static void marker(Canvas c, Proj cam, double[] p, int mode, float t, float alpha, int w) {
        double r = 0.28 + 0.05 * Math.sin(t * 6);
        int seg = 14;
        double[][] v = new double[seg + 1][];
        for (int i = 0; i <= seg; i++) {
            double ang = i * Math.PI * 2 / seg;
            v[i] = cam.view(p[0] + Math.cos(ang) * r, p[1] + 0.03, p[2] + Math.sin(ang) * r);
        }
        int rgb = Neon.pick(mode, t, 0.5f);
        for (int i = 0; i < seg; i++) {
            double[][] s = Proj.clipSegment(v[i], v[i + 1]);
            if (s == null) continue;
            double[] a = cam.screen(s[0]), b = cam.screen(s[1]);
            Fx.line(c, cam.sw, cam.sh, a[0], a[1], b[0], b[1], w + 3, Fx.withAlpha(rgb, alpha * 0.16f));
            Fx.line(c, cam.sw, cam.sh, a[0], a[1], b[0], b[1], w, Fx.withAlpha(rgb, alpha));
        }
        double k = r * 0.55;
        double[][][] cross = {
                {{p[0] - k, p[1] + 0.03, p[2] - k}, {p[0] + k, p[1] + 0.03, p[2] + k}},
                {{p[0] - k, p[1] + 0.03, p[2] + k}, {p[0] + k, p[1] + 0.03, p[2] - k}}};
        for (double[][] l : cross) {
            double[][] s = Proj.clipSegment(cam.view(l[0][0], l[0][1], l[0][2]), cam.view(l[1][0], l[1][1], l[1][2]));
            if (s == null) continue;
            double[] a = cam.screen(s[0]), b = cam.screen(s[1]);
            Fx.line(c, cam.sw, cam.sh, a[0], a[1], b[0], b[1], w, Fx.withAlpha(rgb, alpha * 0.85f));
        }
    }

    private static void label(DrawContext ctx, MinecraftClient mc, Proj cam, double x, double y, double z, String s, float alpha) {
        double[] sc = cam.project(x, y, z);
        if (sc == null) return;
        float scale = 0.8f;
        float tx = (float) sc[0] - Draw.textWidth(mc.textRenderer, s, scale) / 2f;
        Draw.text(ctx, mc.textRenderer, s, tx, (float) sc[1], scale, Draw.argb((int) (255 * Math.min(1f, alpha)), 0xFFFFFF));
    }
}
