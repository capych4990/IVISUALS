package com.ivisuals;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Small helpers to draw world-space shapes (rings, lines, floating text) on the HUD layer through Proj. */
final class WorldFx {
    private WorldFx() {}

    static final String[] WHO = {"Me", "Others", "Everyone"};

    static boolean allows(int who, boolean self) {
        return who == 2 || (who == 0 && self) || (who == 1 && !self);
    }

    static void line(Canvas c, Proj cam, double ax, double ay, double az, double bx, double by, double bz,
                     int w, int argb) {
        double[][] seg = Proj.clipSegment(cam.view(ax, ay, az), cam.view(bx, by, bz));
        if (seg == null) return;
        double[] s0 = cam.screen(seg[0]), s1 = cam.screen(seg[1]);
        Fx.line(c, cam.sw, cam.sh, s0[0], s0[1], s1[0], s1[1], w, argb);
    }

    /** Glowing line: soft wide copy + bright core. */
    static void glowLine(Canvas c, Proj cam, double ax, double ay, double az, double bx, double by, double bz,
                         int w, int rgb, float a) {
        if (a <= 0.01f) return;
        line(c, cam, ax, ay, az, bx, by, bz, w + 3, Fx.withAlpha(rgb, a * 0.14f));
        line(c, cam, ax, ay, az, bx, by, bz, w, Fx.withAlpha(rgb, a));
    }

    /** Arc of a horizontal circle (angles in radians). */
    static void arc(Canvas c, Proj cam, double cx, double cy, double cz, double r, double a0, double sweep,
                    int segs, int w, int rgb, float a) {
        double px = cx + Math.cos(a0) * r, pz = cz + Math.sin(a0) * r;
        for (int i = 1; i <= segs; i++) {
            double ang = a0 + sweep * i / segs;
            double x = cx + Math.cos(ang) * r, z = cz + Math.sin(ang) * r;
            glowLine(c, cam, px, cy, pz, x, cy, z, w, rgb, a);
            px = x;
            pz = z;
        }
    }

    static void ring(Canvas c, Proj cam, double cx, double cy, double cz, double r, int w, int rgb, float a) {
        int segs = r > 1.5 ? 40 : 28;
        arc(c, cam, cx, cy, cz, r, 0, Math.PI * 2, segs, w, rgb, a);
    }

    /** True when no block stands between the camera and the point. */
    static boolean visible(MinecraftClient mc, Proj cam, double x, double y, double z) {
        try {
            return mc.world.raycast(new RaycastContext(new Vec3d(cam.cx, cam.cy, cam.cz), new Vec3d(x, y, z),
                    RaycastContext.ShapeType.VISUAL, RaycastContext.FluidHandling.NONE, mc.player))
                    .getType() == HitResult.Type.MISS;
        } catch (Throwable t) {
            return true;
        }
    }

    /** Text with a dark shadow, centred on the screen position of a world point. */
    static void text(DrawContext ctx, MinecraftClient mc, Proj cam, double x, double y, double z, String s,
                     float scale, int rgb, float a) {
        double[] p = cam.project(x, y, z);
        if (p == null || a <= 0.02f) return;
        float tw = Draw.textWidth(mc.textRenderer, s, scale);
        float sx = (float) p[0] - tw / 2f, sy = (float) p[1] - 4f * scale;
        Draw.text(ctx, mc.textRenderer, s, sx + 1, sy + 1, scale, Draw.argb((int) (170 * a), 0x000000));
        Draw.text(ctx, mc.textRenderer, s, sx, sy, scale, Draw.argb((int) (255 * a), rgb));
    }
}
