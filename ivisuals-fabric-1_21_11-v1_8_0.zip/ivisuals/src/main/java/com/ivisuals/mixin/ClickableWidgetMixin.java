package com.ivisuals.mixin;

import com.ivisuals.NeonButtons;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Neon edge on every button / slider in the game. */
@Mixin(ClickableWidget.class)
public abstract class ClickableWidgetMixin {
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void ivisuals$neon(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        NeonButtons.draw(context, (ClickableWidget) (Object) this);
    }
}
