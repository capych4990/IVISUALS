package com.ivisuals.mixin;

import com.ivisuals.SkyFx;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Sky: getCloudsColor (Vec3d variant). Only one of the variants matches the real method; the other one is skipped. */
@Mixin(ClientWorld.class)
public abstract class CloudColorVecMixin {
    @Inject(method = "getCloudsColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void ivisuals$sky(CallbackInfoReturnable<Vec3d> cir) {
        if (SkyFx.tintClouds() && SkyFx.cloudVec()) cir.setReturnValue(SkyFx.vec(0.5f));
    }
}
