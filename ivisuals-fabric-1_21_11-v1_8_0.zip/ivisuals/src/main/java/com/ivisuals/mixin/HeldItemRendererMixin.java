package com.ivisuals.mixin;

import com.ivisuals.HandTweaks;
import com.ivisuals.HeldTint;
import com.ivisuals.ModuleManager;
import com.ivisuals.SwingAnimation;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    private boolean ivisuals$pushed;

    /** Hand Tweaks: move / scale / rotate the whole hand (arm + item) around its own pivot. */
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void ivisuals$handPre(AbstractClientPlayerEntity player, float tickProgress, float pitch, Hand hand,
                                  float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                                  OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        ivisuals$pushed = false;
        HeldTint.begin(matrices, queue, hand == Hand.MAIN_HAND);
        if (!ModuleManager.HANDS.enabled) return;
        boolean main = hand == Hand.MAIN_HAND;
        Arm arm = main ? player.getMainArm() : player.getMainArm().getOpposite();
        matrices.push();
        HandTweaks.apply(matrices, arm, main);
        ivisuals$pushed = true;
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void ivisuals$handPost(AbstractClientPlayerEntity player, float tickProgress, float pitch, Hand hand,
                                   float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                                   OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        if (ivisuals$pushed) {
            matrices.pop();
            ivisuals$pushed = false;
        }
        HeldTint.end();
    }

    /** Held Tint: right after the item was queued (matrix stack still holds the item transform) draw the color coat. */
    @Inject(method = "renderItem", at = @At("RETURN"), require = 0)
    private void ivisuals$tint(CallbackInfo ci) {
        HeldTint.afterItem(this);
    }

    /** Swing Animation: replaces the vanilla swing offset of a held item. */
    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true)
    private void ivisuals$swing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        if (ModuleManager.SWING.enabled && SwingAnimation.apply(matrices, arm, swingProgress)) ci.cancel();
    }
}
