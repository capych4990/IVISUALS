package com.ivisuals.mixin;

import com.ivisuals.Nametags;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Nametags: the vanilla name above players is removed (ours is drawn instead).
 * Hooked in the base renderer: every renderer calls it first, so the name is gone before the label is queued.
 */
@Mixin(EntityRenderer.class)
public abstract class PlayerRendererMixin {
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/Entity;Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V",
            at = @At("TAIL"), require = 0)
    private void ivisuals$noVanillaName(Entity entity, EntityRenderState state, float tickProgress, CallbackInfo ci) {
        if (entity instanceof PlayerEntity) Nametags.stripVanillaLabel(state);
    }
}
