package com.ivisuals.mixin;

import com.ivisuals.Friends;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Friends, second hook: if ChatScreen does not declare its own mouseClicked in this version, the click still gets
 * here through Screen. (When the ChatScreen hook already used the click, this one is never reached.)
 */
@Mixin(Screen.class)
public abstract class ScreenClickMixin {
    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true, require = 0)
    private void ivisuals$friendClick2(Click click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        Object self = this;
        if (self instanceof ChatScreen && click.button() == 0 && Friends.onChatClick(click.x(), click.y())) {
            cir.setReturnValue(true);
        }
    }
}
