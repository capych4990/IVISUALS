package com.ivisuals.mixin;

import com.ivisuals.SkyFx;
import net.minecraft.client.world.ClientWorld;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Sky: getSkyColor (int variant). Only one of the variants matches the real method; the other one is skipped. */
@Mixin(ClientWorld.class)
public abstract class SkyColorIntMixin {
    @Inject(method = "getSkyColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void ivisuals$sky(CallbackInfoReturnable<Integer> cir) {
        if (SkyFx.active() && SkyFx.skyInt()) cir.setReturnValue(0xFF000000 | SkyFx.rgb(0f));
    }
}
