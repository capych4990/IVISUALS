package com.ivisuals.mixin;

import com.ivisuals.SkyFx;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Sky: getSkyColor (Vec3d variant). Only one of the variants matches the real method; the other one is skipped. */
@Mixin(ClientWorld.class)
public abstract class SkyColorVecMixin {
    @Inject(method = "getSkyColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void ivisuals$sky(CallbackInfoReturnable<Vec3d> cir) {
        if (SkyFx.active() && SkyFx.skyVec()) cir.setReturnValue(SkyFx.vec(0f));
    }
}
