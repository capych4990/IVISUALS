package com.ivisuals.mixin;

import com.ivisuals.LoadingFx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Startup loading screen: our own picture is drawn over the vanilla Mojang overlay (which keeps doing the real loading logic). */
@Mixin(SplashOverlay.class)
public abstract class SplashOverlayMixin {
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void ivisuals$loading(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        LoadingFx.onOverlay(context);
    }
}
