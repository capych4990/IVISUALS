#!/usr/bin/env python3
"""Generates the black & white lobby panorama, menu backgrounds and button sprites of Ivisuals.
   Run:  python3 tools/gen_assets.py     (needs numpy + Pillow)
   Output goes to src/main/resources/assets/minecraft/... and overrides the vanilla textures."""
import json, os, sys
import numpy as np
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "minecraft", "textures", "gui")
N = int(sys.argv[1]) if len(sys.argv) > 1 else 1024     # panorama face size


def save(img, *path):
    p = os.path.join(ROOT, *path)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p, optimize=True)


# ----------------------------------------------------------------------------- noise
def hash3(ix, iy, iz, seed):
    h = (ix.astype(np.int64) * 374761393 + iy.astype(np.int64) * 668265263 + iz.astype(np.int64) * 2147483647 + seed * 1274126177) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    h = h ^ (h >> 16)
    return (h & 0xFFFFFF).astype(np.float32) / float(0xFFFFFF)


def vnoise(p, seed):
    x, y, z = p[..., 0], p[..., 1], p[..., 2]
    ix, iy, iz = np.floor(x), np.floor(y), np.floor(z)
    fx, fy, fz = (x - ix), (y - iy), (z - iz)
    fx, fy, fz = fx * fx * (3 - 2 * fx), fy * fy * (3 - 2 * fy), fz * fz * (3 - 2 * fz)
    def c(dx, dy, dz): return hash3(ix + dx, iy + dy, iz + dz, seed)
    x00 = c(0, 0, 0) * (1 - fx) + c(1, 0, 0) * fx
    x10 = c(0, 1, 0) * (1 - fx) + c(1, 1, 0) * fx
    x01 = c(0, 0, 1) * (1 - fx) + c(1, 0, 1) * fx
    x11 = c(0, 1, 1) * (1 - fx) + c(1, 1, 1) * fx
    return (x00 * (1 - fy) + x10 * fy) * (1 - fz) + (x01 * (1 - fy) + x11 * fy) * fz


def fbm(p, seed, octaves=4):
    v = np.zeros(p.shape[:-1], np.float32)
    a, f = 0.5, 1.0
    for o in range(octaves):
        v += a * vnoise(p * f, seed + o * 17)
        a *= 0.5
        f *= 2.03
    return v / 0.9375


# ----------------------------------------------------------------------------- panorama
def face_dirs(face, n):
    """Direction vectors of the (n+1)x(n+1) pixel corners of a cube face (grid, so we can take per-pixel derivatives)."""
    g = np.linspace(-1, 1, n + 1, dtype=np.float32)
    u = g[None, :].repeat(n + 1, 0)            # left -> right
    v = -g[:, None].repeat(n + 1, 1)           # top -> bottom  (v = +1 at the top)
    one = np.ones_like(u)
    d = {0: (u, v, -one), 1: (one, v, u), 2: (-u, v, one), 3: (-one, v, -u), 4: (u, one, v), 5: (u, -one, -v)}[face]
    d = np.stack(d, -1)
    return d / np.linalg.norm(d, axis=-1, keepdims=True)


def line_mask(s, width_px=1.3):
    """s = scalar field on the corner grid; lines where s is an integer. Returns pixel-centre intensity 0..1 (core + glow)."""
    su = s[:-1, 1:] - s[:-1, :-1]
    sv = s[1:, :-1] - s[:-1, :-1]
    g = np.sqrt(su * su + sv * sv) + 1e-5
    sc = 0.25 * (s[:-1, :-1] + s[1:, :-1] + s[:-1, 1:] + s[1:, 1:])
    dist = np.abs(sc - np.round(sc))
    px = dist / g
    core = np.clip((width_px - px) / 0.9, 0, 1)
    glow = 0.20 * np.exp(-px / 4.5)
    return np.clip(core + glow, 0, 1)


def panorama_face(face, n):
    d = face_dirs(face, n)
    # layer 1: bold terrain-like contour lines
    s1 = fbm(d * 1.25 + 11.0, 3) * 7.0
    l1 = line_mask(s1, 1.25) * 0.62
    # layer 2: finer, fainter contours
    s2 = fbm(d * 2.6 + 40.0, 9, 3) * 15.0
    l2 = line_mask(s2, 0.8) * 0.16
    # layer 3: dashed great circles (orbits)
    layers = np.zeros_like(l1)
    for k, (nx, ny, nz, ph) in enumerate([(0.3, 0.92, 0.25, 0.0), (-0.75, 0.35, 0.56, 1.3), (0.62, -0.5, 0.6, 2.4)]):
        nv = np.array([nx, ny, nz], np.float32); nv /= np.linalg.norm(nv)
        a = np.cross(nv, [0.3, 0.1, 1.0]); a /= np.linalg.norm(a)
        b = np.cross(nv, a)
        dist = d @ nv * 260.0                                   # ~ pixels across the circle
        phi = np.arctan2(d @ b, d @ a)
        dist_c = 0.25 * (dist[:-1, :-1] + dist[1:, :-1] + dist[:-1, 1:] + dist[1:, 1:])
        phi_c = 0.25 * (phi[:-1, :-1] + phi[1:, :-1] + phi[:-1, 1:] + phi[1:, 1:])
        gu = dist[:-1, 1:] - dist[:-1, :-1]; gv = dist[1:, :-1] - dist[:-1, :-1]
        px = np.abs(dist_c) / (np.sqrt(gu * gu + gv * gv) + 1e-5)
        dash = (np.sin(phi_c * (36 + 12 * k) + ph) > -0.15).astype(np.float32)
        layers = np.maximum(layers, np.clip((1.3 - px) / 0.8, 0, 1) * dash * 1.0 + 0.16 * np.exp(-px / 5) * dash)
    # layer 4: stars
    q = d * 46.0
    cell = np.floor(q)
    h = hash3(cell[..., 0], cell[..., 1], cell[..., 2], 5)
    sp = np.stack([hash3(cell[..., 0], cell[..., 1], cell[..., 2], 6),
                   hash3(cell[..., 0], cell[..., 1], cell[..., 2], 7),
                   hash3(cell[..., 0], cell[..., 1], cell[..., 2], 8)], -1) + cell
    dd = np.linalg.norm(q - sp, axis=-1)
    star = np.where(h < 0.10, np.exp(-(dd / 0.20) ** 2) * (0.5 + 1.0 * hash3(cell[..., 0], cell[..., 1], cell[..., 2], 9)), 0)
    star = np.clip(star[:-1, :-1], 0, 1)

    img = np.clip(np.maximum.reduce([l1, l2, layers, star]), 0, 1)
    # very dark depth: a faint noise haze
    haze = fbm(d * 1.1 + 70.0, 21, 3)[:-1, :-1]
    img = np.clip(img + 0.03 * haze, 0, 1)

    # fade out near the face borders so the seams stay invisible
    t = (np.arange(n) + 0.5) / n
    e = np.minimum(t, 1 - t)
    edge = np.minimum(e[:, None], e[None, :]) / 0.03
    edge = np.clip(edge, 0, 1)
    edge = edge * edge * (3 - 2 * edge)
    img = img * (0.25 + 0.75 * edge)

    g = (img * 255).astype(np.uint8)
    return Image.fromarray(g, "L").convert("RGB")


def gen_panorama():
    for f in range(6):
        save(panorama_face(f, N), "title", "background", f"panorama_{f}.png")
        print("panorama", f)


# ----------------------------------------------------------------------------- menu backgrounds / separators
def gen_backgrounds():
    # 32x32, pattern period 16 (identical whether the game treats the file as 16 or 32 px)
    a = np.zeros((32, 32, 4), np.uint8)
    a[..., :3] = 9
    a[..., 3] = 255
    for k in (0, 16):
        a[k, :, :3] = 24
        a[:, k, :3] = 24
    save(Image.fromarray(a, "RGBA"), "menu_background.png")
    b = np.zeros((32, 32, 4), np.uint8)
    b[..., 3] = 168
    for k in (0, 16):
        b[k, :, :] = (255, 255, 255, 18)
        b[:, k, :] = (255, 255, 255, 18)
    save(Image.fromarray(b, "RGBA"), "inworld_menu_background.png")
    for name in ("header_separator", "footer_separator", "inworld_header_separator", "inworld_footer_separator"):
        s = np.zeros((2, 32, 4), np.uint8)
        s[0] = (255, 255, 255, 120)
        s[1] = (0, 0, 0, 255)
        save(Image.fromarray(s, "RGBA"), f"{name}.png")


# ----------------------------------------------------------------------------- button sprites
def nine(name, w, h, border, fill, edge, hole_corner=True, extra=None):
    a = np.zeros((h, w, 4), np.uint8)
    a[...] = (*fill, 255)
    a[0, :] = (*edge, 255); a[h - 1, :] = (*edge, 255)
    a[:, 0] = (*edge, 255); a[:, w - 1] = (*edge, 255)
    if hole_corner:
        for (y, x) in ((0, 0), (0, w - 1), (h - 1, 0), (h - 1, w - 1)):
            a[y, x] = (0, 0, 0, 0)
    if extra: extra(a)
    save(Image.fromarray(a, "RGBA"), "sprites", "widget", name + ".png")
    meta = {"gui": {"scaling": {"type": "nine_slice", "width": w, "height": h, "border": border}}}
    with open(os.path.join(ROOT, "sprites", "widget", name + ".png.mcmeta"), "w") as f:
        json.dump(meta, f, indent=2)


def gen_buttons():
    nine("button", 200, 20, 3, (10, 10, 13), (150, 150, 160))
    nine("button_highlighted", 200, 20, 3, (26, 26, 31), (255, 255, 255))
    nine("button_disabled", 200, 20, 3, (12, 12, 12), (62, 62, 66))
    nine("slider", 200, 20, 3, (6, 6, 8), (120, 120, 128))
    nine("slider_highlighted", 200, 20, 3, (14, 14, 18), (230, 230, 238))
    nine("slider_handle", 8, 20, 3, (225, 225, 232), (255, 255, 255))
    nine("slider_handle_highlighted", 8, 20, 3, (255, 255, 255), (255, 255, 255))


if __name__ == "__main__":
    gen_buttons()
    gen_backgrounds()
    gen_panorama()
    print("done ->", os.path.normpath(ROOT))
