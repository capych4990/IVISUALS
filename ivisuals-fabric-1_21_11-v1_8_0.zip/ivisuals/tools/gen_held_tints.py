#!/usr/bin/env python3
"""Generates the flat translucent color textures used by Held Tint.
   c0..c23 = hues (every 15 degrees), c24 = white;  a0..a3 = opacity levels.
   Output: src/main/resources/assets/ivisuals/textures/held/c{color}_a{alpha}.png   (needs Pillow)"""
import colorsys, os
from PIL import Image

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources",
                   "assets", "ivisuals", "textures", "held")
ALPHAS = [0.25, 0.40, 0.60, 0.80]
os.makedirs(OUT, exist_ok=True)
for c in range(25):
    if c == 24:
        rgb = (255, 255, 255)
    else:
        r, g, b = colorsys.hsv_to_rgb(c / 24.0, 0.85, 1.0)
        rgb = (int(r * 255), int(g * 255), int(b * 255))
    for a, al in enumerate(ALPHAS):
        Image.new("RGBA", (4, 4), rgb + (int(al * 255),)).save(os.path.join(OUT, f"c{c}_a{a}.png"), optimize=True)
print("done")
