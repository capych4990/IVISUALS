# nightree — local anti-cheat test client (Fabric, MC 1.21.11, Java 21)
Test tool for YOUR OWN server / local worlds. No anticheat bypass, no stealth.

## Build
1. Check versions at https://fabricmc.net/develop and fix `gradle.properties`.
2. `gradle wrapper` (once), then `./gradlew build`
3. JAR: `build/libs/nightree-0.1.0.jar` -> put in `.minecraft/mods` with Fabric API.

## Use
- Right Shift opens the GUI (rebind in Controls -> nightree).
- Click a module to toggle, "Bind" then press a key (Esc = clear), mode button cycles Legit/Suspicious/Extreme, Run logs a test event.
- Profiles: `config/nightree/profiles/*.json`.

## Status
Done: module/category system, binds, JSON profiles, GUI, basic HUD, test log + counters.
TODO: render modules (ESP etc.), projectile tracker, skin loader, hand animation, per-server profiles, real test scenarios in `TestModule.run()`.
