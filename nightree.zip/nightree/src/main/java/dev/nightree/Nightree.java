package dev.nightree;
import dev.nightree.config.ConfigManager;
import dev.nightree.gui.ClickGui;
import dev.nightree.module.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
public class Nightree implements ClientModInitializer {
    private static KeyBinding openGui;
    private static final boolean[] down = new boolean[512];
    @Override public void onInitializeClient() {
        ModuleManager.init(); ConfigManager.load("default");
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.nightree.gui", InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.create(Identifier.of("nightree", "main"))));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) mc.setScreen(new ClickGui());
            if (mc.currentScreen != null || mc.getWindow() == null) return;
            for (Module m : ModuleManager.ALL) {
                if (m.key < 0 || m.key >= 512) continue;
                boolean p = InputUtil.isKeyPressed(mc.getWindow(), m.key);
                if (p && !down[m.key]) { if (m instanceof TestModule t) t.run(); else m.toggle(); }
                down[m.key] = p;
            }
            ModuleManager.ALL.forEach(m -> { if (m.enabled) m.onTick(); });
        });
        HudElementRegistry.addLast(Identifier.of("nightree", "hud"), (ctx, tick) -> {
            MinecraftClient mc = MinecraftClient.getInstance(); if (mc.player == null) return;
            int y = 4, c = 0xFFFFFFFF; var tr = mc.textRenderer;
            if (ModuleManager.on("HUD FPS")) ctx.drawTextWithShadow(tr, "FPS: " + mc.getCurrentFps(), 4, y += 10, c);
            if (ModuleManager.on("HUD Coords")) ctx.drawTextWithShadow(tr, String.format("XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()), 4, y += 10, c);
            if (ModuleManager.on("HUD Direction")) ctx.drawTextWithShadow(tr, "Dir: " + mc.player.getHorizontalFacing().asString(), 4, y += 10, c);
            if (ModuleManager.on("HUD Health")) ctx.drawTextWithShadow(tr, "HP: " + (int) mc.player.getHealth(), 4, y += 10, c);
            if (ModuleManager.on("HUD Nick")) ctx.drawTextWithShadow(tr, mc.player.getName().getString(), 4, y += 10, c);
            if (ModuleManager.on("TestPanel")) ctx.drawTextWithShadow(tr, "Detected: " + TestLog.detected + " Passed: " + TestLog.passed + " Failed: " + TestLog.failed, 4, y += 10, c);
        });
    }
}
