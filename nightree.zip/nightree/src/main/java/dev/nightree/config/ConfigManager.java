package dev.nightree.config;
import com.google.gson.*;
import dev.nightree.module.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static String profile = "default";
    private static Path dir() { return FabricLoader.getInstance().getConfigDir().resolve("nightree/profiles"); }
    public static List<String> profiles() {
        List<String> r = new ArrayList<>();
        try { Files.createDirectories(dir()); try (var s = Files.list(dir())) { s.forEach(p -> r.add(p.getFileName().toString().replace(".json",""))); } } catch (Exception ignored) {}
        if (!r.contains("default")) r.add("default"); return r;
    }
    public static void save() { save(profile); }
    public static void save(String name) {
        try {
            Files.createDirectories(dir()); JsonObject root = new JsonObject();
            for (Module m : ModuleManager.ALL) {
                JsonObject o = new JsonObject(); o.addProperty("enabled", m.enabled); o.addProperty("key", m.key);
                JsonObject s = new JsonObject(); m.settings.forEach(s::addProperty); o.add("settings", s);
                if (m instanceof TestModule t) o.addProperty("mode", t.mode);
                root.add(m.name, o);
            }
            Files.writeString(dir().resolve(name + ".json"), GSON.toJson(root)); profile = name;
        } catch (Exception e) { e.printStackTrace(); }
    }
    public static void load(String name) {
        try {
            Path f = dir().resolve(name + ".json"); if (!Files.exists(f)) return;
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            for (Module m : ModuleManager.ALL) {
                if (!root.has(m.name)) continue; JsonObject o = root.getAsJsonObject(m.name);
                m.enabled = o.get("enabled").getAsBoolean(); m.key = o.get("key").getAsInt();
                o.getAsJsonObject("settings").entrySet().forEach(e -> m.settings.put(e.getKey(), e.getValue().getAsDouble()));
                if (m instanceof TestModule t && o.has("mode")) t.mode = o.get("mode").getAsInt();
            }
            profile = name;
        } catch (Exception e) { e.printStackTrace(); }
    }
}
