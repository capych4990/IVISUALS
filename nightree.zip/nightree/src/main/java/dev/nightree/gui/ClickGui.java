package dev.nightree.gui;
import dev.nightree.config.ConfigManager;
import dev.nightree.module.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
public class ClickGui extends Screen {
    private static Category current = Category.COMBAT;
    private Module listening;
    public ClickGui() { super(Text.literal("nightree")); }
    @Override protected void init() {
        clearChildren(); int x = 10, i = 0;
        for (Category c : Category.values()) {
            addDrawableChild(ButtonWidget.builder(Text.literal(c.name()), b -> { current = c; init(); })
                .dimensions(x, 10, 70, 18).build()); x += 72;
        }
        int y = 36;
        for (Module m : ModuleManager.ALL) {
            if (m.category != current) continue;
            int col = (i % 2) * 300, row = (i / 2) * 22; i++;
            addDrawableChild(ButtonWidget.builder(Text.literal((m.enabled ? "[ON] " : "[OFF] ") + m.name), b -> { m.toggle(); init(); })
                .dimensions(10 + col, y + row, 140, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal(listening == m ? "..." : "Bind: " + (m.key < 0 ? "none" : InputUtil.fromKeyCode(new KeyInput(m.key, 0, 0)).getLocalizedText().getString())),
                b -> { listening = m; init(); }).dimensions(152 + col, y + row, 70, 20).build());
            if (m instanceof TestModule t) {
                addDrawableChild(ButtonWidget.builder(Text.literal(TestModule.MODES[t.mode]), b -> { t.cycleMode(); init(); })
                    .dimensions(224 + col, y + row, 40, 20).build());
                addDrawableChild(ButtonWidget.builder(Text.literal("Run"), b -> t.run()).dimensions(266 + col, y + row, 30, 20).build());
            }
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Save: " + ConfigManager.profile), b -> ConfigManager.save()).dimensions(10, height - 26, 110, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Next profile"), b -> {
            var l = ConfigManager.profiles(); int n = (l.indexOf(ConfigManager.profile) + 1) % l.size(); ConfigManager.load(l.get(n)); init();
        }).dimensions(124, height - 26, 90, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("New profile"), b -> { ConfigManager.save("profile" + ConfigManager.profiles().size()); init(); })
            .dimensions(218, height - 26, 90, 18).build());
    }
    @Override public boolean keyPressed(KeyInput input) {
        if (listening != null) { listening.key = input.key() == 256 ? -1 : input.key(); listening = null; init(); return true; }
        return super.keyPressed(input);
    }
    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawTextWithShadow(textRenderer, "AntiCheat Test | Detected: " + TestLog.detected + " Passed: " + TestLog.passed + " Failed: " + TestLog.failed, 10, height - 60, 0xFFFFFFFF);
        int s = Math.max(0, TestLog.ENTRIES.size() - 4);
        for (int k = s; k < TestLog.ENTRIES.size(); k++) ctx.drawTextWithShadow(textRenderer, TestLog.ENTRIES.get(k).line(), 10, height - 50 + (k - s) * 9, 0xFFAAAAAA);
    }
}
