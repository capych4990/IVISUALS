package dev.nightree.module;
public enum Category { COMBAT, MOVEMENT, PLAYER, VISUAL, HUD, MISC, ANTICHEAT, TEST }
