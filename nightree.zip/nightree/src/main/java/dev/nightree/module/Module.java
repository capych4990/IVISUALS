package dev.nightree.module;
import java.util.LinkedHashMap;
import java.util.Map;
public class Module {
    public final String name; public final Category category;
    public boolean enabled; public int key = -1; // GLFW key, -1 = none
    public final Map<String, Double> settings = new LinkedHashMap<>();
    public Module(String name, Category category) { this.name = name; this.category = category; }
    public void toggle() { enabled = !enabled; }
    public void onTick() {}
}
