package dev.nightree.module;
import java.util.ArrayList;
import java.util.List;
public final class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();
    public static void init() {
        for (String n : new String[]{"KillAura","TriggerBot","Reach","AutoClicker","Rotation","Hitbox","AttackTiming","TargetSelection"})
            ALL.add(new TestModule(n + " Test", Category.COMBAT));
        for (String n : new String[]{"Sprint","Strafe","Speed","Flight","Spider","NoFall","Jesus","Knockback","Jump","Timer"})
            ALL.add(new TestModule(n + " Test", Category.MOVEMENT));
        for (String n : new String[]{"AutoTotem Test","Ender Pearl Key Test","Wind Charge Key Test","Trap Item Key Test"})
            ALL.add(new TestModule(n, Category.PLAYER));
        for (String n : new String[]{"ESP","PlayerESP","ItemESP","MobESP","Tracer","NameTags","HealthBar","ArmorBar","ItemName","EntityOutline","Hitbox","BlockOutline","FullBright","XRay","ChestESP","EntityDistance","DirectionLines","ArrowTrails","ProjectileTrails","TargetHighlight","DamageIndicator","TotemIndicator","EnchantDisplay","PotionDisplay","TargetInfo","WorldTime","Crosshair","Keystrokes","CPS"})
            ALL.add(new Module(n, Category.VISUAL));
        for (String n : new String[]{"FPS","Ping","Coords","Direction","Health","Nick","Armor","MainHand","Offhand","Totem","Effects","Inventory","ArmorPanel"})
            ALL.add(new Module("HUD " + n, Category.HUD));
        for (String n : new String[]{"ProjectileTracker","SkinLoader","HandAnimation","ServerProfiles"})
            ALL.add(new Module(n, Category.MISC));
        ALL.add(new Module("TestPanel", Category.ANTICHEAT));
        ALL.add(new Module("TestLogOverlay", Category.TEST));
        for (Module m : ALL) if (m instanceof TestModule) m.key = -1;
    }
    public static Module get(String name) { for (Module m : ALL) if (m.name.equals(name)) return m; return null; }
    public static boolean on(String name) { Module m = get(name); return m != null && m.enabled; }
}
