package dev.nightree.module;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
public final class TestLog {
    public record Entry(String time, String module, String event, String params, String result) {
        public String line() { return time + " TEST EVENT -> " + module + " -> " + params + " [" + result + "]"; }
    }
    public static final List<Entry> ENTRIES = new ArrayList<>();
    public static int detected, passed, failed;
    /** result: "DETECTED" = anticheat caught it (pass), "MISSED" = not caught (fail), else "PENDING". */
    public static void add(String module, String event, String params, String result) {
        ENTRIES.add(new Entry(LocalTime.now().withNano(0).toString(), module, event, params, result));
        if (ENTRIES.size() > 500) ENTRIES.remove(0);
        if (result.equals("DETECTED")) { detected++; passed++; } else if (result.equals("MISSED")) failed++;
    }
    public static void clear() { ENTRIES.clear(); detected = passed = failed = 0; }
}
