package dev.nightree.module;
/** Scenario descriptor for your own server. Currently logs a test event; scenario logic goes in run(). */
public class TestModule extends Module {
    public static final String[] MODES = {"Legit", "Suspicious", "Extreme"};
    public int mode = 0;
    public TestModule(String name, Category c) {
        super(name, c);
        settings.put("intensity", 1.0); settings.put("duration", 5.0);
    }
    public void cycleMode() { mode = (mode + 1) % MODES.length; }
    public void run() {
        TestLog.add(name, "run", "mode=" + MODES[mode] + " intensity=" + settings.get("intensity")
            + " duration=" + settings.get("duration") + "s", "PENDING");
        // TODO: apply the local test scenario here. Report "DETECTED"/"MISSED" from your server's anticheat logs.
    }
}
